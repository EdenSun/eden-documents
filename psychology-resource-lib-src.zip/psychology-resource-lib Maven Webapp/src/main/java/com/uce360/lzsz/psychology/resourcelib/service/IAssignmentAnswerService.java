package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.MarkAssignmentAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IAssignmentAnswerService {

	/**
	 * 分页查询作业答案
	 * @param assignmentID 作业ID
	 * @param pager 分页数据
	 * @return
	 */
	ViewDTO<AssignmentAnswerListDTO> listAssignmentAnswer(Long assignmentID,PagerDTO pager)throws ServiceException;

	/**
	 * 获取指定用户的作业答案
	 * @param uid 用户ID
	 * @param assignmentID 作业ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<AssignmentAnswerDTO> getAssignmentAnswerByUIDAndAssignmentID(
			Long uid, Long assignmentID)throws ServiceException;

	/**
	 * 保存作业答案
	 * @param uid 用户ID
	 * @param assignmentID 作业ID
	 * @param assignmentAnswerContent 作业答案内容
	 * @return
	 */
	ViewDTO<Boolean> saveAssignmentAnswer(Long uid, Long assignmentID,
			String assignmentAnswerContent)throws ServiceException;

	/**
	 * 批改作业
	 * @param param
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> markAssignmentAnswer(MarkAssignmentAnswerParam param)throws ServiceException;

}
