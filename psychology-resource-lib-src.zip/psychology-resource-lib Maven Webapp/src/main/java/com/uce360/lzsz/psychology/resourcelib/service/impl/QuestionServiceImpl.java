package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionAnswerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAnswerMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IQuestionMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Answer;
import com.uce360.lzsz.psychology.resourcelib.model.Question;
import com.uce360.lzsz.psychology.resourcelib.service.IQuestionService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class QuestionServiceImpl implements IQuestionService {

	@Autowired
	private IQuestionMapper questionMapper;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IAnswerMapper answerMapper;
	
	@Override
	public ViewDTO<QuestionListDTO> listQuestion(ListQuestionParam param,
			PagerDTO pager) throws ServiceException {
		ViewDTO<QuestionListDTO> view = new ViewDTO<QuestionListDTO>();
		QuestionListDTO listDTO = new QuestionListDTO();
		
		List<Question> questionList = questionMapper.listQuestion(param,pager);
		List<QuestionDTO> dtoList = trans2QuestionListItemDTOList(questionList);
		listDTO.setQuestions(dtoList);
		
		int totalCount = questionMapper.getQuestionCount(param);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	private List<QuestionDTO> trans2QuestionListItemDTOList(
			List<Question> questionList) {
		if( questionList == null ){
			return null;
		}
		List<QuestionDTO> dtoList = new ArrayList<QuestionDTO>();
		QuestionDTO dto = null;
		
		for(Question question:questionList){
			dto = trans2QuestionDTO(question);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		return dtoList;
	}

	private QuestionDTO trans2QuestionDTO(Question question) {
		if( question == null ){
			return null;
		}
		
		QuestionDTO dto = new QuestionDTO();
		BeanUtils.copyProperties(question, dto);
		
		Long askUserID = question.getAskUserID();
		if( askUserID != null ){
			UserDTO userDTO = userService.getUserDTOByID(askUserID);
			
			dto.setAskUser(userDTO);
		}
		return dto;
	}
	

	@Override
	public ViewDTO<QuestionDTO> addQuestion(AddQuestionParam param)
			throws ServiceException {
		ViewDTO<QuestionDTO> view = new ViewDTO<QuestionDTO>();
		
		Question question = new Question();
		question.setAskUserID(param.getUid());
		question.setContent(param.getContent());
		question.setElectiveCourseID(param.getElectiveCourseID());
		question.setStatus(Question.STATUS_NEW);
		question.setTitle(param.getTitle());
		
		questionMapper.save(question);
		
		QuestionDTO dto = trans2QuestionDTO(question);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("成功添加");
		return view;
	}

	@Override
	public ViewDTO<QuestionDTO> getQuestion(Long qid) throws ServiceException {
		ViewDTO<QuestionDTO> view = new ViewDTO<QuestionDTO>();
		
		Question question = questionMapper.getByID(qid);
		
		QuestionDTO dto = trans2QuestionDTO(question);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("获取成功");
		return view;
	}

	@Override
	public ViewDTO<QuestionAnswerListDTO> listQuestionAnswer(Long qid,
			PagerDTO pager) throws ServiceException {
		ViewDTO<QuestionAnswerListDTO> view = new ViewDTO<QuestionAnswerListDTO>();
		QuestionAnswerListDTO listDTO = new QuestionAnswerListDTO();
		
		List<Answer> answers = answerMapper.listByQID(qid,pager);
		List<QuestionAnswerDTO> dtoList = trans2QuestionAnswerDTOList(answers);
		listDTO.setAnswers(dtoList);
		
		int totalCount = answerMapper.listCountByQID(qid);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	private List<QuestionAnswerDTO> trans2QuestionAnswerDTOList(
			List<Answer> answers) {
		if( answers == null ){
			return null;
		}
		List<QuestionAnswerDTO> dtoList = new ArrayList<QuestionAnswerDTO>();
		QuestionAnswerDTO dto = null;
		
		for( Answer answer: answers ){
			dto = trans2QuestionAnswerDTO(answer);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		
		return dtoList;
	}

	private QuestionAnswerDTO trans2QuestionAnswerDTO(Answer answer) {
		if( answer == null ){
			return null;
		}
		QuestionAnswerDTO dto = new QuestionAnswerDTO();
		
		BeanUtils.copyProperties(answer, dto);
		
		Long answerUserID = answer.getAnswerUserID();
		if( answerUserID != null ){
			dto.setAnswerUser(userService.getUserDTOByID(answerUserID));
		}
		
		return dto;
	}

	@Override
	public ViewDTO<Boolean> submitQuestionAnswer(Long uid, Long qid,
			String content) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Answer answer = new Answer();
		answer.setAnswerUserID(uid);
		answer.setContent(content);
		answer.setQuestionID(qid);
		
		answerMapper.save(answer);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("提交成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delByID(Long id) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		questionMapper.delByID( id );
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

}
