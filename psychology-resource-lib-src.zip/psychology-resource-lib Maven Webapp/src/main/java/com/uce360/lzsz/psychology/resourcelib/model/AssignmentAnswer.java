package com.uce360.lzsz.psychology.resourcelib.model;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class AssignmentAnswer {
	private Long id;
	private String content;
	private Long answerUserID;
	private Long assignmentID;
	private Integer score;
	private String teacherComment;
	private Long evaluateUserID;
	private Date createTime = new Date();
	private Integer isDelete = Constants.IS_DELETE_FALSE;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getAnswerUserID() {
		return answerUserID;
	}
	public void setAnswerUserID(Long answerUserID) {
		this.answerUserID = answerUserID;
	}
	public Long getAssignmentID() {
		return assignmentID;
	}
	public void setAssignmentID(Long assignmentID) {
		this.assignmentID = assignmentID;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getTeacherComment() {
		return teacherComment;
	}
	public void setTeacherComment(String teacherComment) {
		this.teacherComment = teacherComment;
	}
	public Long getEvaluateUserID() {
		return evaluateUserID;
	}
	public void setEvaluateUserID(Long evaluateUserID) {
		this.evaluateUserID = evaluateUserID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
}
