package com.uce360.lzsz.psychology.resourcelib.controller.front;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IElectiveCourseService;

@Controller
@RequestMapping("/ucenter")
public class UserCenterController extends BaseController{

	@Autowired
	private IElectiveCourseService electiveCourseService;
	
	@RequestMapping("/my-upload")
	public ModelAndView myUpload(){
		ModelAndView mav = new ModelAndView("ucenter/my-upload");
		
		return mav;
	}
	
	@RequestMapping("/my-download")
	public ModelAndView myDownload(){
		ModelAndView mav = new ModelAndView("ucenter/my-download");
		
		return mav;
	}
	
	@RequestMapping("/my-elective-course")
	public ModelAndView myElectiveCourse(
			HttpSession session
			){
		ModelAndView mav = new ModelAndView("ucenter/my-elective-course");
		
		User user = getLoginUser(session);
		
		List<ElectiveCourseDTO> courseList = electiveCourseService.listAllByUserID(user.getId());
		mav.addObject("courseList", courseList);
		return mav;
	}
}
