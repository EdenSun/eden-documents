package com.uce360.lzsz.psychology.resourcelib.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test")
public class TestController {

	@RequestMapping("/createCar")
	public ModelAndView createCar(HttpServletRequest request){
		System.out.println(request.getQueryString());
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;  
		
		MultipartFile file = multipartRequest.getFile("myFile1");
		System.out.println(file);
		return null;
	}
	
	
	@RequestMapping("/checkUpdate")
	@ResponseBody
	public UpdateDTO checkUpdate(HttpServletRequest request){
		UpdateDTO dto = new UpdateDTO();
		dto.setAppName("真好物流宝");
		dto.setApkURL("http://192.168.0.100:8080/psychology-resource-lib/v12.0.77.apk");
		dto.setApkName("v12.0.77.apk");
		dto.setVerName("12.0.7");
		dto.setVerCode("19");
		return dto;
	}
	
	class UpdateDTO{
		private String appName;
		private String apkURL;
		private String apkName;
		private String verName;
		private String verCode;
		public String getAppName() {
			return appName;
		}
		public void setAppName(String appName) {
			this.appName = appName;
		}
		public String getApkURL() {
			return apkURL;
		}
		public void setApkURL(String apkURL) {
			this.apkURL = apkURL;
		}
		public String getApkName() {
			return apkName;
		}
		public void setApkName(String apkName) {
			this.apkName = apkName;
		}
		public String getVerName() {
			return verName;
		}
		public void setVerName(String verName) {
			this.verName = verName;
		}
		public String getVerCode() {
			return verCode;
		}
		public void setVerCode(String verCode) {
			this.verCode = verCode;
		}
	}
	
}
