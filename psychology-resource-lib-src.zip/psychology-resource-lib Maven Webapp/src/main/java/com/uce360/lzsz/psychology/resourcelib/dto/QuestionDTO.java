package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class QuestionDTO {
	private Long id;
	private String title;
	private String content;
	private Long electiveCourseID;
	private Date createTime;
	
	private UserDTO askUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getElectiveCourseID() {
		return electiveCourseID;
	}

	public void setElectiveCourseID(Long electiveCourseID) {
		this.electiveCourseID = electiveCourseID;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public UserDTO getAskUser() {
		return askUser;
	}

	public void setAskUser(UserDTO askUser) {
		this.askUser = askUser;
	}
	
}
