package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.ResourceCategoryDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceCategoryParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IResourceCategoryService {

	/**
	 * 递归查询所有分类
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceCategoryDTO> listCatelist()throws ServiceException;

	/**
	 * 根据ID删除指定分类
	 * @param id 分类ID
	 * @return 
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delCate(Long id)throws ServiceException;

	/**
	 * 更新指定分类名称
	 * @param id
	 * @param name2 
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> updateCateName(Long id, String name2)throws ServiceException;

	/**
	 * 创建资源分类
	 * @param resCategoryParamDTO
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceCategoryDTO> addCate(
			ResourceCategoryParamDTO resCategoryParamDTO)throws ServiceException;

	/**
	 * 获取所有媒体属性分类
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceCategoryDTO>> listAllMediaCate()throws ServiceException;

	/**
	 * 获取所有课程属性分类
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceCategoryDTO>> listAllCourseCate()throws ServiceException;


}
