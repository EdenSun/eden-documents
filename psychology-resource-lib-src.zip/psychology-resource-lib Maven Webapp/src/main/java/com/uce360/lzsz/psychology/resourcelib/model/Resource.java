package com.uce360.lzsz.psychology.resourcelib.model;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class Resource {

	public static final Integer AUDIT_STATUS_WAITTING_FOR_AUDIT = 1;
	public static final Integer AUDIT_STATUS_APPROVE = 2;
	public static final Integer AUDIT_STATUS_REJECT = 3;
	
	public static final int FORMAT_UNKNOWN = 0;
	public static final int FORMAT_PDF = 1;
	public static final int FORMAT_DOC = 2;
	public static final int FORMAT_DOCX = 3;
	public static final int FORMAT_XLS = 4;
	public static final int FORMAT_XLSX = 5;
	public static final int FORMAT_PPT = 6;
	public static final int FORMAT_PPTX = 7;
	public static final int FORMAT_TXT = 8;
	public static final int FORMAT_RTF = 9;
	public static final int FORMAT_PSD = 10;
	
	
	public static final int FORMAT_AVI = 201;
	public static final int FORMAT_MP4 = 202;
	public static final int FORMAT_WMV = 203;
	public static final int FORMAT_FLV = 204;
	public static final int FORMAT_MOV = 205;
	public static final int FORMAT_RMVB = 206;
	public static final int FORMAT_ASF = 207;
	public static final int FORMAT_MPG = 208;
	public static final int FORMAT_WAV = 209;
	public static final int FORMAT_MP3 = 210;
	
	
	public static final int FORMAT_PNG = 401;
	public static final int FORMAT_JPG = 402;
	public static final int FORMAT_JPEG = 403;
	public static final int FORMAT_GIF = 404;
	public static final int FORMAT_BMP = 405;
	
	public static final int FORMAT_RAR = 600;
	public static final int FORMAT_ZIP = 601;
	
	
	public static final int FACE_TO_ALL = 1;
	public static final int FACE_TO_STUDENT = 2;
	public static final int FACE_TO_TEACHER = 3;
	
	private Long id;
	private String name;
	private String description;
	private String url;
	private String onlineReadUrl;
	private Long size;
	private String keywords;
	private Integer format;
	private Long onlineReadingChannelID;
	private Long creatorID;
	private Integer auditStatus;
	private Integer faceTo;
	private Date createTime;
	private Integer isDelete;
	
	
	public Resource() {
		super();
		this.createTime = new Date();
		this.isDelete = Constants.IS_DELETE_FALSE;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getOnlineReadUrl() {
		return onlineReadUrl;
	}
	public void setOnlineReadUrl(String onlineReadUrl) {
		this.onlineReadUrl = onlineReadUrl;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public Integer getFormat() {
		return format;
	}
	public void setFormat(Integer format) {
		this.format = format;
	}
	public Long getOnlineReadingChannelID() {
		return onlineReadingChannelID;
	}
	public void setOnlineReadingChannelID(Long onlineReadingChannelID) {
		this.onlineReadingChannelID = onlineReadingChannelID;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public Integer getAuditStatus() {
		return auditStatus;
	}
	public void setAuditStatus(Integer auditStatus) {
		this.auditStatus = auditStatus;
	}
	public Integer getFaceTo() {
		return faceTo;
	}
	public void setFaceTo(Integer faceTo) {
		this.faceTo = faceTo;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

}
