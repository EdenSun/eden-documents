package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Assignment;

public interface IAssignmentMapper {

	List<Assignment> listAssignmentByCourseID(
			@Param("uid")Long uid,
			@Param("cid")Long cid, 
			@Param("pager")PagerDTO pager);

	int getAssignmentCountByCourseID(@Param("uid")Long uid,@Param("cid")Long cid);

	Assignment getByID(@Param("id")Long id);

	void save(@Param("assignment")Assignment assignment);

	void delByID(@Param("id")Long id);

	List<Assignment> listStudentsCourseAssignment(@Param("uid")Long uid, @Param("cid")Long cid,
			@Param("pager")PagerDTO pager);

	int getStudentsCourseAssignmentCount(@Param("uid")Long uid, @Param("cid")Long cid);

	List<Assignment> listTeachersCourseAssignment(@Param("uid")Long uid, @Param("cid")Long cid,
			@Param("pager")PagerDTO pager);

	int getTeachersCourseAssignmentCount(@Param("uid")Long uid, @Param("cid")Long cid);

}
