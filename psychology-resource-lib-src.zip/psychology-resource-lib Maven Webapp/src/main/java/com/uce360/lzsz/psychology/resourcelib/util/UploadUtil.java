package com.uce360.lzsz.psychology.resourcelib.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;


public class UploadUtil {
	/**
	 * Description: 向FTP服务器上传文件
	 * @Version      1.0
	 * @param url FTP服务器hostname
	 * @param port  FTP服务器端口
	 * @param username FTP登录账号
	 * @param password  FTP登录密码
	 * @param path  FTP服务器保存目录
	 * @param filename  上传到FTP服务器上的文件名
	 * @param input   输入流
	 * @return 成功返回true，否则返回false *
	 */
	public static String uploadFile(
			String filename, // 上传到FTP服务器上的文件名
			InputStream input // 输入流
	){
		FTPClient ftp = new FTPClient();
		ftp.setControlEncoding("GBK");
		try {
			int reply;
			ftp.connect(Constants.FTP_HOST_NAME, Constants.FTP_PORT);// 连接FTP服务器
			// 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				return null;
			}
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
			
			//以当前日期为基目录
			String folder = UploadUtil.getFTPUploadFolderByDate(new Date());
			boolean isChangeSuccess = ftp.changeWorkingDirectory(folder);
			
			if( isChangeSuccess ){
				
			}else{
				ftp.makeDirectory(folder);
				ftp.changeWorkingDirectory(folder);
			}
			
			ftp.storeFile(filename, input);
			input.close();
			ftp.logout();
			return folder + "/" + filename;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
				}
			}
		}
		return null;
	}

	private static String getFTPUploadFolderByDate(Date date) {
		Date now = new Date();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String folder = df.format(now);
		return folder;
	}

	/**
	 * 将本地文件上传到FTP服务器上 *
	 *//*
	public static void upLoadFromProduction(String url,// FTP服务器hostname
			int port,// FTP服务器端口
			String username, // FTP登录账号
			String password, // FTP登录密码
			String path, // FTP服务器保存目录
			String filename, // 上传到FTP服务器上的文件名
			String orginfilename // 输入流文件名
	   ) {
		try {
			FileInputStream in = new FileInputStream(new File(orginfilename));
			boolean flag = uploadFile(url, port, username, password, path,filename, in);
			System.out.println(flag);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
     //测试
	/*public static void main(String[] args) {
		
		upLoadFromProduction("192.168.13.32", 21, "hanshibo", "han", "韩士波测试", "hanshibo.doc", "E:/temp/H2数据库使用.doc");
	}*/
}
