package com.uce360.lzsz.psychology.resourcelib.util;

public class FileUtil {

	public static String getSuffix(String fileName) {
		if( fileName == null || fileName.indexOf(".") == -1){
			return null;
		}
		
		return fileName.substring(fileName.indexOf(".")+1);
	}

	public static void main(String[] args) {
		System.out.println(getSuffix("dsfjpeg"));
	}
}
