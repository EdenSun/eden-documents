package com.uce360.lzsz.psychology.resourcelib.mapper;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.model.ResourceResourceCategory;

public interface IResourceResourceCategoryMapper {

	/**
	 * 删除指定资源ID的记录
	 * @param resID 资源ID
	 */
	void delByResID(@Param("resID")Long resID);

	/**
	 * 保存
	 * @param rrc
	 */
	void save(@Param("rrc")ResourceResourceCategory rrc);

}
