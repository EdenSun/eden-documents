package com.uce360.lzsz.psychology.resourcelib.controller.front;

import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;

@RequestMapping("/auth/json")
@Controller
public class AuthJSONController extends BaseController{
	@Autowired
	private IUserService userService;
	
	@RequestMapping("/doLogin")
	@ResponseBody
	public ViewDTO<Boolean> doLogin(
		HttpSession session,
		String account,
		String password,
		String validCode
		){
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		//检查验证码
		String sessionValidCode = session.getAttribute(Constants.SESSION_KEY_VALID_CODE)==null? null : (String)session.getAttribute(Constants.SESSION_KEY_VALID_CODE); 
		if( sessionValidCode != null ){
			if( !sessionValidCode.toLowerCase().equals(validCode.toLowerCase()) ){
				view.setCode(ViewDTO.CODE_FAIL);
				view.setData(false);
				view.setMsg("验证码不正确");
				return view;
			}
		}
		
		UsernamePasswordToken token = new UsernamePasswordToken(account, password);
		token.setRememberMe(false);
		Subject currentUser = SecurityUtils.getSubject();
		
		try {
			currentUser.login(token);
			
			//登录成功
			User user = userService.get(account, password);
			if( user != null ){
				session.setAttribute(Constants.SESSION_ID_LOGIN_USER, user);
				
				view.setCode(ViewDTO.CODE_SUCCESS);
				view.setData(true);
				view.setMsg("登录成功");
				return view;
			}else{
				view.setCode(ViewDTO.CODE_FAIL);
				view.setData(false);
				view.setMsg("用户名或密码不正确");
				return view;
			}
			
		} catch (AuthenticationException e) {
			log.error("登录失败",e);
			view.setCode(ViewDTO.CODE_FAIL);
			view.setData(false);
			view.setMsg("登录失败");
			return view;
		}
	}
	
	@RequestMapping("/doLogout")
	@ResponseBody
	public ViewDTO<Boolean> doLogout(
		HttpSession session
		){
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Subject currentUser = SecurityUtils.getSubject();
		
		currentUser.logout();
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("登出成功");
		return view;
	}
	
	
	@RequestMapping("/isLogin")
	@ResponseBody
	public ViewDTO<Boolean> isLogin(
		HttpSession session
		){
		Subject currentUser = SecurityUtils.getSubject();
		
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		boolean isLogin = currentUser.isAuthenticated();

		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(isLogin);
		view.setMsg("success");
		return view;
	}
}
