package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddElectiveCourseParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddAssignmentParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IElectiveCourseService {

	/**
	 * 查询用户所有选课
	 * @param uid
	 * @return
	 * @throws ServiceException
	 */
	List<ElectiveCourseDTO> listAllByUserID(Long uid)throws ServiceException;

	/**
	 * 根据课程ID获取课程ViewDTO 
	 * @param cid 课程ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ElectiveCourseDTO> getViewByID(Long cid)throws ServiceException;

	/**
	 * 分页查询指定用户创建的课程
	 * @param uid 创建用户ID
	 * @param pager 分页数据
	 * @return 
	 * @throws ServiceException
	 */
	ViewDTO<ElectiveCourseListDTO> listElectiveCourseByUID(Long uid,
			PagerDTO pager)throws ServiceException;

	/**
	 * 删除选课
	 * @param id 选课ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delElectiveCourse(Long id)throws ServiceException;

	/**
	 * 添加选课
	 * @param param
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addElectiveCourse(AddElectiveCourseParam param)throws ServiceException;

	/**
	 * 添加作业
	 * @param param 参数对象
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addAssignment(AddAssignmentParam param)throws ServiceException;

	/**
	 * 查询所有选课列表
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<ElectiveCourseDTO>> listAll()throws ServiceException;

	/**
	 * 更新选课公告
	 * @param ecid 选课ID
	 * @param description 公告
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> updateECDesc(Long ecid, String description)throws ServiceException;

}
