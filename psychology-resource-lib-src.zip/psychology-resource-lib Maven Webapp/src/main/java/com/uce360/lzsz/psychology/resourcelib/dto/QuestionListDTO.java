package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class QuestionListDTO {
	private List<QuestionDTO> questions;
	private PagerDTO pager;
	public List<QuestionDTO> getQuestions() {
		return questions;
	}
	public void setQuestions(List<QuestionDTO> questions) {
		this.questions = questions;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
	
}
