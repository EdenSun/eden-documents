package com.uce360.lzsz.psychology.resourcelib.controller.front;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;

@RequestMapping("/res/json")
@Controller
public class ResourceJSONController {

	@Autowired
	private IResourceService resourceService;
	
	@RequestMapping("/reslist")
	@ResponseBody
	public ViewDTO<ResourceListDTO> reslist(
		Long categoryID,
		PagerDTO pager
		){
		ViewDTO<ResourceListDTO> view = resourceService.listResourceByCategory(categoryID,2,pager);
		
		return view;
	}
	
	
	@RequestMapping("/reslistByChannel")
	@ResponseBody
	public ViewDTO<List<ResourceDTO>> reslistByChannel(
		Long channelID
		){
		ViewDTO<List<ResourceDTO>> view = resourceService.listResourceByChannel(channelID);
		
		return view;
	}
	
	@RequestMapping("/latest")
	@ResponseBody
	public ViewDTO<List<ResourceDTO>> latest(
		int count
		){
		ViewDTO<List<ResourceDTO>> view = resourceService.listLatest(count);
		
		return view;
	}
	
	
}
