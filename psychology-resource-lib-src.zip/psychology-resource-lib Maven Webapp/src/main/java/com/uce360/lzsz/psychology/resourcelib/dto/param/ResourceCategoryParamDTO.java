package com.uce360.lzsz.psychology.resourcelib.dto.param;


public class ResourceCategoryParamDTO {
	private String name;
	private Integer level;
	private Long parentID;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Long getParentID() {
		return parentID;
	}
	public void setParentID(Long parentID) {
		this.parentID = parentID;
	}
	
}
