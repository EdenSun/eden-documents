package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.UserParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IUserMapper;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserMapper userMapper;
	
	@Override
	public User get(String account, String password) throws ServiceException {
		return userMapper.getByAccountAndPassword(account,password);
	}

	@Override
	public ViewDTO<Boolean> delUser(Long userID) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		userMapper.delUser(userID);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

	@Override
	public ViewDTO<UserDTO> addUser(UserParamDTO userParam)
			throws ServiceException {
		ViewDTO<UserDTO> view = new ViewDTO<UserDTO>();
		
		User user = trans2User( userParam );
		
		userMapper.save(user);
		
		UserDTO userDTO = trans2UserDTO(user);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(userDTO);
		view.setMsg("成功添加用户");
		return view;
	}

	private UserDTO trans2UserDTO(User user) {
		if( user == null ){
			return null;
		}
		UserDTO userDTO = new UserDTO();
		
		BeanUtils.copyProperties(user, userDTO);
		
		return userDTO;
	}

	private User trans2User(UserParamDTO userParam) {
		if( userParam == null ){
			return null;
		}
		User user = new User();
		
		BeanUtils.copyProperties(userParam, user);
		
		return user;
	}

	@Override
	public ViewDTO<Boolean> updateUser(UserParamDTO userParam)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		User user = userMapper.getByID(userParam.getId());
		
		if( user != null ){
			BeanUtils.copyProperties(userParam, user);
			userMapper.update(user);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("成功更新用户");
			return view;
		}
		
		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("更新用户失败");
		return view;
	}

	@Override
	public ViewDTO<UserListDTO> listUser(PagerDTO pager)
			throws ServiceException {
		ViewDTO<UserListDTO> view = new ViewDTO<UserListDTO>();
		UserListDTO userListDTO = new UserListDTO();
		
		List<User> userList = userMapper.listUser(pager);
		List<UserDTO> userDTOList = trans2UserDTOList(userList);
		userListDTO.setUsers(userDTOList);
		
		int totalCount = userMapper.listUserCount();
		pager.setTotalCount( totalCount );
		userListDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(userListDTO);
		view.setMsg("成功查询用户列表");
		return view;
	}

	private List<UserDTO> trans2UserDTOList(List<User> userList) {
		if( userList == null ){
			return null;
		}
		List<UserDTO> userDTOList = new ArrayList<UserDTO>();
		UserDTO userDTO = null;
		
		for( User user : userList ){
			userDTO = trans2UserDTO(user);
			
			if( userDTO != null ){
				userDTOList.add(userDTO);
			}
		}
		
		return userDTOList;
	}

	@Override
	public UserDTO getUserDTOByID(Long uid) throws ServiceException {
		User user = userMapper.getByID(uid);
		
		UserDTO dto = trans2UserDTO(user);
		
		return dto;
	}

	@Override
	public ViewDTO<List<UserDTO>> listAllStudent() throws ServiceException {
		ViewDTO<List<UserDTO>> view = new ViewDTO<List<UserDTO>>();
		
		List<User> userList = userMapper.listAllByRoleType( User.ROLE_TYPE_STUDENT );
		List<UserDTO> dtoList = trans2UserDTOList(userList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<List<UserDTO>> listAllTeacher() throws ServiceException {
ViewDTO<List<UserDTO>> view = new ViewDTO<List<UserDTO>>();
		
		List<User> userList = userMapper.listAllByRoleType( User.ROLE_TYPE_TEACHER );
		List<UserDTO> dtoList = trans2UserDTOList(userList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public List<UserDTO> listAllStudentByECID(Long ecid)
			throws ServiceException {
		List<User> users = userMapper.listAllStudentByECID(ecid);
		List<UserDTO> dtoList = trans2UserDTOList(users);
		
		return dtoList;
	}

	@Override
	public User getUserByID(Long uid) throws ServiceException {
		return userMapper.getByID(uid);
	}

	@Override
	public void addUsers(List<User> userList) throws ServiceException {
		if( userList != null ){
			for(User user : userList ){
				userMapper.save(user);
			}
		}
	}
	
}
