package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.CatalogDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CatalogTreeDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CourseParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface ICourseService {

	/**
	 * 分页查询所有课程
	 * @param pager 分页数据
	 * @return 返回课程列表
	 * @throws ServiceException
	 */
	ViewDTO<CourseListDTO> listCourse(PagerDTO pager)throws ServiceException;

	/**
	 * 根据ID查询课程
	 * @param courseID
	 * @return
	 * @throws ServiceException
	 */
	CourseDTO getByID(Long courseID)throws ServiceException;

	/**
	 * 查询课程列表
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CourseDTO>> listCourse()throws ServiceException;

	/**
	 * 添加课程
	 * @param courseParam
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<CourseDTO> addCourse(CourseParamDTO courseParam)throws ServiceException;

	/**
	 * 级联查询课程的目录
	 * @param courseID 课程ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CatalogTreeDTO>> listCourseCatalog(Long courseID)throws ServiceException;

	/**
	 * 查询所有课程
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CourseDTO>> listAllCourse()throws ServiceException;

	/**
	 * 删除课程
	 * @param courseID 课程ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delCourse(Long courseID)throws ServiceException;

	/**
	 * 查询所有首页展示的课程
	 * @return
	 * @throws ServiceException
	 */
	List<CourseDTO> listAllHomepageCourse()throws ServiceException;

	/**
	 * 添加或更新课程
	 * @param courseParam
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<CourseDTO> addOrUpdateCourse(CourseParamDTO courseParam)throws ServiceException;


}
