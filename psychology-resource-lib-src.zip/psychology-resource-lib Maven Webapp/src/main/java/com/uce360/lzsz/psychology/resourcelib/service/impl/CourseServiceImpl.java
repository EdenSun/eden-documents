package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.CatalogDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CatalogTreeDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CourseParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.ICatalogMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.ICourseMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceCatalogMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Catalog;
import com.uce360.lzsz.psychology.resourcelib.model.Course;
import com.uce360.lzsz.psychology.resourcelib.service.ICourseService;

@Service
public class CourseServiceImpl implements ICourseService {
	@Autowired
	private ICourseMapper courseMapper;
	
	@Autowired
	private ICatalogMapper catalogService;
	
	@Override
	public ViewDTO<CourseListDTO> listCourse(PagerDTO pager)
			throws ServiceException {
		ViewDTO<CourseListDTO> view = new ViewDTO<CourseListDTO>();
		CourseListDTO courseListDTO = new CourseListDTO();
		
		List<Course> courseList = courseMapper.listCourse(pager);
		List<CourseDTO> courseDTOList = trans2CourseDTOList(courseList);
		
		courseListDTO.setCourses(courseDTOList);
		
		int totalCount = courseMapper.getCourseCount();
		pager.setTotalCount(totalCount);
		courseListDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(courseListDTO);
		view.setMsg("课程查询成功");
		return view;
	}

	private List<CourseDTO> trans2CourseDTOList(List<Course> courseList) {
		if( courseList == null ){
			return null;
		}
		List<CourseDTO> dtoList = new ArrayList<CourseDTO>();
		CourseDTO dto = null;
		
		for( Course course : courseList ){
			dto = trans2CourseDTO(course);
			if( dto != null){
				dtoList.add(dto);
			}
		}
		
		return dtoList;
	}

	private CourseDTO trans2CourseDTO(Course course) {
		if( course  == null ){
			return null;
		}
		
		CourseDTO dto = new CourseDTO();
		BeanUtils.copyProperties(course, dto);
		
		return dto;
	}

	@Override
	public CourseDTO getByID(Long courseID) throws ServiceException {
		Course course = courseMapper.getByID(courseID);
		
		CourseDTO dto = trans2CourseDTO(course);
		
		return dto;
	}

	@Override
	public ViewDTO<List<CourseDTO>> listCourse() throws ServiceException {
		ViewDTO<List<CourseDTO>> view = new ViewDTO<List<CourseDTO>>();
		
		List<Course> courseList = courseMapper.listCourse(null);
		
		List<CourseDTO> dtoList = trans2CourseDTOList(courseList);

		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<CourseDTO> addCourse(CourseParamDTO courseParam)
			throws ServiceException {
		ViewDTO<CourseDTO> view = new ViewDTO<CourseDTO>();
		Course course = new Course();

		BeanUtils.copyProperties(courseParam, course);
		course.setCategoryID(7L);
		if( courseParam.getIsShowOnHomepageBoolean() == null || courseParam.getIsShowOnHomepageBoolean().booleanValue() == false ){
			course.setIsShowOnHomepage(Course.IS_SHOW_ON_HOMEPAGE_FALSE);
		}else{
			course.setIsShowOnHomepage(Course.IS_SHOW_ON_HOMEPAGE_TRUE);
		}
		
		courseMapper.save(course);
		
		CourseDTO dto = trans2CourseDTO(course);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("添加课程");
		return view;
	}

	
	@Override
	public ViewDTO<List<CatalogTreeDTO>> listCourseCatalog(Long courseID)
			throws ServiceException {
		ViewDTO<List<CatalogTreeDTO>> view = new ViewDTO<List<CatalogTreeDTO>>();
		
		List<Catalog> chapterList = catalogService.listChapterByCourseID(courseID);

		List<CatalogTreeDTO> catalogTreeDTOList = trans2CatalogTreeDTOList(chapterList);
		
		if( catalogTreeDTOList != null && catalogTreeDTOList.size() > 0 ){
			iteratorCatalogTree( catalogTreeDTOList , 0 );
		}
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(catalogTreeDTOList);
		view.setMsg("查询成功");
		return view;
	}

	private List<CatalogTreeDTO> trans2CatalogTreeDTOList(
			List<Catalog> catalogList) {
		if( catalogList == null ){
			return null;
		}
		List<CatalogTreeDTO> dtoList = new ArrayList<CatalogTreeDTO>();
		CatalogTreeDTO dto = null;
		
		for( Catalog c : catalogList ){
			dto = trans2CatalogTreeDTO(c);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		
		return dtoList;
	}

	private CatalogTreeDTO trans2CatalogTreeDTO(Catalog c) {
		if( c== null ){
			return null;
		}
		CatalogTreeDTO dto = new CatalogTreeDTO();
		
		BeanUtils.copyProperties(c, dto);
		
		return dto;
	}

	private void iteratorCatalogTree(List<CatalogTreeDTO> catalogTreeDTOList,
			int index) {
		if( index >= catalogTreeDTOList.size() ){
			return;
		}
		
		CatalogTreeDTO curDTO = catalogTreeDTOList.get(index);

		if( curDTO != null ){
			List<CatalogTreeDTO> subs = trans2CatalogTreeDTOList( catalogService.listByParent(curDTO.getId()) );
			
			if( subs == null || subs.size() == 0 ){
				return;
			}else {
				curDTO.setSubs(subs);

				for(int i = 0 ;i < subs.size() ; i++ ){
					iteratorCatalogTree(subs,i);
				}
			}
			
			iteratorCatalogTree(catalogTreeDTOList,index+1);
		}else{
			return ;
		}
	}

	
	@Override
	public ViewDTO<List<CourseDTO>> listAllCourse() throws ServiceException {
		ViewDTO<List<CourseDTO>> view = new ViewDTO<List<CourseDTO>>();
		List<Course> courseList = courseMapper.listAll();
		
		List<CourseDTO> dtoList = trans2CourseDTOList(courseList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delCourse(Long courseID) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO();
		courseMapper.delCourse(courseID);
		
		//删除课程章节以及子目录
		catalogService.delByCourse( courseID );
		
		view.setCode( ViewDTO.CODE_SUCCESS );
		view.setData( true );
		view.setMsg( "删除成功" );
		return view;
	}

	@Override
	public List<CourseDTO> listAllHomepageCourse() throws ServiceException {
		
		List<Course> courseList = courseMapper.listAllHomepageCourse();
		
		List<CourseDTO> courseDTOList = trans2CourseDTOList(courseList);
		
		return courseDTOList;
	}

	@Override
	public ViewDTO<CourseDTO> addOrUpdateCourse(CourseParamDTO courseParam)
			throws ServiceException {
		ViewDTO<CourseDTO> view = new ViewDTO<CourseDTO>();
		Course course = new Course();

		BeanUtils.copyProperties(courseParam, course);
		course.setCategoryID(7L);
		if( courseParam.getIsShowOnHomepageBoolean() == null || courseParam.getIsShowOnHomepageBoolean().booleanValue() == false ){
			course.setIsShowOnHomepage(Course.IS_SHOW_ON_HOMEPAGE_FALSE);
		}else{
			course.setIsShowOnHomepage(Course.IS_SHOW_ON_HOMEPAGE_TRUE);
		}
		
		if( course.getId() == null ){
			//添加
			courseMapper.save(course);
		}else{
			//更新
			courseMapper.update(course);
		}
		
		CourseDTO dto = trans2CourseDTO(course);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("添加/更新课程成功");
		return view;
	}
	
}
