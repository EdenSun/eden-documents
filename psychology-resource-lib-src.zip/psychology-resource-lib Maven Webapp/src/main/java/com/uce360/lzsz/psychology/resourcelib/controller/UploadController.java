package com.uce360.lzsz.psychology.resourcelib.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.uce360.lzsz.psychology.resourcelib.dto.UploadFileDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;
import com.uce360.lzsz.psychology.resourcelib.util.ExcelReader;
import com.uce360.lzsz.psychology.resourcelib.util.FileUtil;
import com.uce360.lzsz.psychology.resourcelib.util.UploadUtil;
@Controller
public class UploadController {
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	@ResponseBody
	public UploadFileDTO uploadImg(@RequestParam("fileUpload") CommonsMultipartFile file)
			throws IllegalStateException, IOException {
		UploadFileDTO fileDTO = new UploadFileDTO();
		fileDTO.setContentType(file.getContentType());
		fileDTO.setSize(file.getSize());
		
		fileDTO.setOriginalFilename(file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf(".")) );
		
		String suffix = FileUtil.getSuffix(file.getOriginalFilename());

        // 判断文件是否存在  
        if (!file.isEmpty()) { 
        	String fileName = null;
        	if( suffix != null ){
        		fileName = UUID.randomUUID().toString() + "." + suffix;
        	}else{
        		fileName = UUID.randomUUID().toString();
        	}
        	String path = UploadUtil.uploadFile(fileName, file.getInputStream());
            
        	fileDTO.setBasePath(Constants.FTP_HTTP_BASE_PATH);
        	fileDTO.setPath(path);
        }  
        
        return fileDTO;  
	}
	
	/**
	 * 批量导入学生时上传学生列表excel
	 * @param file
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping(value = "/uploadStudentSheet", method = RequestMethod.POST)
	@ResponseBody
	public ViewDTO<Boolean> uploadStudentSheet(@RequestParam("file") CommonsMultipartFile file)
			throws IllegalStateException, IOException {
		ViewDTO<Boolean> view= new ViewDTO<Boolean>();
		ExcelReader excelReader = new ExcelReader();
		String[] title = excelReader.readExcelTitle(file.getInputStream());
		for (String s : title) {
            System.out.print(s + " ");
        }
		
		Map<Integer, String> map = excelReader.readExcelContent(file.getInputStream());
		
		List<User> userList = new ArrayList<User>();
		User user = null;
        for (int i = 1; i <= map.size(); i++) {
        	String curRow = map.get(i);
        	String[] cells = curRow.split("-");
        	
        	if( cells.length > 0 ){
        		user = new User();
        		String account = cells[0];
        		String realName = cells[1];
        		String password = cells[2];
        		String email = cells[3];
        		String mobilePhone = cells[4];
        		String sex = cells[5];
        		String studentID = cells[6];
        		String startYear = cells[7];
        		
        		user.setAccount(account);
        		user.setRealName(realName);
        		user.setPassword(password);
        		user.setEmail(email);
        		user.setMobilePhone(mobilePhone);
        		if( sex != null ){
        			if( sex.trim().equals("男") ){
        				user.setSex(User.SEX_BOY);
        			}else if( sex.trim().equals("女") ){
        				user.setSex(User.SEX_GIRL);
        			}
        		}
        		user.setStudentID(studentID);
        		user.setStartYear(startYear);
        		user.setRoleType(User.ROLE_TYPE_STUDENT);
        		
        		userList.add(user);
        	}
        	
        }
        if(userList.size() > 0 ){
        	userService.addUsers(userList);
        }
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("导入成功");
		return view;
	}
}

