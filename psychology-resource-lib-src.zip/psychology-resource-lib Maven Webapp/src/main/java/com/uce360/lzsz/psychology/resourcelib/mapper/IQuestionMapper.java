package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.model.Question;

public interface IQuestionMapper {

	List<Question> listQuestion(
			@Param("param")ListQuestionParam param, 
			@Param("pager")PagerDTO pager);

	int getQuestionCount(@Param("param")ListQuestionParam param);

	void save(@Param("question")Question question);

	Question getByID(@Param("qid")Long qid);

	void delByID(@Param("id")Long id);

}
