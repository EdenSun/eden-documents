package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.CatalogDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CatalogParamDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CourseParamDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListResParamDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceParamDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.ICatalogService;
import com.uce360.lzsz.psychology.resourcelib.service.ICourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;

@RequestMapping("/admin/coursecenter")
@Controller
public class CourseManageController extends BaseController{

	@Autowired
	private ICourseService courseService;
	
	@Autowired
	private ICatalogService catalogService;
	
	@Autowired
	private IResourceService resourceService;
	
	@RequestMapping("/listCourse")
	@ResponseBody
	public ViewDTO<List<CourseDTO>> listCourse(){
		ViewDTO<List<CourseDTO>> view = courseService.listCourse();
		
		return view;
	}
	
	@RequestMapping("/addCourse")
	@ResponseBody
	public ViewDTO<CourseDTO> addCourse(
			HttpSession session,
			@ModelAttribute("courseParam")CourseParamDTO courseParam
		){
		User user = getLoginUser(session);
		
		courseParam.setCreatorID(user.getId());
		ViewDTO<CourseDTO> view = courseService.addCourse(courseParam);
		
		return view;
	}
	
	@RequestMapping("/addOrUpdateCourse")
	@ResponseBody
	public ViewDTO<CourseDTO> addOrUpdateCourse(
			HttpSession session,
			@ModelAttribute("courseParam")CourseParamDTO courseParam
		){
		User user = getLoginUser(session);
		
		courseParam.setCreatorID(user.getId());
		ViewDTO<CourseDTO> view = courseService.addOrUpdateCourse(courseParam);
		
		return view;
	}
	
	/**
	 * 查询所有章
	 * @param courseID
	 * @return
	 */
	@RequestMapping("/listChapterByCourse")
	@ResponseBody
	public ViewDTO<List<CatalogDTO>> listChapter(
			Long courseID
		){
		ViewDTO<List<CatalogDTO>> view = catalogService.listChapterByCourse(courseID);
		
		return view;
	}
	
	
	@RequestMapping("/addCatalog")
	@ResponseBody
	public ViewDTO<CatalogDTO> addCatalog(
			HttpSession session,
			@ModelAttribute("catalogParam")CatalogParamDTO catalogParam
		){
		ViewDTO<CatalogDTO> view = catalogService.addCatalog(catalogParam);
		
		return view;
	}
	
	/**
	 * 查询所有节
	 * @param chapterID
	 * @return
	 */
	@RequestMapping("/listSectionByChapter")
	@ResponseBody
	public ViewDTO<List<CatalogDTO>> listSectionByChapter(
			Long chapterID
		){
		ViewDTO<List<CatalogDTO>> view = catalogService.listSection(chapterID);
		
		return view;
	}
	
	/**
	 * 查询所有节
	 * @param chapterID
	 * @return
	 */
	@RequestMapping("/listSubDirBySection")
	@ResponseBody
	public ViewDTO<List<CatalogDTO>> listSubDirBySection(
			Long sectionID
		){
		ViewDTO<List<CatalogDTO>> view = catalogService.listSubDir(sectionID);
		
		return view;
	}
	
	
	@RequestMapping("/listRes")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listRes(
			@ModelAttribute("resParamDTO")ListResParamDTO resParamDTO,
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<ResourceListDTO> view = resourceService.listResource(resParamDTO,pager);
		
		return view;
	}
	
	@RequestMapping("/addResToSubDir")
	@ResponseBody
	public ViewDTO<Boolean> addResToSubDir(
			Long catalogID,
			Long resID
		){
		ViewDTO<Boolean> view = resourceService.addResToSubDir(catalogID,resID);
		
		return view;
	}
	
	
	@RequestMapping("/delCourse")
	@ResponseBody
	public ViewDTO<Boolean> delCourse(
			Long courseID
		){
		ViewDTO<Boolean> view = courseService.delCourse(courseID);
		
		return view;
	}
	
	
	@RequestMapping("/delChapter")
	@ResponseBody
	public ViewDTO<Boolean> delChapter(
			Long chapterID
		){
		ViewDTO<Boolean> view = catalogService.delChapter(chapterID);
		
		return view;
	}
	
}
