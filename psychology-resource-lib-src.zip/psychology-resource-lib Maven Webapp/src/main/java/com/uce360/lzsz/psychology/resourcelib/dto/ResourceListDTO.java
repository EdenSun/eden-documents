package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class ResourceListDTO {
	private List<ResourceDTO> resources;
	private PagerDTO pager;
	public List<ResourceDTO> getResources() {
		return resources;
	}
	public void setResources(List<ResourceDTO> resources) {
		this.resources = resources;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
