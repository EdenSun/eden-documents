package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListResParamDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.model.Resource;

public interface IResourceService {

	/**
	 * 分类查询资源，按照资源上传时间倒序
	 * @param categoryID 分类ID
	 * @param auditStatus 审核状态，若是null，不限制
	 * @param pager 分页信息
	 * @return 返回指定分类下的资源列表
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listResourceByCategory(Long categoryID, Integer auditStatus,PagerDTO pager)throws ServiceException;

	/**
	 * 查询指定频道中的所有资源列表
	 * @param channelID 频道ID
	 * @return 返回指定频道中的所有资源列表
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceDTO>> listResourceByChannel(Long channelID)throws ServiceException;

	/**
	 * 查询指定条数的最新资源
	 * @param count 数量
	 * @return 返回指定条数的最新资源
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceDTO>> listLatest(int count)throws ServiceException;

	/**
	 * 添加指定资源到指定频道
	 * @param channelID 频道ID
	 * @param resID 资源ID
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addResToChannel(Long channelID, Long resID)throws ServiceException;

	/**
	 * 从指定频道删除指定资源
	 * @param channelID 频道ID
	 * @param resID 资源ID
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delFromChannel(Long channelID, Long resID)throws ServiceException;

	/**
	 * 关键字检索在线阅读文档 
	 * @param keywords 搜素关键字
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> searchOnlineResByKeywords(String keywords,
			PagerDTO pager)throws ServiceException;

	/**
	 * 根据频道ID查询频道中的资源
	 * @param channelID 频道ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listResByChannel(Long channelID, PagerDTO pager)throws ServiceException;

	/**
	 * 保存资源
	 * @param resource 资源对象
	 * @return 返回插入的资源
	 * @throws ServiceException
	 */
	ViewDTO<ResourceDTO> addResource(ResourceParamDTO resource)throws ServiceException;

	/**
	 * 审核资源
	 * @param resourceID 资源ID
	 * @param auditStatus 审核状态
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> auditRes(Long resourceID, int auditStatus)throws ServiceException;

	/**
	 * 更新资源
	 * @param resource 资源对象
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> updateRes(ResourceParamDTO resource)throws ServiceException;

	/**
	 * 根据资源ID删除资源
	 * @param resourceID 资源ID
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delRes(Long resourceID)throws ServiceException;

	/**
	 * 创建资源
	 * @param resource 资源对象
	 * @return 
	 * @throws ServiceException
	 */
	ResourceDTO addResource(Resource resource)throws ServiceException;

	/**
	 * 分页查询指定分类下的资源列表
	 * @param cateID 分类ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listResByCategoryID(Long cateID,Integer auditStatus, PagerDTO pager)throws ServiceException;

	/**
	 * 获取指定分类下的所有资源列表
	 * @param cateID 分类ID
	 * @return 返回指定分类下的所有资源列表
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listAllResByCategoryID(Long cateID,Integer auditStatus)throws ServiceException;

	/**
	 * 分页查询资源列表
	 * @param resParamDTO 查询参数
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listResource(ListResParamDTO resParamDTO,
			PagerDTO pager)throws ServiceException;

	/**
	 * 资源添加到目录
	 * @param catalogID 目录ID
	 * @param resID 资源ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addResToSubDir(Long catalogID, Long resID)throws ServiceException;

	/**
	 * 获取目录中的资源列表
	 * @param catalogID 目录ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceDTO>> listAllResByCatalog(Long catalogID)throws ServiceException;

	/**
	 * 查询课程资源
	 * @param courseID 课程ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<ResourceListDTO> listResByCourse(Long courseID, PagerDTO pager)throws ServiceException;

	/**
	 * 查询
	 * @param resourceID
	 * @return
	 * @throws ServiceException
	 */
	ResourceDTO getResourceDTOByID(Long resourceID)throws ServiceException;

	/**
	 * 查询指定用户上传的资源列表
	 * @param uid 用户ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	List<ResourceDTO> listResByUploaderUID(Long uid, PagerDTO pager)throws ServiceException;

	/**
	 * 查询指定用户上传的资源数量
	 * @param uid 用户ID
	 * @return 返回指定用户上传的资源数量
	 * @throws ServiceException
	 */
	int listResCountByUploaderUID(Long uid)throws ServiceException;

	/**
	 * 分页查询资源
	 * @param keywords 关键字
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ResourceListDTO listResByKeywords(String keywords, PagerDTO pager)throws ServiceException;

	/**
	 *  根据分类名称查询指定课程中的所有资源
	 * @param courseID
	 * @param catalogName
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<ResourceDTO>> listAllResByCatalogNameInCourse(Long courseID,
			String catalogName)throws ServiceException;

}
