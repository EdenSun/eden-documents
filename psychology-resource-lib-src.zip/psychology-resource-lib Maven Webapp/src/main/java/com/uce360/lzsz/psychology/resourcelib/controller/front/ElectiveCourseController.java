package com.uce360.lzsz.psychology.resourcelib.controller.front;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentDetailDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentAnswerService;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentService;
import com.uce360.lzsz.psychology.resourcelib.service.IElectiveCourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IQuestionService;

@Controller
@RequestMapping("/ucenter/ec")
public class ElectiveCourseController extends BaseController{
	@Autowired
	private IElectiveCourseService electiveCourseService;
	
	@Autowired
	private IAssignmentService assignmentService;
	
	@Autowired
	private IQuestionService questionService;
	
	@Autowired
	private IAssignmentAnswerService assignmentAnswerService;
	
	@RequestMapping("/get-course")
	@ResponseBody
	public ViewDTO<ElectiveCourseDTO> getCourse(Long cid){
		ViewDTO<ElectiveCourseDTO> view = electiveCourseService.getViewByID(cid);
		
		return view;
	}
	
	@RequestMapping("/list-assignment")
	@ResponseBody
	public ViewDTO<AssignmentListDTO> listAssignment(
			HttpSession session,
			Long cid,
			@ModelAttribute("pager")PagerDTO pager
			){
		User user = getLoginUser(session);
		ViewDTO<AssignmentListDTO> view = assignmentService.listAssignment(user.getId(),cid,pager);
		
		return view;
	}
	
	@RequestMapping("/get-assignment")
	@ResponseBody
	public ViewDTO<AssignmentDetailDTO> getAssignment(
			Long id
			){
		ViewDTO<AssignmentDetailDTO> view = assignmentService.getAssignment(id);
		
		return view;
	}
	
	@RequestMapping("/list-assignment-answer")
	@ResponseBody
	public ViewDTO<AssignmentAnswerListDTO> listAssignmentAnswer(
			Long assignmentID,
			@ModelAttribute("pager")PagerDTO pager
			){
		ViewDTO<AssignmentAnswerListDTO> view = assignmentAnswerService.listAssignmentAnswer(assignmentID,pager);
		
		return view;
	}
	
	@RequestMapping("/get-my-assignment-answer")
	@ResponseBody
	public ViewDTO<AssignmentAnswerDTO> getMyAssignmentAnswer(
			HttpSession session,
			Long assignmentID
			){
		User user = getLoginUser(session);
		
		ViewDTO<AssignmentAnswerDTO> view = assignmentAnswerService.getAssignmentAnswerByUIDAndAssignmentID(user.getId(),assignmentID);
		
		return view;
	}
	
	@RequestMapping("/submit-assignment-answer")
	@ResponseBody
	public ViewDTO<Boolean> submitAssignmentAnswer(
			HttpSession session,
			Long assignmentID,
			String assignmentAnswerContent
			){
		User user = getLoginUser(session);
		
		ViewDTO<Boolean> view = assignmentAnswerService.saveAssignmentAnswer(user.getId(),assignmentID,assignmentAnswerContent);
		
		return view;
	}
	
	
	
	@RequestMapping("/list-question")
	@ResponseBody
	public ViewDTO<QuestionListDTO> listQuestion(
			HttpSession session,
			@ModelAttribute("param")ListQuestionParam param,
			@ModelAttribute("pager")PagerDTO pager
			){
		User user = getLoginUser(session);
		
		param.setUid(user.getId());
		ViewDTO<QuestionListDTO> view = questionService.listQuestion(param,pager);
		
		return view;
	}
	
	@RequestMapping("/add-question")
	@ResponseBody
	public ViewDTO<QuestionDTO> addQuestion(
			HttpSession session,
			AddQuestionParam param
			){
		User user = getLoginUser(session);
		
		param.setUid(user.getId());
		ViewDTO<QuestionDTO> view = questionService.addQuestion(param);
		
		return view;
	}
	
	@RequestMapping("/get-question-detail")
	@ResponseBody
	public ViewDTO<QuestionDTO> getQuestionDetail(
			Long id
			){
		ViewDTO<QuestionDTO> view = questionService.getQuestion(id);
		
		return view;
	}
	
	@RequestMapping("/list-question-answer")
	@ResponseBody
	public ViewDTO<QuestionAnswerListDTO> listQuestionAnswer(
			Long qid,
			@ModelAttribute("pager")PagerDTO pager
			){
		ViewDTO<QuestionAnswerListDTO> view = questionService.listQuestionAnswer(qid,pager);
		
		return view;
	}
	
	@RequestMapping("/submit-question-answer")
	@ResponseBody
	public ViewDTO<Boolean> submitQuestionAnswer(
			HttpSession session,
			Long qid,
			String content
			){
		User user = getLoginUser(session);
		
		ViewDTO<Boolean> view = questionService.submitQuestionAnswer(user.getId(),qid,content);
		
		return view;
	}
	
	@RequestMapping("/update-ec-desc")
	@ResponseBody
	public ViewDTO<Boolean> updateECDesc(
			HttpSession session,
			Long id,
			String description
			){
		ViewDTO<Boolean> view = electiveCourseService.updateECDesc(id,description);
		
		return view;
	}
	

}
