package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentDetailDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IAssignmentService {
	/**
	 * 分页查询指定课程的作业数据
	 * @param uid 用户ID
	 * @param cid 课程ID
	 * @param pager 分页数据
	 * @return 分页返回指定课程的作业数据
	 * @throws ServiceException
	 */
	ViewDTO<AssignmentListDTO> listAssignment(Long uid, Long cid, PagerDTO pager)throws ServiceException;


	/**
	 * 查询用户是否已经对作业作答
	 * @param uid 用户ID
	 * @param assignmentID 作业ID
	 * @return 已经作答返回true，否则返回false
	 * @throws ServiceException
	 */
	boolean isSubmit(Long uid, Long assignmentID)throws ServiceException;


	/**
	 * 根据ID获取作业答案
	 * @param id 作业ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<AssignmentDetailDTO> getAssignment(Long id)throws ServiceException;


	/**
	 * 根据ID 删除作业
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delByID(Long id)throws ServiceException;


	ViewDTO<AssignmentListDTO> listAssignmentForAdmin(Long uid, Long ecID,
			PagerDTO pager)throws ServiceException;


}
