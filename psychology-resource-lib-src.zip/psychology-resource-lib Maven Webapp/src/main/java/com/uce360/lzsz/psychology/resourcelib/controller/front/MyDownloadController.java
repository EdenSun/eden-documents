package com.uce360.lzsz.psychology.resourcelib.controller.front;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.DownloadListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IDownloadService;

@Controller
@RequestMapping("/ucenter/download")
public class MyDownloadController extends BaseController{
	@Autowired
	private IDownloadService downloadService;
	
	@RequestMapping("/list-my-download")
	@ResponseBody
	public ViewDTO<DownloadListDTO> listMyDowloads(
			HttpSession session,
			@ModelAttribute("pager")PagerDTO pager
			){
		User user = getLoginUser(session);
		
		ViewDTO<DownloadListDTO> view = downloadService.listByUserID(user.getId(),pager);
		
		return view;
	}
	
	@RequestMapping("/del")
	@ResponseBody
	public ViewDTO<Boolean> del(
			Long downloadID
			){
		ViewDTO<Boolean> view = downloadService.delByID(downloadID);
		
		return view;
	}
	
	@RequestMapping("/addMyDownload")
	@ResponseBody
	public ViewDTO<Boolean> addMyDownload(
			HttpSession session,
			Long resID
			){
		User user = getLoginUser(session);
		
		ViewDTO<Boolean> view = downloadService.addMyDownload(user.getId(),resID);
		
		return view;
	}
	
}
