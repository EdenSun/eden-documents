package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.model.Catalog;

public interface ICatalogMapper {

	List<Catalog> listChapterByCourseID(@Param("courseID")Long courseID);

	List<Catalog> listSectionByChapterID(@Param("chapterID")Long chapterID);

	void save(@Param("catalog")Catalog catalog);

	List<Catalog> listByParent(@Param("parentID")Long parentID);

	Catalog getByID(@Param("catalogID")Long catalogID);

	void delByCourse(@Param("courseID")Long courseID);

	void delByID(@Param("catalogID")Long catalogID);

	/**
	 * 删除课程courseID下的，级别大于level的分类
	 * @param courseID
	 * @param level
	 */
	void delByCourseAndGtLevel(
			@Param("courseID")Long courseID, 
			@Param("level")Integer level);

}
