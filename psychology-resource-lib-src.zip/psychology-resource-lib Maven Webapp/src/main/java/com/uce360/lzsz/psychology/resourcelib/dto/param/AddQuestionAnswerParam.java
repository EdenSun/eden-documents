package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class AddQuestionAnswerParam {
	private Long questionID;
	private String content;
	private Long answerUserID;
	public Long getQuestionID() {
		return questionID;
	}
	public void setQuestionID(Long questionID) {
		this.questionID = questionID;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getAnswerUserID() {
		return answerUserID;
	}
	public void setAnswerUserID(Long answerUserID) {
		this.answerUserID = answerUserID;
	}
}
