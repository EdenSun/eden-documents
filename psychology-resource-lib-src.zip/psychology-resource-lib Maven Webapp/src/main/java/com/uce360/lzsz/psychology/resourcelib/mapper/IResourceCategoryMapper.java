package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.model.ResourceCategory;

public interface IResourceCategoryMapper {

	ResourceCategory getByLevel(
			@Param("level")Integer level);

	List<ResourceCategory> listSubCategory(
			@Param("resourceCategoryID")Long resourceCategoryID);

	void delCate(@Param("id")Long id);

	ResourceCategory getByID(@Param("id")Long id);

	void update(@Param("cate")ResourceCategory cate);

	void add(@Param("cate")ResourceCategory cate);

	ResourceCategory getMediaCateByResID(@Param("resID")Long resID);

	ResourceCategory getCourseCateByResID(@Param("resID")Long resID);


}
