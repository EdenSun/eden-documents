package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Assignment;
import com.uce360.lzsz.psychology.resourcelib.model.AssignmentAnswer;

public interface IAssignmentAnswerMapper {

	AssignmentAnswer getByUIDAndAssignmentID(
			@Param("uid")Long uid, 
			@Param("assignmentID")Long assignmentID);

	List<AssignmentAnswer> listAnswerByAssngnmentID(
			@Param("assignmentID")Long assignmentID,
			@Param("pager")PagerDTO pager);

	int listAnswerCountByAssngnmentID(
			@Param("assignmentID")Long assignmentID);

	void save(@Param("answer")AssignmentAnswer answer);

	AssignmentAnswer getByID(@Param("id")Long id);

	void update(@Param("assignmentAnswer")AssignmentAnswer assignmentAnswer);


}
