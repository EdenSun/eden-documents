package com.uce360.lzsz.psychology.resourcelib.model;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class ElectiveCourse {
	private Long id;
	private String name;
	private String description;
	private Long teacherID;
	private Long creatorID;
	private Date createTime = new Date();
	private Integer isDelete = Constants.IS_DELETE_FALSE;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(Long teacherID) {
		this.teacherID = teacherID;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
}
