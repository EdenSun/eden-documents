package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListResParamDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.ICatalogMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceCatalogMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceCategoryMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceResourceCategoryMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Catalog;
import com.uce360.lzsz.psychology.resourcelib.model.Resource;
import com.uce360.lzsz.psychology.resourcelib.model.ResourceCatalog;
import com.uce360.lzsz.psychology.resourcelib.model.ResourceCategory;
import com.uce360.lzsz.psychology.resourcelib.model.ResourceResourceCategory;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;
import com.uce360.lzsz.psychology.resourcelib.util.ResourceUtil;

@Service
public class ResourceServiceImpl implements IResourceService {

	@Autowired
	private IUserService userService;
	
	@Autowired
	private IResourceMapper resourceMapper;
	
	@Autowired
	private IResourceCategoryMapper resourceCategoryMapper;

	@Autowired
	private ICatalogMapper catalogMapper;
	
	@Autowired
	private IResourceCatalogMapper resourceCatalogMapper;
	
	@Autowired
	private IResourceResourceCategoryMapper resourceResourceCategoryMapper;
	@Override
	public ViewDTO<ResourceListDTO> listResourceByCategory(Long categoryID, Integer auditStatus,PagerDTO pager)
			throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO dto = new ResourceListDTO();
		
		List<Resource> resList = resourceMapper.listByCategory(categoryID,auditStatus,pager);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		dto.setResources(resDTOList);
		
		int totalCount = resourceMapper.listCountByCategory(categoryID,auditStatus);
		pager.setTotalCount(totalCount);
		dto.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("成功获取资源列表");
		return view;
	}

	private List<ResourceDTO> trans2ResourceDTOList(List<Resource> resList) {
		if( resList == null ){
			return null;
		}
		List<ResourceDTO> resDTOList = new ArrayList<ResourceDTO>();
		ResourceDTO dto = null;
		
		for( Resource res : resList ){
			dto = trans2ResourceDTO(res);
			if( dto != null ){
				resDTOList.add(dto);
			}
		}
		
		return resDTOList;
	}

	
	private ResourceDTO trans2ResourceDTO(Resource res) {
		if( res == null ){
			return null;
		}
		
		ResourceDTO dto = new ResourceDTO();
		
		BeanUtils.copyProperties(res, dto);
		
		dto.setFormatStr( ResourceUtil.getFormatStr(res.getFormat()) );
		dto.setAuditStatusStr( ResourceUtil.getAuditStatusStr(res.getAuditStatus()) );
		//填充创建用户
		if( res.getCreatorID() != null ){
			UserDTO creator = userService.getUserDTOByID(res.getCreatorID());
			dto.setCreator(creator);
		}
		
		//填充媒体分类
		ResourceCategory mediaCate = resourceCategoryMapper.getMediaCateByResID(res.getId());
		if( mediaCate != null ){
			dto.setMediaCateID(mediaCate.getId());
		}
		//填充课程分类
		ResourceCategory courseCate = resourceCategoryMapper.getCourseCateByResID(res.getId());
		if( courseCate != null ){
			dto.setCourseCateID(courseCate.getId());
		}
		
		dto.setUrlBase(Constants.FTP_HTTP_BASE_PATH);
		//dto.setOnlineReadUrlBase(Constants.FTP_HTTP_BASE_PATH);
		
		//面向对象
		Integer faceTo = res.getFaceTo();
		if( faceTo != null ){
			dto.setFaceToStr( ResourceUtil.getFaceToStr(faceTo) );
		}
		
		//文件类型图标
		dto.setFileTypeIconUrl( ResourceUtil.getFileTypeIconUrlByFormat(res.getFormat()) );
		
		return dto;
	}

	@Override
	public ViewDTO<List<ResourceDTO>> listResourceByChannel(Long channelID)
			throws ServiceException {
		ViewDTO<List<ResourceDTO>> view = new ViewDTO<List<ResourceDTO>>();
		
		List<Resource> resList = resourceMapper.listByChannel(channelID);
		
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resDTOList);
		view.setMsg("成功获取频道资源");
		return view;
	}

	@Override
	public ViewDTO<List<ResourceDTO>> listLatest(int count)
			throws ServiceException {
		ViewDTO<List<ResourceDTO>> view = new ViewDTO<List<ResourceDTO>>();
		
		List<Resource> resList = resourceMapper.listLatest(count);
		
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resDTOList);
		view.setMsg("成功获取最新上传资源");
		return view;
	}

	@Override
	public ViewDTO<Boolean> addResToChannel(Long channelID, Long resID)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Resource res = resourceMapper.getByID(resID);
		
		if( res != null ){
			res.setOnlineReadingChannelID(channelID);
			
			resourceMapper.update(res);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("成功向频道中添加资源");
			return view;
		}

		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("向频道中添加资源失败");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delFromChannel(Long channelID, Long resID)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Resource res = resourceMapper.getByID(resID);
		
		if( res != null ){
			res.setOnlineReadingChannelID(null);
			
			resourceMapper.update(res);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("成功从频道中删除资源");
			return view;
		}

		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("从频道中删除资源失败");
		return view;
	}

	@Override
	public ViewDTO<ResourceListDTO> searchOnlineResByKeywords(String keywords,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO listDTO = new ResourceListDTO();
		
		List<Resource> resourceList = resourceMapper.searchOnlineResByKeywords(keywords,pager);
		
		List<ResourceDTO> resourceDTOList = trans2ResourceDTOList(resourceList);
		listDTO.setResources(resourceDTOList);
		
		int totalCount = resourceMapper.getSearchOnlineResCountByKeywords(keywords);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("成功检索频道资源");
		return view;
	}

	@Override
	public ViewDTO<ResourceListDTO> listResByChannel(Long channelID,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO listDTO = new ResourceListDTO();
		
		List<Resource> resourceList = resourceMapper.listResByChannel(channelID,pager);
		
		List<ResourceDTO> resourceDTOList = trans2ResourceDTOList(resourceList);
		listDTO.setResources(resourceDTOList);
		
		int totalCount = resourceMapper.getResCountByChannel(channelID);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("成功获取频道资源");
		return view;
	}

	@Override
	public ViewDTO<ResourceDTO> addResource(ResourceParamDTO resourceParamDTO)
			throws ServiceException {
		ViewDTO<ResourceDTO> view = new ViewDTO<ResourceDTO>();
		
		Resource resource = new Resource();
		
		BeanUtils.copyProperties(resourceParamDTO, resource);
		
		resourceMapper.save( resource );
		
		ResourceDTO resourceDTO = trans2ResourceDTO(resource);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resourceDTO);
		view.setMsg("添加资源成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> auditRes(Long resourceID, int auditStatus)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Resource resource = resourceMapper.getByID(resourceID);
		
		if( resource != null ){
			resource.setAuditStatus(auditStatus);
			
			resourceMapper.update(resource);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("审核成功");
			return view;
		}
		
		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("审核出错");
		return view;
	}

	@Override
	public ViewDTO<Boolean> updateRes(ResourceParamDTO resourceParamDTO)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Resource resource = resourceMapper.getByID(resourceParamDTO.getId());
		
		if( resource != null ){
			BeanUtils.copyProperties(resourceParamDTO, resource);
			
			resourceMapper.update(resource);
			
			//更新分类
			Long mediaCateID = resourceParamDTO.getMediaCateID();
			//Long courseCateID = resourceParamDTO.getCourseCateID();
			if( /*courseCateID != null &&*/ mediaCateID != null ){
				//清空资源分类关系
				resourceResourceCategoryMapper.delByResID(resourceParamDTO.getId());
				
				//创建两个资源分类关系
				ResourceResourceCategory rcc = new ResourceResourceCategory(resourceParamDTO.getId(),mediaCateID);
				resourceResourceCategoryMapper.save(rcc);
				
				/*rcc = new ResourceResourceCategory(resourceParamDTO.getId(),courseCateID);
				resourceResourceCategoryMapper.save(rcc);*/
			}
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("更新成功");
			return view;
		}
		
		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("更新失败");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delRes(Long resourceID) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		resourceMapper.delResource(resourceID);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

	@Override
	public ResourceDTO addResource(Resource resource) throws ServiceException {
		resourceMapper.save(resource);
		return trans2ResourceDTO(resource);
	}

	@Override
	public ViewDTO<ResourceListDTO> listResByCategoryID(Long cateID,Integer auditStatus,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO resLitDTO = new ResourceListDTO();
		
		List<Resource> resList = resourceMapper.listByCategory(cateID, auditStatus,pager);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		resLitDTO.setResources(resDTOList);
		
		int totalCount = resourceMapper.listCountByCategory(cateID,auditStatus);
		pager.setTotalCount(totalCount);
		resLitDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resLitDTO);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<ResourceListDTO> listAllResByCategoryID(Long cateID,Integer auditStatus)
			throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO resLitDTO = new ResourceListDTO();
		
		List<Resource> resList = resourceMapper.listByCategory(cateID,auditStatus,null);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		resLitDTO.setResources(resDTOList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resLitDTO);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<ResourceListDTO> listResource(ListResParamDTO resParamDTO,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO listDTO = new ResourceListDTO();
		
		List<Resource> resList = resourceMapper.listByListResParamDTO(resParamDTO,pager);
		List<ResourceDTO> dtoList = trans2ResourceDTOList(resList);
		listDTO.setResources(dtoList);
		
		int totalCount = resourceMapper.listCountByListResParamDTO(resParamDTO);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	
	@Override
	public ViewDTO<Boolean> addResToSubDir(Long catalogID, Long resID)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Catalog catalog = catalogMapper.getByID( catalogID );
		if( catalog == null ){
			view.setCode(ViewDTO.CODE_FAIL);
			view.setData(false);
			view.setMsg("目录不存在");
			return view;
		}
		
		if( catalog.getName().equals("电子素材") ){
			/**
			 * 只能添加一个PDF
			 * 删除原有的，添加新的
			 */
			resourceCatalogMapper.deleteByCatalogID(catalogID);
			
			ResourceCatalog rc = new ResourceCatalog(catalogID,resID);
			resourceCatalogMapper.save(rc);
		}else{
			/**
			 * 可以添加多个，追加
			 */
			ResourceCatalog resourceCatalog = resourceCatalogMapper.getByCatalogIDAndResourceID(catalogID,resID);
			
			if( resourceCatalog != null ){
				view.setCode(ViewDTO.CODE_FAIL);
				view.setData(false);
				view.setMsg("不可重复添加");
				return view;
			}
			
			ResourceCatalog rc = new ResourceCatalog(catalogID,resID);
			resourceCatalogMapper.save(rc);
		}
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("添加成功");
		return view;
	}

	@Override
	public ViewDTO<List<ResourceDTO>> listAllResByCatalog(Long catalogID)
			throws ServiceException {
		ViewDTO<List<ResourceDTO>> view = new ViewDTO<List<ResourceDTO>>();
		List<Resource> resList = resourceMapper.listAllResByCatalog(catalogID);
		
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resDTOList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<ResourceListDTO> listResByCourse(Long courseID,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ResourceListDTO> view = new ViewDTO<ResourceListDTO>();
		ResourceListDTO dto = new ResourceListDTO();
		
		/*List<Catalog> catalogList = catalogMapper.listChapterByCourseID(courseID);
		
		List<Long> catalogIDList = new ArrayList<Long>();
		for( Catalog c : catalogList ){
			catalogIDList.add(c.getId());
		}*/
		
		List<Resource> resList = resourceMapper.listResByCourse(courseID,pager);
		List<ResourceDTO> dtoList = trans2ResourceDTOList(resList);

		dto.setResources(dtoList);
		
		int totalCount = resourceMapper.listResCountByCourse(courseID);
		pager.setTotalCount(totalCount);
		
		dto.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ResourceDTO getResourceDTOByID(Long resourceID)
			throws ServiceException {
		Resource res = resourceMapper.getByID(resourceID);
		
		ResourceDTO dto = trans2ResourceDTO(res);
		
		return dto;
	}

	@Override
	public List<ResourceDTO> listResByUploaderUID(Long uid, PagerDTO pager)
			throws ServiceException {
		List<Resource> resList = resourceMapper.listResByUploaderUID(uid,pager);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		
		return resDTOList;
	}

	@Override
	public int listResCountByUploaderUID(Long uid) throws ServiceException {
		return resourceMapper.listResCountByUploaderUID(uid);
	}

	@Override
	public ResourceListDTO listResByKeywords(String keywords, PagerDTO pager)
			throws ServiceException {
		ResourceListDTO dto = new ResourceListDTO();
		
		List<Resource> resList = resourceMapper.listByKeywords(keywords,pager);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		dto.setResources(resDTOList);
		
		int totalCount = resourceMapper.listCountByKeywords(keywords);
		pager.setTotalCount(totalCount);
		dto.setPager(pager);
		
		return dto;
	}

	@Override
	public ViewDTO<List<ResourceDTO>> listAllResByCatalogNameInCourse(
			Long courseID, String catalogName) throws ServiceException {
		ViewDTO<List<ResourceDTO>> view = new ViewDTO<List<ResourceDTO>>();
		
		List<Resource> resList = resourceMapper.listAllByCategoryNameInCourse(courseID,catalogName,Resource.AUDIT_STATUS_APPROVE);
		List<ResourceDTO> resDTOList = trans2ResourceDTOList(resList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(resDTOList);
		view.setMsg("查询成功");
		return view;
	}
	
}
