package com.uce360.lzsz.psychology.resourcelib.model;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class Question {
	/** 新创建的 */
	public static final Integer STATUS_NEW = 1;
	private Long id;
	private String title;
	private String content;
	private Long askUserID;
	private Integer status;
	private Long electiveCourseID;
	private Date createTime = new Date();
	private Integer isDelete = Constants.IS_DELETE_FALSE;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getAskUserID() {
		return askUserID;
	}
	public void setAskUserID(Long askUserID) {
		this.askUserID = askUserID;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getElectiveCourseID() {
		return electiveCourseID;
	}
	public void setElectiveCourseID(Long electiveCourseID) {
		this.electiveCourseID = electiveCourseID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
}
