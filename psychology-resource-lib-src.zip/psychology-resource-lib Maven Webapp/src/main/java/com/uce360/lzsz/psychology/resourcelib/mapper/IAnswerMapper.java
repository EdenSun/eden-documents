package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Answer;

public interface IAnswerMapper {

	List<Answer> listByQID(
			@Param("qid")Long qid, 
			@Param("pager")PagerDTO pager);

	int listCountByQID(@Param("qid")Long qid);

	void save(@Param("answer")Answer answer);

}
