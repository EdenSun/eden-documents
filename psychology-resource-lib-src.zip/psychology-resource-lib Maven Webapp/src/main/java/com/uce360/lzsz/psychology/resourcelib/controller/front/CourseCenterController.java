package com.uce360.lzsz.psychology.resourcelib.controller.front;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.dto.CatalogTreeDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.CourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.service.ICourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;

/**
 * 课程中心
 * @author durian
 *
 */
@Controller
@RequestMapping("/coursecenter")
public class CourseCenterController {

	@Autowired
	private IResourceService resourceService;
	
	@Autowired
	private ICourseService courseService;
	
	@RequestMapping("/listCourse")
	@ResponseBody
	public ViewDTO<CourseListDTO> listCourse(
		@ModelAttribute("pager")PagerDTO pager
			){
		
		ViewDTO<CourseListDTO> view = courseService.listCourse(pager);
		
		return view;
	}
	
	@RequestMapping("/getCourseCatalog")
	@ResponseBody
	public ViewDTO<List<CatalogTreeDTO>> getCourseCatalog(
			Long courseID
			){
		
		ViewDTO<List<CatalogTreeDTO>> view = courseService.listCourseCatalog(courseID);
		
		return view;
	}
	
	
	@RequestMapping("/listAllResByCatalog")
	@ResponseBody
	public ViewDTO<List<ResourceDTO>> listAllResByCatalog(
			Long catalogID
			){
		
		ViewDTO<List<ResourceDTO>> view = resourceService.listAllResByCatalog(catalogID);
		
		return view;
	}
	
	@RequestMapping("/listAllResByCatalogNameInCourse")
	@ResponseBody
	public ViewDTO<List<ResourceDTO>> listAllResByCatalogNameInCourse(
			Long courseID,
			String catalogName
			){
		
		ViewDTO<List<ResourceDTO>> view = resourceService.listAllResByCatalogNameInCourse(courseID,catalogName);
		
		return view;
	}
	
}
