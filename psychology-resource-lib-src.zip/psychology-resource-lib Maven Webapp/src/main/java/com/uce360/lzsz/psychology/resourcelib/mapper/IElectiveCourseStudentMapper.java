package com.uce360.lzsz.psychology.resourcelib.mapper;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.model.ElectiveCourseStudent;

public interface IElectiveCourseStudentMapper {

	void save(@Param("ecStudent")ElectiveCourseStudent ecStudent);

}
