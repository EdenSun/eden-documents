package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;
import java.util.List;

public class CatalogTreeDTO {
	private Long id;
	private String name;
	private String description;
	private Integer level;
	private Long parentID;
	private Long courseID;
	private Date createTime;
	private Integer isDelete;
	
	private List<CatalogTreeDTO> subs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Long getParentID() {
		return parentID;
	}

	public void setParentID(Long parentID) {
		this.parentID = parentID;
	}

	public Long getCourseID() {
		return courseID;
	}

	public void setCourseID(Long courseID) {
		this.courseID = courseID;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public List<CatalogTreeDTO> getSubs() {
		return subs;
	}

	public void setSubs(List<CatalogTreeDTO> subs) {
		this.subs = subs;
	}
	
}
