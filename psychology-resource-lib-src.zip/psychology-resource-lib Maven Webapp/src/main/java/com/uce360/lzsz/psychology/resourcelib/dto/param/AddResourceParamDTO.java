package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class AddResourceParamDTO {
}
