package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.ResourceCategoryDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceCategoryParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceCategoryMapper;
import com.uce360.lzsz.psychology.resourcelib.model.ResourceCategory;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceCategoryService;

@Service
public class ResourceCategoryServiceImpl implements IResourceCategoryService {
	@Autowired
	private IResourceCategoryMapper resourceCategoryMapper;
	
	@Override
	public ViewDTO<ResourceCategoryDTO> listCatelist() throws ServiceException {
		ViewDTO<ResourceCategoryDTO> view = new ViewDTO<ResourceCategoryDTO>();
		
		ResourceCategory root = resourceCategoryMapper.getByLevel(0);
		ResourceCategoryDTO rootDTO = trans2ResourceCategoryDTO(root);
		
		iteratorResourceCategory(rootDTO);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(rootDTO);
		view.setMsg("递归读取所有资源分类成功");
		return view;
	}

	private void iteratorResourceCategory(ResourceCategoryDTO parent) {
		List<ResourceCategory> subs =  resourceCategoryMapper.listSubCategory(parent.getId());
	
		if( subs != null ){
			List<ResourceCategoryDTO> subDTOList = trans2ResourceCategoryDTOList(subs);
			parent.setSubs( subDTOList );
			
			for( ResourceCategoryDTO dto: subDTOList){
				iteratorResourceCategory(dto);
			}
		}else{
			return;
		}
	}

	
	private List<ResourceCategoryDTO> trans2ResourceCategoryDTOList(
			List<ResourceCategory> subs) {
		if( subs == null ){
			return null;
		}
		List<ResourceCategoryDTO> dtoList = new ArrayList<ResourceCategoryDTO>();
		ResourceCategoryDTO dto = null;
		
		for( ResourceCategory resCategory: subs ){
			dto = trans2ResourceCategoryDTO(resCategory);
			dtoList.add(dto);
		}
		
		return dtoList;
	}

	private ResourceCategoryDTO trans2ResourceCategoryDTO(ResourceCategory resourceCategory) {
		if( resourceCategory == null ){
			return null;
		}
		
		ResourceCategoryDTO dto = new ResourceCategoryDTO();
		BeanUtils.copyProperties(resourceCategory, dto);
		
		return dto;
	}

	@Override
	public ViewDTO<Boolean> delCate(Long id) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		resourceCategoryMapper.delCate(id);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("成功删除指定分类");
		return view;
	}

	@Override
	public ViewDTO<Boolean> updateCateName(Long id, String name)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		ResourceCategory cate = resourceCategoryMapper.getByID(id);
		
		if( cate != null ){
			cate.setName(name);
			
			resourceCategoryMapper.update(cate);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(true);
			view.setMsg("成功更新分类名称");
			return view;
		}
		
		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(false);
		view.setMsg("更新分类名称失败");
		return view;
	}

	@Override
	public ViewDTO<ResourceCategoryDTO> addCate(
			ResourceCategoryParamDTO resCategoryParamDTO)
			throws ServiceException {
		ViewDTO<ResourceCategoryDTO> view = new ViewDTO<ResourceCategoryDTO>();
		
		ResourceCategory cate = trans2ResourceCategory( resCategoryParamDTO );
		
		if( cate != null ){
			resourceCategoryMapper.add(cate);
			
			ResourceCategoryDTO cateDTO = trans2ResourceCategoryDTO(cate);
			
			view.setCode(ViewDTO.CODE_SUCCESS);
			view.setData(cateDTO);
			view.setMsg("成功创建分类");
			return view;
		}
		
		view.setCode(ViewDTO.CODE_FAIL);
		view.setData(null);
		view.setMsg("创建分类失败");
		return view;
	}

	private ResourceCategory trans2ResourceCategory(
			ResourceCategoryParamDTO resCategoryParamDTO) {
		if( resCategoryParamDTO == null ){
			return null;
		}
		ResourceCategory cate = new ResourceCategory();
		
		BeanUtils.copyProperties(resCategoryParamDTO, cate);
		
		return cate;
	}

	@Override
	public ViewDTO<List<ResourceCategoryDTO>> listAllMediaCate()
			throws ServiceException {
		ViewDTO<List<ResourceCategoryDTO>> view = new ViewDTO<List<ResourceCategoryDTO>>();
		
		
		ResourceCategory root = resourceCategoryMapper.getByID(1L);
		ResourceCategoryDTO rootDTO = trans2ResourceCategoryDTO(root);
		
		List<ResourceCategoryDTO> cateList = new ArrayList<ResourceCategoryDTO>();
		iteratorResourceCategoryToList(cateList,rootDTO);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(cateList);
		view.setMsg("递归读取所有媒体分类成功");
		return view;
	}

	private void iteratorResourceCategoryToList(
			List<ResourceCategoryDTO> cateList, ResourceCategoryDTO parent) {
		List<ResourceCategory> subs =  resourceCategoryMapper.listSubCategory(parent.getId());
		
		if( subs != null ){
			List<ResourceCategoryDTO> subDTOList = trans2ResourceCategoryDTOList(subs);
			cateList.addAll(subDTOList);
			
			for( ResourceCategoryDTO dto: subDTOList){
				iteratorResourceCategory(dto);
			}
		}else{
			return;
		}
	}

	@Override
	public ViewDTO<List<ResourceCategoryDTO>> listAllCourseCate()
			throws ServiceException {
		ViewDTO<List<ResourceCategoryDTO>> view = new ViewDTO<List<ResourceCategoryDTO>>();
		
		ResourceCategory root = resourceCategoryMapper.getByID(7L);
		ResourceCategoryDTO rootDTO = trans2ResourceCategoryDTO(root);
		
		List<ResourceCategoryDTO> cateList = new ArrayList<ResourceCategoryDTO>();
		iteratorResourceCategoryToList(cateList,rootDTO);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(cateList);
		view.setMsg("递归读取所有课程分类成功");
		return view;
	}

}
