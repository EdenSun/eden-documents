package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class AssignmentListDTO {
	private List<AssignmentListItemDTO> assignments;
	private PagerDTO pager;
	public List<AssignmentListItemDTO> getAssignments() {
		return assignments;
	}
	public void setAssignments(List<AssignmentListItemDTO> assignments) {
		this.assignments = assignments;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
