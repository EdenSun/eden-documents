package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class QuestionAnswerListDTO {
	private List<QuestionAnswerDTO> answers;
	private PagerDTO pager;
	public List<QuestionAnswerDTO> getAnswers() {
		return answers;
	}
	public void setAnswers(List<QuestionAnswerDTO> answers) {
		this.answers = answers;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
