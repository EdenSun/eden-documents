package com.uce360.lzsz.psychology.resourcelib.util;

import com.uce360.lzsz.psychology.resourcelib.model.Resource;

public class ResourceUtil {

	public static String getFormatStr(String suffix) {
		if (suffix != null) {
			if (suffix.toLowerCase().equals("pdf")) {
				return "PDF文档";
			} else if (suffix.toLowerCase().equals("doc")
					|| suffix.toLowerCase().equals("docx")) {
				return "WORD文档";
			} else if (suffix.toLowerCase().equals("ppt")
					|| suffix.toLowerCase().equals("pptx")) {
				return "PPT文档";
			} else if (suffix.toLowerCase().equals("xls")
					|| suffix.toLowerCase().equals("xlsx")) {
				return "EXCEL文档";
			} else if (suffix.toLowerCase().equals("png")
					|| suffix.toLowerCase().equals("jpg")
					|| suffix.toLowerCase().equals("jpeg")
					|| suffix.toLowerCase().equals("gif")) {
				return "图片";
			} else if (suffix.toLowerCase().equals("rmvb")
					|| suffix.toLowerCase().equals("mp4")
					|| suffix.toLowerCase().equals("avi")
					|| suffix.toLowerCase().equals("mov")
					|| suffix.toLowerCase().equals("asf")
					|| suffix.toLowerCase().equals("wmv")
					|| suffix.toLowerCase().equals("flv")) {
				return "视频";
			} else if (suffix.toLowerCase().equals("txt")) {
				return "文本";
			}
		}
		return "未知";
	}

	public static Integer getFormatBySuffix(String suffix) {
		if (suffix != null) {
			if (suffix.toLowerCase().equals("pdf")) {
				return Resource.FORMAT_PDF;
			} else if (suffix.toLowerCase().equals("doc")) {
				return Resource.FORMAT_DOC;
			} else if (suffix.toLowerCase().equals("docx")) {
				return Resource.FORMAT_DOCX;
			} else if (suffix.toLowerCase().equals("ppt")) {
				return Resource.FORMAT_PPT;
			} else if (suffix.toLowerCase().equals("pptx")) {
				return Resource.FORMAT_PPTX;
			} else if (suffix.toLowerCase().equals("xls")) {
				return Resource.FORMAT_XLS;
			} else if (suffix.toLowerCase().equals("xlsx")) {
				return Resource.FORMAT_XLSX;
			} else if (suffix.toLowerCase().equals("png")) {
				return Resource.FORMAT_PNG;
			} else if (suffix.toLowerCase().equals("jpg")) {
				return Resource.FORMAT_JPG;
			} else if (suffix.toLowerCase().equals("jpeg")) {
				return Resource.FORMAT_JPEG;
			} else if (suffix.toLowerCase().equals("gif")) {
				return Resource.FORMAT_GIF;
			}else if (suffix.toLowerCase().equals("rmvb")) {
				return Resource.FORMAT_RMVB;
			} else if (suffix.toLowerCase().equals("mp4")) {
				return Resource.FORMAT_MP4;
			} else if (suffix.toLowerCase().equals("avi")) {
				return Resource.FORMAT_AVI;
			} else if (suffix.toLowerCase().equals("mov")) {
				return Resource.FORMAT_MOV;
			}else if (suffix.toLowerCase().equals("asf")) {
				return Resource.FORMAT_ASF;
			} else if (suffix.toLowerCase().equals("wmv")) {
				return Resource.FORMAT_WMV;
			} else if (suffix.toLowerCase().equals("flv")) {
				return Resource.FORMAT_FLV;
			} else if (suffix.toLowerCase().equals("txt")) {
				return Resource.FORMAT_TXT;
			}
		}

		return Resource.FORMAT_UNKNOWN;
	}

	public static String getFormatStr(Integer format) {
		if( format == null ){
			return null;
		}
		
		if( format.equals( Resource.FORMAT_PDF )  ){
			return "PDF文档";
		}else if( format.equals( Resource.FORMAT_DOC ) ){
			return "DOC文档";
		}else if( format.equals( Resource.FORMAT_DOCX ) ){
			return "DOCX文档";
		}else if( format.equals( Resource.FORMAT_PPT ) ){
			return "PPT幻灯片";
		}else if( format.equals( Resource.FORMAT_PPTX ) ){
			return "PPTX幻灯片";
		}else if( format.equals( Resource.FORMAT_XLS ) ){
			return "XLS电子表格文档";
		}else if( format.equals( Resource.FORMAT_XLSX ) ){
			return "XLSX电子表格文档";
		}else if( format.equals( Resource.FORMAT_PNG ) ){
			return "PNG图片";
		}else if( format.equals( Resource.FORMAT_JPG ) ){
			return "JPG图片";
		}else if( format.equals( Resource.FORMAT_JPEG ) ){
			return "JPEG图片";
		}else if( format.equals( Resource.FORMAT_GIF ) ){
			return "GIF图片";
		}else if( format.equals( Resource.FORMAT_RMVB ) ){
			return "RMVB视频文件";
		}else if( format.equals( Resource.FORMAT_MP4 ) ){
			return "MP4视频文件";
		}else if( format.equals( Resource.FORMAT_AVI ) ){
			return "AVI视频文件";
		}else if( format.equals( Resource.FORMAT_MOV ) ){
			return "MOV视频文件";
		}else if( format.equals( Resource.FORMAT_ASF ) ){
			return "ASF视频文件";
		}else if( format.equals( Resource.FORMAT_WMV ) ){
			return "WMV视频文件";
		}else if( format.equals( Resource.FORMAT_FLV ) ){
			return "FLV视频文件";
		}else if( format.equals( Resource.FORMAT_TXT ) ){
			return "TXT文本";
		}else if( format.equals( Resource.FORMAT_RAR ) ){
			return "RAR文件";
		}else if( format.equals( Resource.FORMAT_WAV ) ){
			return "WAV文件";
		}else if( format.equals( Resource.FORMAT_MP3 ) ){
			return "MP3文件";
		}else if( format.equals( Resource.FORMAT_BMP ) ){
			return "BMP文件";
		}else if( format.equals( Resource.FORMAT_MPG ) ){
			return "MPG文件";
		}else if( format.equals( Resource.FORMAT_PSD ) ){
			return "PSD文件";
		}else if( format.equals( Resource.FORMAT_RTF ) ){
			return "RTF文件";
		}else if( format.equals( Resource.FORMAT_ZIP ) ){
			return "ZIP文件";
		}
		
		return "未知格式";
	}

	public static String getAuditStatusStr(Integer auditStatus) {
		if( auditStatus == null ){
			return "未知状态";
		}
		if( auditStatus.equals(Resource.AUDIT_STATUS_APPROVE) ){
			return "审核通过";
		}else if( auditStatus.equals(Resource.AUDIT_STATUS_REJECT) ){
			return "审核驳回";
		}else if( auditStatus.equals(Resource.AUDIT_STATUS_WAITTING_FOR_AUDIT) ){
			return "等待审核";
		}
		return "未知状态";
	}

	public static String getFaceToStr(Integer faceTo) {
		if( faceTo.equals( Resource.FACE_TO_ALL ) ){
			return "不限";
		}else if( faceTo.equals( Resource.FACE_TO_STUDENT ) ){
			return "学生";
		}else if( faceTo.equals( Resource.FACE_TO_TEACHER ) ){
			return "老师";
		}
		return "其他";
	}

	public static String getFileTypeIconUrlByFormat(Integer format) {
		if( format == null ){
			return null;
		}
		
		if( format.equals( Resource.FORMAT_PDF )  ){
			return "img/ft/pdf.png";
		}else if( format.equals( Resource.FORMAT_DOC ) ){
			return "img/ft/doc.png";
		}else if( format.equals( Resource.FORMAT_DOCX ) ){
			return "img/ft/docx.png";
		}else if( format.equals( Resource.FORMAT_PPT ) ){
			return "img/ft/ppt.png";
		}else if( format.equals( Resource.FORMAT_PPTX ) ){
			return "img/ft/ppt.png";
		}else if( format.equals( Resource.FORMAT_XLS ) ){
			return "img/ft/xls.png";
		}else if( format.equals( Resource.FORMAT_XLSX ) ){
			return "img/ft/xlsx.png";
		}else if( format.equals( Resource.FORMAT_PNG ) ){
			return "img/ft/png.png";
		}else if( format.equals( Resource.FORMAT_JPG ) ){
			return "img/ft/jpg.png";
		}else if( format.equals( Resource.FORMAT_JPEG ) ){
			return "img/ft/jpg.png";
		}else if( format.equals( Resource.FORMAT_GIF ) ){
			return "img/ft/gif.png";
		}else if( format.equals( Resource.FORMAT_RMVB ) ){
			return "img/ft/_blank.png";
		}else if( format.equals( Resource.FORMAT_MP4 ) ){
			return "img/ft/mp4.png";
		}else if( format.equals( Resource.FORMAT_AVI ) ){
			return "img/ft/avi.png";
		}else if( format.equals( Resource.FORMAT_MOV ) ){
			return "img/ft/_blank.png";
		}else if( format.equals( Resource.FORMAT_ASF ) ){
			return "img/ft/_blank.png";
		}else if( format.equals( Resource.FORMAT_WMV ) ){
			return "img/ft/_blank.png";
		}else if( format.equals( Resource.FORMAT_FLV ) ){
			return "img/ft/flv.png";
		}else if( format.equals( Resource.FORMAT_TXT ) ){
			return "img/ft/txt.png";
		}else if( format.equals( Resource.FORMAT_RAR ) ){
			return "img/ft/rar.png";
		}else if( format.equals( Resource.FORMAT_WAV ) ){
			return "img/ft/wav.png";
		}else if( format.equals( Resource.FORMAT_MP3 ) ){
			return "img/ft/mp3.png";
		}else if( format.equals( Resource.FORMAT_BMP ) ){
			return "img/ft/bmp.png";
		}else if( format.equals( Resource.FORMAT_MPG ) ){
			return "img/ft/mpg.png";
		}else if( format.equals( Resource.FORMAT_PSD ) ){
			return "img/ft/psd.png";
		}else if( format.equals( Resource.FORMAT_RTF ) ){
			return "img/ft/rtf.png";
		}else if( format.equals( Resource.FORMAT_ZIP ) ){
			return "img/ft/zip.png";
		}
		
		return "img/ft/_blank.png";
	}

}
