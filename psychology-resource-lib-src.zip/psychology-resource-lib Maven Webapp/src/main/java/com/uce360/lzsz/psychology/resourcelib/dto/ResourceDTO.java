package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class ResourceDTO {
	private Long id;
	private String name;
	private String description;
	private String urlBase;
	private String url;
	private String onlineReadUrl;
	
	private String fileTypeIconUrl;
	private Long size;
	private String keywords;
	
	private Integer format;
	private String formatStr;
	
	private Long onlineReadingChannelID;
	private Long creatorID;
	private UserDTO creator;
	
	private Integer auditStatus;
	private String auditStatusStr;
	
	private Integer faceTo;
	private String faceToStr;
	
	private Date createTime;
	private Integer isDelete;
	
	private Long mediaCateID;
	private Long courseCateID;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getOnlineReadUrl() {
		return onlineReadUrl;
	}
	public void setOnlineReadUrl(String onlineReadUrl) {
		this.onlineReadUrl = onlineReadUrl;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public Integer getFormat() {
		return format;
	}
	public void setFormat(Integer format) {
		this.format = format;
	}
	public String getFormatStr() {
		return formatStr;
	}
	public void setFormatStr(String formatStr) {
		this.formatStr = formatStr;
	}
	public Long getOnlineReadingChannelID() {
		return onlineReadingChannelID;
	}
	public void setOnlineReadingChannelID(Long onlineReadingChannelID) {
		this.onlineReadingChannelID = onlineReadingChannelID;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public UserDTO getCreator() {
		return creator;
	}
	public void setCreator(UserDTO creator) {
		this.creator = creator;
	}
	public Integer getAuditStatus() {
		return auditStatus;
	}
	public void setAuditStatus(Integer auditStatus) {
		this.auditStatus = auditStatus;
	}
	public String getAuditStatusStr() {
		return auditStatusStr;
	}
	public void setAuditStatusStr(String auditStatusStr) {
		this.auditStatusStr = auditStatusStr;
	}
	public Integer getFaceTo() {
		return faceTo;
	}
	public void setFaceTo(Integer faceTo) {
		this.faceTo = faceTo;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	public Long getMediaCateID() {
		return mediaCateID;
	}
	public void setMediaCateID(Long mediaCateID) {
		this.mediaCateID = mediaCateID;
	}
	public Long getCourseCateID() {
		return courseCateID;
	}
	public void setCourseCateID(Long courseCateID) {
		this.courseCateID = courseCateID;
	}
	public String getUrlBase() {
		return urlBase;
	}
	public void setUrlBase(String urlBase) {
		this.urlBase = urlBase;
	}
	public String getFaceToStr() {
		return faceToStr;
	}
	public void setFaceToStr(String faceToStr) {
		this.faceToStr = faceToStr;
	}
	public String getFileTypeIconUrl() {
		return fileTypeIconUrl;
	}
	public void setFileTypeIconUrl(String fileTypeIconUrl) {
		this.fileTypeIconUrl = fileTypeIconUrl;
	}
}
