package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class AssignmentAnswerListDTO {
	private List<AssignmentAnswerListItemDTO> answers;
	private PagerDTO pager;
	public List<AssignmentAnswerListItemDTO> getAnswers() {
		return answers;
	}
	public void setAnswers(List<AssignmentAnswerListItemDTO> answers) {
		this.answers = answers;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
