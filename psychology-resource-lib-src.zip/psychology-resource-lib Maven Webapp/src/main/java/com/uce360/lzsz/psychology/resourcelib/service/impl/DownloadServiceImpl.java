package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.DownloadItemDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.DownloadListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IDownloadMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IResourceMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IUserMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Download;
import com.uce360.lzsz.psychology.resourcelib.service.IDownloadService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class DownloadServiceImpl implements IDownloadService {
	@Autowired
	private IDownloadMapper downloadMapper;
	
	@Autowired
	private IUserMapper userMapper;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IResourceMapper resourceMapper;
	
	@Autowired
	private IResourceService resourceService;
	
	@Override
	public ViewDTO<DownloadListDTO> listByUserID(Long uid, PagerDTO pager)
			throws ServiceException {
		ViewDTO<DownloadListDTO> view = new ViewDTO<DownloadListDTO>();
		DownloadListDTO listDTO = new DownloadListDTO();
		
		List<Download> downloadList = downloadMapper.listByUserID(uid,pager);
		List<DownloadItemDTO> dtoList = trans2DownloadItemDTOList(downloadList);
		listDTO.setDownloads(dtoList);
		
		int totalCount = downloadMapper.listCountByUserID(uid);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	private List<DownloadItemDTO> trans2DownloadItemDTOList(
			List<Download> downloadList) {
		if( downloadList == null ){
			return null;
		}
		List<DownloadItemDTO> dtoList = new ArrayList<DownloadItemDTO>();
		DownloadItemDTO dto = null;
		
		for(Download download:downloadList){
			dto = trans2DownloadItemDTO(download);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		
		return dtoList;
	}

	private DownloadItemDTO trans2DownloadItemDTO(Download download) {
		if( download == null ){
			return null;
		}
		DownloadItemDTO dto = new DownloadItemDTO();
		
		ResourceDTO resDTO = resourceService.getResourceDTOByID(download.getResourceID());
		dto.setResource(resDTO);

		UserDTO userDTO = userService.getUserDTOByID(download.getUserID());
		dto.setUser(userDTO);
		
		return dto;
	}

	@Override
	public ViewDTO<Boolean> delByID(Long downloadID) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		downloadMapper.delByID(downloadID);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> addMyDownload(Long uid, Long resID)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		Download download = new Download();
		download.setResourceID(resID);
		download.setUserID(uid);
		
		downloadMapper.save(download);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("成功");
		return view;
	}

	
}
