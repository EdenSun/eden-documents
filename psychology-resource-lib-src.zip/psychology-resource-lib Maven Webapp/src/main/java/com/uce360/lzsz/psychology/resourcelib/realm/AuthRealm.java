package com.uce360.lzsz.psychology.resourcelib.realm;

import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;

@Service("authRealm")
public class AuthRealm extends AuthorizingRealm{
	Logger log = Logger.getLogger(AuthRealm.class);
	
	@Autowired
	private IUserService userService;
	
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		/*String account=(String)principals.fromRealm(getName()).iterator().next();  
		UserDTO userDTO = userService.getDTO(account);
		
		if( userDTO != null ){
			SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();  

			List<RoleDTO> roles = userDTO.getRoles();
			if( roles != null ){
				for(RoleDTO role : roles){
					info.addRole(role.getRoleString());
					
					List<PermissionDTO> permissions = role.getPermissions();
					if( permissions != null ){
						for(PermissionDTO permission: permissions){
							info.addStringPermission( permission.getPermissionString() );
						}
					}
				}
			}
			
			return info;
		}
		else{
			return null;
		}*/
		
		return null;
	}

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken _token) throws AuthenticationException {
		UsernamePasswordToken token = (UsernamePasswordToken)_token;
		
		String account = token.getUsername();
		String password = String.valueOf(token.getPassword());
		
		log.info("用户登录:[" + account + ":" + password + "]");
		
		User user = userService.get(account,password);

		if( user != null ){
			//用户存在，登录成
			SecurityUtils.getSubject().getSession().setAttribute(Constants.SESSION_ID_LOGIN_USER, user);
			return new SimpleAuthenticationInfo(account, password, getName());
		}else{
			return null;
		}
	}

	
}
