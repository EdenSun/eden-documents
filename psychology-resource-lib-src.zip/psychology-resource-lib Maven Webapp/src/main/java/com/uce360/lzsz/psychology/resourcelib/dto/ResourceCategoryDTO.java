package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;


public class ResourceCategoryDTO {
	private Long id;
	private String name;
	private Integer level;
	
	private List<ResourceCategoryDTO> subs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public List<ResourceCategoryDTO> getSubs() {
		return subs;
	}

	public void setSubs(List<ResourceCategoryDTO> subs) {
		this.subs = subs;
	}

}
