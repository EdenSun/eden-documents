package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class ListResParamDTO {
	private Integer format;
	private String keywords;
	
	public Integer getFormat() {
		return format;
	}
	public void setFormat(Integer format) {
		this.format = format;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	
}
