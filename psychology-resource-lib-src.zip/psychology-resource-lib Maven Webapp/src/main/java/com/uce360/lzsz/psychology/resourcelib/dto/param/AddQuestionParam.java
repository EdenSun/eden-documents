package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class AddQuestionParam {
	private Long electiveCourseID;
	private String title;
	private String content;
	private Long uid;
	public Long getElectiveCourseID() {
		return electiveCourseID;
	}
	public void setElectiveCourseID(Long electiveCourseID) {
		this.electiveCourseID = electiveCourseID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
}
