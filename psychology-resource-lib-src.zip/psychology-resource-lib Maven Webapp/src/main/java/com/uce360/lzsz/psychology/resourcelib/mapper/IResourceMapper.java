package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListResParamDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Resource;

public interface IResourceMapper {

	List<Resource> listByCategory(
			@Param("categoryID")Long categoryID, 
			@Param("auditStatus")Integer auditStatus,
			@Param("pager")PagerDTO pager);

	int listCountByCategory(
			@Param("categoryID")Long categoryID,
			@Param("auditStatus")Integer auditStatus);

	List<Resource> listByChannel(
		@Param("channelID")Long channelID);

	List<Resource> listLatest(
			@Param("count")int count);

	Resource getByID(
			@Param("id")Long id);

	void update(@Param("res")Resource res);

	List<Resource> listResByChannel(@Param("channelID")Long channelID, @Param("pager")PagerDTO pager);

	int getResCountByChannel(@Param("channelID")Long channelID);

	List<Resource> searchOnlineResByKeywords(@Param("keywords")String keywords, @Param("pager")PagerDTO pager);

	int getSearchOnlineResCountByKeywords(@Param("keywords")String keywords);

	void save(@Param("resource")Resource resource);

	void delResource(@Param("resourceID")Long resourceID);

	List<Resource> listByListResParamDTO(
			@Param("resParamDTO")ListResParamDTO resParamDTO,
			@Param("pager")PagerDTO pager);

	int listCountByListResParamDTO(@Param("resParamDTO")ListResParamDTO resParamDTO);

	List<Resource> listAllResByCatalog(@Param("catalogID")Long catalogID);

	List<Resource> listResByCourse(
			@Param("courseID")Long courseID, 
			@Param("pager")PagerDTO pager);

	int listResCountByCourse(@Param("courseID")Long courseID);

	List<Resource> listResByUploaderUID(
			@Param("uid")Long uid, 
			@Param("pager")PagerDTO pager);

	int listResCountByUploaderUID(@Param("uid")Long uid);

	List<Resource> listByKeywords(
			@Param("keywords")String keywords, 
			@Param("pager")PagerDTO pager);

	int listCountByKeywords(@Param("keywords")String keywords);

	List<Resource> listAllByCategoryNameInCourse(
			@Param("courseID")Long courseID,
			@Param("catalogName")String catalogName, 
			@Param("auditStatus")Integer auditStatus);

}
