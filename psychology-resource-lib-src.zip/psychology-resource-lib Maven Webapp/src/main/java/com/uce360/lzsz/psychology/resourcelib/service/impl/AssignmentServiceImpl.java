package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentDetailDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentListItemDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAssignmentAnswerMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAssignmentMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Assignment;
import com.uce360.lzsz.psychology.resourcelib.model.AssignmentAnswer;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class AssignmentServiceImpl implements IAssignmentService {

	@Autowired
	private IAssignmentMapper assignmentMapper;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IAssignmentAnswerMapper assignmentAnswerMapper;
	
	@Override
	public ViewDTO<AssignmentListDTO> listAssignment(Long uid, Long cid,
			PagerDTO pager) throws ServiceException {
		ViewDTO<AssignmentListDTO> view = new ViewDTO<AssignmentListDTO>();
		AssignmentListDTO listDTO = new AssignmentListDTO();
		
		/*判断用户是老师 还是 学生
		 * 若是老师，查询老师教授的选课列表
		 * 若是学生，查询学生所选的选课列表
		 **/
		User user = userService.getUserByID(uid);
		if( user.getRoleType().equals(User.ROLE_TYPE_STUDENT) ){
			
			List<Assignment> assignmentList = assignmentMapper.listStudentsCourseAssignment(uid,cid,pager);
			List<AssignmentListItemDTO> dtoList = trans2AssignmentListItemDTOList(uid,assignmentList);
			listDTO.setAssignments(dtoList);
			
			int totalCount = assignmentMapper.getStudentsCourseAssignmentCount(uid,cid);
			pager.setTotalCount(totalCount);
			listDTO.setPager(pager);
			
		}else if( user.getRoleType().equals(User.ROLE_TYPE_TEACHER) ){
			
			List<Assignment> assignmentList = assignmentMapper.listTeachersCourseAssignment(uid,cid,pager);
			List<AssignmentListItemDTO> dtoList = trans2AssignmentListItemDTOList(uid,assignmentList);
			listDTO.setAssignments(dtoList);
			
			int totalCount = assignmentMapper.getTeachersCourseAssignmentCount(uid,cid);
			pager.setTotalCount(totalCount);
			listDTO.setPager(pager);
		}else{
			//其他 do nothing
		}
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<AssignmentListDTO> listAssignmentForAdmin(Long uid,
			Long cid, PagerDTO pager) throws ServiceException {
		ViewDTO<AssignmentListDTO> view = new ViewDTO<AssignmentListDTO>();
		AssignmentListDTO listDTO = new AssignmentListDTO();
		
		List<Assignment> assignmentList = assignmentMapper.listAssignmentByCourseID(uid,cid,pager);
		List<AssignmentListItemDTO> dtoList = trans2AssignmentListItemDTOList(uid,assignmentList);
		listDTO.setAssignments(dtoList);
		
		int totalCount = assignmentMapper.getAssignmentCountByCourseID(uid,cid);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}
	

	private List<AssignmentListItemDTO> trans2AssignmentListItemDTOList(
			Long uid,
			List<Assignment> assignmentList) {
		if( assignmentList == null ){
			return null;
		}
		List<AssignmentListItemDTO> dtoList = new ArrayList<AssignmentListItemDTO>();
		AssignmentListItemDTO dto = null;
		
		for( Assignment assignment: assignmentList ){
			dto = trans2AssignmentListItemDTO(uid,assignment);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		return dtoList;
	}

	private AssignmentListItemDTO trans2AssignmentListItemDTO(
			Long uid,
			Assignment assignment) {
		if( assignment == null ){
			return null;
		}
		AssignmentListItemDTO dto = new AssignmentListItemDTO();
		
		BeanUtils.copyProperties(assignment, dto);
		
		Long creatorID = assignment.getCreatorID();
		if( creatorID != null ){
			UserDTO creator = userService.getUserDTOByID(creatorID);
			dto.setCreator(creator);
		}
		
		boolean isSubmit = isSubmit(uid,assignment.getId());
		dto.setSubmit(isSubmit);
		return dto;
	}

	public boolean isSubmit(Long uid, Long assignmentID)throws ServiceException {
		AssignmentAnswer answer = assignmentAnswerMapper.getByUIDAndAssignmentID(uid,assignmentID);
		
		if( answer != null ){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public ViewDTO<AssignmentDetailDTO> getAssignment(Long id)
			throws ServiceException {
		ViewDTO<AssignmentDetailDTO> view = new ViewDTO<AssignmentDetailDTO>();
		
		Assignment assignment = assignmentMapper.getByID(id);
		
		AssignmentDetailDTO detailDTO = trans2AssignmentDetailDTO(assignment);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(detailDTO);
		view.setMsg("成功获取作业");
		return view;
	}

	private AssignmentDetailDTO trans2AssignmentDetailDTO(Assignment assignment) {
		if( assignment == null ){
			return null;
		}
		AssignmentDetailDTO dto = new AssignmentDetailDTO();
		
		BeanUtils.copyProperties(assignment, dto);
		
		Long creatorID = assignment.getCreatorID();
		if( creatorID != null ){
			UserDTO creator = userService.getUserDTOByID(creatorID);
			dto.setCreator(creator);
		}
		
		return dto;
	}

	@Override
	public ViewDTO<Boolean> delByID(Long id) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		assignmentMapper.delByID(id);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

}
