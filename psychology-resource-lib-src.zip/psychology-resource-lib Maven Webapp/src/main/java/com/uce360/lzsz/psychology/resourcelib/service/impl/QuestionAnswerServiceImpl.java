package com.uce360.lzsz.psychology.resourcelib.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAnswerMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Answer;
import com.uce360.lzsz.psychology.resourcelib.service.IQuestionAnswerService;

@Service
public class QuestionAnswerServiceImpl implements IQuestionAnswerService {

	@Autowired
	private IAnswerMapper answerMapper;
	
	@Override
	public ViewDTO<Boolean> addQuestionAnswer(AddQuestionAnswerParam param)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Answer answer = new Answer();
		answer.setAnswerUserID(param.getAnswerUserID());
		answer.setContent(param.getContent());
		answer.setQuestionID(param.getQuestionID());
		answerMapper.save(answer);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("添加成功");
		return view;
	}

}
