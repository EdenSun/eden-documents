package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListItemDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.MarkAssignmentAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAssignmentAnswerMapper;
import com.uce360.lzsz.psychology.resourcelib.model.AssignmentAnswer;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentAnswerService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class AssignmentAnswerServiceImpl implements IAssignmentAnswerService {

	@Autowired
	private IAssignmentAnswerMapper assignmentAnswerMapper;

	@Autowired
	private IUserService userService;
	
	@Override
	public ViewDTO<AssignmentAnswerListDTO> listAssignmentAnswer(
			Long assignmentID, PagerDTO pager) {
		ViewDTO<AssignmentAnswerListDTO> view = new ViewDTO<AssignmentAnswerListDTO>();
		AssignmentAnswerListDTO listDTO = new AssignmentAnswerListDTO();
		
		List<AssignmentAnswer> answers = assignmentAnswerMapper.listAnswerByAssngnmentID(assignmentID,pager);
		List<AssignmentAnswerListItemDTO> aaListItemDTO = trans2AssignmentAnswerListItemDTOList(answers);
		listDTO.setAnswers(aaListItemDTO);
		
		int totalCount = assignmentAnswerMapper.listAnswerCountByAssngnmentID(assignmentID);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	private List<AssignmentAnswerListItemDTO> trans2AssignmentAnswerListItemDTOList(
			List<AssignmentAnswer> answers) {
		if( answers == null ){
			return null;
		}
		List<AssignmentAnswerListItemDTO> dtoList = new ArrayList<AssignmentAnswerListItemDTO>();
		AssignmentAnswerListItemDTO dto = null;
		
		for(AssignmentAnswer answer:answers ){
			dto = trans2AssignmentAnswerListItemDTO(answer);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		
		return dtoList;
	}

	private AssignmentAnswerListItemDTO trans2AssignmentAnswerListItemDTO(
			AssignmentAnswer answer) {
		if( answer == null ){
			return null;
		}
		AssignmentAnswerListItemDTO dto = new AssignmentAnswerListItemDTO();
		
		BeanUtils.copyProperties(answer, dto);
		
		Long answerUserID = answer.getAnswerUserID();
		if( answerUserID != null ){
			dto.setAnswerUser(userService.getUserDTOByID(answerUserID));
		}
		
		Long evaluateUserID = answer.getEvaluateUserID();
		if( evaluateUserID != null ){
			dto.setEvaluateUser(userService.getUserDTOByID(evaluateUserID));
		}
		
		return dto;
	}

	@Override
	public ViewDTO<AssignmentAnswerDTO> getAssignmentAnswerByUIDAndAssignmentID(
			Long uid, Long assignmentID) {
		ViewDTO<AssignmentAnswerDTO> view = new ViewDTO<AssignmentAnswerDTO>();
		
		AssignmentAnswer answer = assignmentAnswerMapper.getByUIDAndAssignmentID(uid, assignmentID);
		
		AssignmentAnswerDTO answerDTO = trans2AssignmentAnswerDTO(answer);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(answerDTO);
		view.setMsg("成功获取");
		return view;
	}

	private AssignmentAnswerDTO trans2AssignmentAnswerDTO(
			AssignmentAnswer answer) {
		if( answer == null ){
			return null;
		}
		AssignmentAnswerDTO dto = new AssignmentAnswerDTO();
		
		BeanUtils.copyProperties(answer, dto);
		
		Long answerUserID = answer.getAnswerUserID();
		if( answerUserID != null ){
			dto.setAnswerUser(userService.getUserDTOByID(answerUserID));
			
		}
		
		Long evaluateUserID = answer.getEvaluateUserID();
		if( evaluateUserID != null ){
			dto.setEvaluateUser(userService.getUserDTOByID(evaluateUserID));
		}
		
		return dto;
	}

	@Override
	public ViewDTO<Boolean> saveAssignmentAnswer(Long uid, Long assignmentID,
			String assignmentAnswerContent) {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		AssignmentAnswer answer = new AssignmentAnswer();
		answer.setAnswerUserID(uid);
		answer.setAssignmentID(assignmentID);
		answer.setContent(assignmentAnswerContent);

		assignmentAnswerMapper.save(answer);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("提交作业成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> markAssignmentAnswer(MarkAssignmentAnswerParam param)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		Long aaid = param.getAaid();
		
		AssignmentAnswer assignmentAnswer = assignmentAnswerMapper.getByID(aaid);
		
		if( assignmentAnswer == null ){
			view.setCode(ViewDTO.CODE_FAIL);
			view.setData(false);
			view.setMsg("失败");
			return view;
		}
		assignmentAnswer.setEvaluateUserID( param.getEvaluateUserID() );
		assignmentAnswer.setScore( param.getScore() );
		assignmentAnswer.setTeacherComment( param.getTeacherComment() );
		assignmentAnswerMapper.update( assignmentAnswer );
		
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("成功");
		return view;
	}

}
