package com.uce360.lzsz.psychology.resourcelib.dto.param;

import java.util.List;

public class AddElectiveCourseParam {
	private String name;
	private String description;
	private Long teacherID;
	private List<Long> studentIDAry;
	private Long creatorID;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(Long teacherID) {
		this.teacherID = teacherID;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public List<Long> getStudentIDAry() {
		return studentIDAry;
	}
	public void setStudentIDAry(List<Long> studentIDAry) {
		this.studentIDAry = studentIDAry;
	}
}
