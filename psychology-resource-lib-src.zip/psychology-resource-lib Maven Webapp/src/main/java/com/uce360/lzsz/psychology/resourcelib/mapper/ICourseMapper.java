package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Course;

public interface ICourseMapper {

	List<Course> listCourse(@Param("pager")PagerDTO pager);

	int getCourseCount();

	Course getByID(@Param("courseID")Long courseID);

	void save(@Param("course")Course course);

	List<Course> listAll();

	void delCourse(@Param("courseID")Long courseID);

	List<Course> listAllHomepageCourse();

	void update(@Param("course")Course course);

}
