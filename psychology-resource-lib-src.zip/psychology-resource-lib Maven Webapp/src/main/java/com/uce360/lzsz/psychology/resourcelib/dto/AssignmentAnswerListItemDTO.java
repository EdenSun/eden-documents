package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class AssignmentAnswerListItemDTO {
	private Long id;
	private String content;
	private Long assignmentID;
	private Integer score;
	private String teacherComment;
	private Date createTime;

	private UserDTO answerUser;
	private UserDTO evaluateUser;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getAssignmentID() {
		return assignmentID;
	}
	public void setAssignmentID(Long assignmentID) {
		this.assignmentID = assignmentID;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getTeacherComment() {
		return teacherComment;
	}
	public void setTeacherComment(String teacherComment) {
		this.teacherComment = teacherComment;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public UserDTO getAnswerUser() {
		return answerUser;
	}
	public void setAnswerUser(UserDTO answerUser) {
		this.answerUser = answerUser;
	}
	public UserDTO getEvaluateUser() {
		return evaluateUser;
	}
	public void setEvaluateUser(UserDTO evaluateUser) {
		this.evaluateUser = evaluateUser;
	}
	
}
