package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.dto.ResourceCategoryDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceCategoryParamDTO;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceCategoryService;

@RequestMapping("/admin/rescenter")
@Controller
public class ResCategoryManageController {

	@Autowired
	private IResourceCategoryService resourceCategoryService;
	
	@RequestMapping("/listCateTree")
	@ResponseBody
	public ViewDTO<ResourceCategoryDTO> listCateTree(){
		ViewDTO<ResourceCategoryDTO> view = resourceCategoryService.listCatelist();
		
		return view;
	}
	
	
	@RequestMapping("/delCate")
	@ResponseBody
	public ViewDTO<Boolean> delCate(
			Long id
			){
		ViewDTO<Boolean> view = resourceCategoryService.delCate(id);
		
		return view; 
	}
	
	@RequestMapping("/updateCateName")
	@ResponseBody
	public ViewDTO<Boolean> updateCateName(Long id,String name){
		ViewDTO<Boolean> view = resourceCategoryService.updateCateName(id,name);
		
		return view;
	}
	
	@RequestMapping("/addCate")
	@ResponseBody
	public ViewDTO<ResourceCategoryDTO> addCate(
			@ModelAttribute("resCategoryParamDTO")ResourceCategoryParamDTO resCategoryParamDTO){
		ViewDTO<ResourceCategoryDTO> view = resourceCategoryService.addCate(resCategoryParamDTO);
		
		return view; 
	}
	
	
}
