package com.uce360.lzsz.psychology.resourcelib.util;


public class Constants {

	public static final String SESSION_ID_LOGIN_USER = "SESSION_ID_LOGIN_USER";
	public static final String SESSION_KEY_VALID_CODE = "validCode";
	public static final Integer IS_DELETE_FALSE = 0;
	
	/** FTP windows配置*/
	//public static final String FTP_HTTP_BASE_PATH = "http://127.0.0.1:8080/upload/";
	/** pdf2swf windows 配置*/
//	public static final String PDF2SWF_PATH = "pdf2swf.exe";
	/** xpdf语言包windows配置 */
//	public static final String XPDF_LANG_ZH_DIR = "G:\\xpdf\\xpdf-chinese-simplified";
	
	
	/** FTP 柳州服务器配置*/
//	public static final String FTP_HTTP_BASE_PATH = "http://172.16.0.168:8080/upload/";
	/** pdf2swf linux 配置*/
//	public static final String PDF2SWF_PATH = "/usr/local/swftools/bin/pdf2swf";
	/** xpdf语言包 linux配置 */
//	public static final String XPDF_LANG_ZH_DIR = "/usr/local/swftools/xpdf/xpdf-chinese-simplified";
	
	/** FTP 柳州服务器配置*/
	public static final String FTP_HTTP_BASE_PATH = "http://112.124.71.3:8080/upload/";
	/** pdf2swf linux 配置*/
	public static final String PDF2SWF_PATH = "/usr/local/bin/pdf2swf";
	/** xpdf语言包 linux配置 */
	public static final String XPDF_LANG_ZH_DIR = "/root/appenv/xpdf-chinese-simplified";
	
	
	public static String FTP_HOST_NAME = "127.0.0.1";
	public static int FTP_PORT = 21;
	public static String FTP_USERNAME = "testuser";
	public static String FTP_PASSWORD = "testuser";
	//public static String FTP_FILE_PATH = "upload"; 

}
