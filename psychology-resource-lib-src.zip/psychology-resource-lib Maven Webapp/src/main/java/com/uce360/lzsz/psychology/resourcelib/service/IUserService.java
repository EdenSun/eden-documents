package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.UserParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.model.User;

public interface IUserService {

	User get(String account, String password)throws ServiceException;

	/**
	 * 根据用户ID删除用户
	 * @param userID 用户ID 
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delUser(Long userID)throws ServiceException;

	/**
	 * 添加用户
	 * @param userParam 用户数据对象
	 * @return 返回添加后的用户
	 * @throws ServiceException
	 */
	ViewDTO<UserDTO> addUser(UserParamDTO userParam)throws ServiceException;

	/**
	 * 更新用户
	 * @param userParam 用户数据对象
	 * @return 返回是否成功
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> updateUser(UserParamDTO userParam)throws ServiceException;

	/**
	 * 分页查询用户列表
	 * @param pager 分页数据
	 * @return 返回用户列表
	 * @throws ServiceException
	 */
	ViewDTO<UserListDTO> listUser(PagerDTO pager)throws ServiceException;

	/**
	 * 获取用户DTO
	 * @param uid 用户ID
	 * @return
	 * @throws ServiceException
	 */
	UserDTO getUserDTOByID(Long uid)throws ServiceException;

	/**
	 * 查询所有学生
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<UserDTO>> listAllStudent()throws ServiceException;

	/**
	 * 查询所有老师
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<UserDTO>> listAllTeacher()throws ServiceException;

	List<UserDTO> listAllStudentByECID(Long ecid)throws ServiceException;

	User getUserByID(Long uid)throws ServiceException;

	void addUsers(List<User> userList)throws ServiceException;

}
