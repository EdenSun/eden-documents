package com.uce360.lzsz.psychology.resourcelib.util;

public class ContentType {
	public static final Object PDF = "application/pdf";

}
