package com.uce360.lzsz.psychology.resourcelib.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class BaseController {
	protected Logger log = Logger.getLogger(this.getClass());
	
	protected User getLoginUser(HttpSession session) {
		User user = (User)session.getAttribute(Constants.SESSION_ID_LOGIN_USER);
		
		return user;
	}
}
