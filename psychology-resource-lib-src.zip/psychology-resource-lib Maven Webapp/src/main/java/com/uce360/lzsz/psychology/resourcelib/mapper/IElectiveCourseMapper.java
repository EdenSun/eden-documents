package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.ElectiveCourse;

public interface IElectiveCourseMapper {

	List<ElectiveCourse> listAllByStudentID(@Param("uid")Long uid);

	ElectiveCourse getByID(@Param("courseID")Long courseID);

	List<ElectiveCourse> listByUID(
			@Param("uid")Long uid, 
			@Param("pager")PagerDTO pager);

	int listCountByUID(@Param("uid")Long uid);

	void delByID(@Param("id")Long id);

	void save(@Param("ec")ElectiveCourse ec);

	List<ElectiveCourse> listAll();

	List<ElectiveCourse> listAllByTeacherID(@Param("uid")Long uid);

	void update(@Param("ec")ElectiveCourse ec);

}
