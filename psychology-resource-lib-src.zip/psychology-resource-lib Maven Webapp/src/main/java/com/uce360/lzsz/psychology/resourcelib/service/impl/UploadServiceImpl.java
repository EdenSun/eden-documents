package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UploadListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;
import com.uce360.lzsz.psychology.resourcelib.service.IUploadService;

@Service
public class UploadServiceImpl implements IUploadService {

	@Autowired
	private IResourceService resourceService;
	
	@Override
	public ViewDTO<UploadListDTO> listByUserID(Long uid, PagerDTO pager)
			throws ServiceException {
		ViewDTO<UploadListDTO> view = new ViewDTO<UploadListDTO>();
		UploadListDTO listDTO = new UploadListDTO();
		
		List<ResourceDTO> resList = resourceService.listResByUploaderUID(uid, pager);
		listDTO.setResources(resList);
		
		int totalCount = resourceService.listResCountByUploaderUID(uid);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}


}
