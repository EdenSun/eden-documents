package com.uce360.lzsz.psychology.resourcelib.util;

public class FTPUtil {

}
