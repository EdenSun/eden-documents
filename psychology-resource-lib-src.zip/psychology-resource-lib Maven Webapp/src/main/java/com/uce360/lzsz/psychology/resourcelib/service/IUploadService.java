package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UploadListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IUploadService {

	/**
	 * 查询指定用户的上传列表
	 * @param uid 用户ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<UploadListDTO> listByUserID(Long uid, PagerDTO pager)throws ServiceException;

}
