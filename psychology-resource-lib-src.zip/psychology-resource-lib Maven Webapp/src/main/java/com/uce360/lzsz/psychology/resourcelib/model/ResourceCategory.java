package com.uce360.lzsz.psychology.resourcelib.model;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class ResourceCategory {
	public final static int TYPE_MEDIA = 1;
	public final static int TYPE_COURSE = 2;
	
	private Long id;
	private String name;
	private Integer type;
	private Integer level;
	private Long parentID;
	private Date createTime = new Date();
	private Integer isDelete = Constants.IS_DELETE_FALSE;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Long getParentID() {
		return parentID;
	}
	public void setParentID(Long parentID) {
		this.parentID = parentID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
}
