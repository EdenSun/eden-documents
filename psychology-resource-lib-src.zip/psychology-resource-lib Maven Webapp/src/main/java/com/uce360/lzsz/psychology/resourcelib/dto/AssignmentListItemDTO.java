package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class AssignmentListItemDTO {
	private Long id;
	private String title;
	private String content;
	private Long electiveCourseID;
	private Date createTime;
	
	private UserDTO creator;
	/**登录用户是否已经提交*/
	private boolean isSubmit;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getElectiveCourseID() {
		return electiveCourseID;
	}
	public void setElectiveCourseID(Long electiveCourseID) {
		this.electiveCourseID = electiveCourseID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public UserDTO getCreator() {
		return creator;
	}
	public void setCreator(UserDTO creator) {
		this.creator = creator;
	}
	public boolean isSubmit() {
		return isSubmit;
	}
	public void setSubmit(boolean isSubmit) {
		this.isSubmit = isSubmit;
	}
	
}
