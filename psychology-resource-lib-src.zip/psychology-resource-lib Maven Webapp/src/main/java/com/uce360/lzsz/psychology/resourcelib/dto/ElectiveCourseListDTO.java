package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class ElectiveCourseListDTO {
	private List<ElectiveCourseDTO> courses;
	private PagerDTO pager;
	public List<ElectiveCourseDTO> getCourses() {
		return courses;
	}
	public void setCourses(List<ElectiveCourseDTO> courses) {
		this.courses = courses;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
