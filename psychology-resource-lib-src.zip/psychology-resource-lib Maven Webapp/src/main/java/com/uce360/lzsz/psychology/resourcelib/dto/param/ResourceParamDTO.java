package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class ResourceParamDTO {
	private Long id;
	private String name;
	private String description;
	private Integer faceTo;
	private String keywords;
	private Long mediaCateID;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getFaceTo() {
		return faceTo;
	}
	public void setFaceTo(Integer faceTo) {
		this.faceTo = faceTo;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public Long getMediaCateID() {
		return mediaCateID;
	}
	public void setMediaCateID(Long mediaCateID) {
		this.mediaCateID = mediaCateID;
	}
	
}
