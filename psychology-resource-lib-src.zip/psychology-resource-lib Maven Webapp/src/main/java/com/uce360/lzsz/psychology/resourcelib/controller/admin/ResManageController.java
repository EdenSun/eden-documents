package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceCategoryDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ResourceParamDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Resource;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceCategoryService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;
import com.uce360.lzsz.psychology.resourcelib.util.Constants;
import com.uce360.lzsz.psychology.resourcelib.util.ContentType;
import com.uce360.lzsz.psychology.resourcelib.util.FileUtil;
import com.uce360.lzsz.psychology.resourcelib.util.ResourceUtil;
import com.uce360.lzsz.psychology.resourcelib.util.UploadUtil;


@RequestMapping("/admin/rescenter")
@Controller
public class ResManageController extends BaseController{

	@Autowired
	private IResourceService resourceService;
	
	@Autowired
	private IResourceCategoryService resourceCategoryService;
	
	
	@RequestMapping("/uploadRes")
	@ResponseBody
	public ResourceDTO uploadRes(
			HttpSession session,
			@RequestParam("file")CommonsMultipartFile file) throws IOException{
		ResourceDTO fileDTO = new ResourceDTO();
		/*fileDTO.setContentType(file.getContentType());
		fileDTO.setSize(file.getSize());
		
		fileDTO.setOriginalFilename(file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf(".")) );
*/		
		String contentType = file.getContentType();
		String suffix = FileUtil.getSuffix(file.getOriginalFilename());
		
        // 判断文件是否存在 
        if (!file.isEmpty()) { 
        	String fileName = null;
        	String fileNameBase = UUID.randomUUID().toString();
        	if( suffix != null ){
        		fileName = fileNameBase + "." + suffix;
        	}else{
        		fileName = fileNameBase;
        	}
        	String path = UploadUtil.uploadFile(fileName, file.getInputStream());
            
        	/*fileDTO.setBasePath(Constants.FTP_HTTP_BASE_PATH);
        	fileDTO.setPath(path);*/
        	fileDTO.setFormatStr(ResourceUtil.getFormatStr(suffix));
        	
        	Resource resource = new Resource();
            resource.setAuditStatus( Resource.AUDIT_STATUS_WAITTING_FOR_AUDIT );
            resource.setSize(file.getSize());
            resource.setFormat(ResourceUtil.getFormatBySuffix(suffix));
            resource.setUrl(path);
            resource.setName(file.getOriginalFilename());
            
            //FIXME:
            resource.setCreatorID( getLoginUser(session).getId() );
            resource.setCreatorID( 1L );
            
            //转换文档
            if( contentType.equals( ContentType.PDF ) ){
            	//PDF 文档
            	/* 获取临时文件目录 */
            	String tmpDirectory = System.getProperty("java.io.tmpdir");
            	File tempDir = new File(tmpDirectory);  
                //如果该文件夹不存在，则创建  
                if(!tempDir.exists()){  
                    tempDir.mkdirs();  
                } 

            	//保存pdf到本地临时文件
                File pdfFile = new File(tempDir,fileName);
                FileOutputStream fos = null;
                try {
					//写入数据
					fos = new FileOutputStream(pdfFile);
					fos.write(file.getBytes());
					fos.flush();
				} catch (Exception e) {
					log.error("创建PDF文件失败",e);
					return null;
				}finally{
					if( fos != null ){
						try {
							fos.close();
						} catch (Exception e) {
							log.error("关闭流失败",e);
							return null;
						}
					}
				}
            	
            	/* pdf转换swf */
                String swfFileName = fileNameBase + ".swf";
                String swfFilePath = tempDir + File.separator + swfFileName;
                File swfFile = new File(swfFilePath);
                Process process = Runtime.getRuntime().exec(Constants.PDF2SWF_PATH + " "+ pdfFile.getAbsolutePath() +" -o " + swfFilePath + " -f -T 9 -t -s storeallcharacters -s languagedir=" + Constants.XPDF_LANG_ZH_DIR );
            	
                /*为"错误输出流"单独开一个线程读取之,否则会造成标准输出流的阻塞*/
                Thread t=new Thread(new InputStreamRunnable(process.getInputStream(),"InputStream"));  
                t.start();  
                
                try {
					//等待转换完成
					process.waitFor();
				} catch (InterruptedException e1) {
					log.error("转换swf进程中断",e1);
					return null;
				}
            	
            	byte[] swfBytes;
            	FileInputStream fis = null;
            	ByteArrayOutputStream baos = null;
				try {
					
					fis = new FileInputStream(swfFile);
					
					baos = new ByteArrayOutputStream();
					
					byte[] buffer = new byte[1024];
					
					while( fis.read(buffer) != -1 ){
						baos.write(buffer);
					}
					swfBytes = baos.toByteArray();
				} catch (Exception e) {
					log.error("读取swf失败",e);
					return null;
				}finally{
					if( fis != null ){
						try {
							fis.close();
						} catch (Exception e) {
							log.error("关闭流失败",e);
							return null;
						}
					}
					if( baos != null ){
						try {
							baos.close();
						} catch (Exception e) {
							log.error("关闭流失败",e);
							return null;
						}
					}
				}
            	
            	//上传swf到FTP
            	String swfPath = UploadUtil.uploadFile(swfFileName, new ByteArrayInputStream(swfBytes) );
                
            	/* 清理文件，删除PDF与SWF */
            	pdfFile.delete();
            	swfFile.delete();
            	
            	//设置地址
            	resource.setOnlineReadUrl(swfPath);
            }
            
            fileDTO = resourceService.addResource(resource);
        }  
        
        return fileDTO;  
	}
	
	class InputStreamRunnable implements Runnable  
	{  
	    BufferedReader bReader=null;  
	    String type=null;  
	    public InputStreamRunnable(InputStream is, String _type)  
	    {  
	        try  
	        {  
	            bReader=new BufferedReader(new InputStreamReader(new BufferedInputStream(is),"UTF-8"));  
	            type=_type;  
	        }  
	        catch(Exception ex)  
	        {  
	        }  
	    }  
	    public void run()  
	    {  
	        String line;  
	        int lineNum=0;  
	  
	        try  
	        {  
	            while((line=bReader.readLine())!=null)  
	            {  
	                lineNum++; 
	                log.debug(line);
	                //Thread.sleep(200);  
	            }  
	        }  
	        catch(Exception ex) { 
	        	ex.printStackTrace();
	        }finally{
	        	if( bReader != null ){
	        		try {
						bReader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
	        	}
	        }
	    }  
	}  
	/*@RequestMapping("/addRes")
	@ResponseBody
	public ViewDTO<ResourceDTO> addRes(
		HttpSession session,
		@RequestParam("resource")AddResourceParamDTO resource
		){
		User user = getLoginUser(session);
		
		resource.setCreatorID( user.getId() );
		resource.setAuditStatus(Resource.AUDIT_STATUS_WAITTING_FOR_AUDIT);
		ViewDTO<ResourceDTO> view = resourceService.addResource(resource);
		
		return view;
	}*/
	

	@RequestMapping("/auditRes")
	@ResponseBody
	public ViewDTO<Boolean> auditRes(
		Long resourceID,
		Integer auditStatus
		){
		ViewDTO<Boolean> view = resourceService.auditRes(resourceID,auditStatus);
		
		return view;
	}
	
	@RequestMapping("/updateRes")
	@ResponseBody
	public ViewDTO<Boolean> updateRes(
			@ModelAttribute("resource")ResourceParamDTO resource	
		){
		ViewDTO<Boolean> view = resourceService.updateRes(resource);
		
		return view;
	}
	
	@RequestMapping("/delRes")
	@ResponseBody
	public ViewDTO<Boolean> delRes(
		Long resourceID	
		){
		ViewDTO<Boolean> view = resourceService.delRes(resourceID);
		
		return view;
	}
	
	@RequestMapping("/listRes")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listRes(
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<ResourceListDTO> view = resourceService.listResourceByCategory(null,null, pager);
		
		return view;
	}
	
	
	@RequestMapping("/listAllMediaCate")
	@ResponseBody
	public ViewDTO<List<ResourceCategoryDTO>> listAllMediaCate(){
		ViewDTO<List<ResourceCategoryDTO>> view = resourceCategoryService.listAllMediaCate();
		
		return view;
	}
	
	@RequestMapping("/listAllCourseCate")
	@ResponseBody
	public ViewDTO<List<ResourceCategoryDTO>> listAllCourseCate(){
		ViewDTO<List<ResourceCategoryDTO>> view = resourceCategoryService.listAllCourseCate();
		
		return view;
	}
}
