package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;

public interface IUserMapper {

	User getByAccountAndPassword(
			@Param("account")String account, 
			@Param("password")String password);

	void delUser(@Param("userID")Long userID);

	void save(@Param("user")User user);

	User getByID(@Param("uid")Long uid);

	void update(@Param("user")User user);

	List<User> listUser(@Param("pager")PagerDTO pager);

	int listUserCount();

	List<User> listAllByRoleType(@Param("roleType")int roleType);

	List<User> listAllStudentByECID(@Param("ecid")Long ecid);

}
