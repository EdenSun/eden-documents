package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class QuestionAnswerDTO {
	private Long id;
	private String content;
	private Long questionID;
	private Date createTime;
	private Integer isDelete;
	
	private UserDTO answerUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getQuestionID() {
		return questionID;
	}

	public void setQuestionID(Long questionID) {
		this.questionID = questionID;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public UserDTO getAnswerUser() {
		return answerUser;
	}

	public void setAnswerUser(UserDTO answerUser) {
		this.answerUser = answerUser;
	}
	
}
