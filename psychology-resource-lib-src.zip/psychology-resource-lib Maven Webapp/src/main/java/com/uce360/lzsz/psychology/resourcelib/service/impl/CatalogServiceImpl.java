package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.inject.spi.Bean;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.CatalogDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CatalogParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.ICatalogMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Catalog;
import com.uce360.lzsz.psychology.resourcelib.service.ICatalogService;

@Service
public class CatalogServiceImpl implements ICatalogService {

	@Autowired
	private ICatalogMapper catalogMapper;
	
	@Override
	public ViewDTO<List<CatalogDTO>> listChapterByCourse(Long courseID)
			throws ServiceException {
		ViewDTO<List<CatalogDTO>> view = new ViewDTO<List<CatalogDTO>>();
		
		List<Catalog> catalogList = catalogMapper.listChapterByCourseID(courseID);
		
		List<CatalogDTO> dtoList = trans2CatalogDTOList(catalogList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	private List<CatalogDTO> trans2CatalogDTOList(List<Catalog> catalogList) {
		if( catalogList == null ){
			return null;
		}
		List<CatalogDTO> dtoList = new ArrayList<CatalogDTO>();
		CatalogDTO dto = null;
		
		for(Catalog c: catalogList){
			dto = trans2CatalogDTO(c);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		return dtoList;
	}

	private CatalogDTO trans2CatalogDTO(Catalog c) {
		if( c == null ){
			return null;
		}
		CatalogDTO dto = new CatalogDTO();
		
		BeanUtils.copyProperties(c, dto);
		
		return dto;
	}

	@Override
	public ViewDTO<List<CatalogDTO>> listSection(Long chapterID)
			throws ServiceException {
		ViewDTO<List<CatalogDTO>> view = new ViewDTO<List<CatalogDTO>>();
		
		List<Catalog> catalogList = catalogMapper.listSectionByChapterID(chapterID);
		
		List<CatalogDTO> dtoList = trans2CatalogDTOList(catalogList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<CatalogDTO> addCatalog(CatalogParamDTO catalogParam)
			throws ServiceException {
		ViewDTO<CatalogDTO> view = new ViewDTO<CatalogDTO>();
		
		Catalog catalog = new Catalog();
		
		BeanUtils.copyProperties(catalogParam, catalog);
		
		catalogMapper.save(catalog);
		
		if( catalogParam.getLevel() == Catalog.LEVEL_SECTION ){
			/**
			 * 如果增加的是节，为每个节创建4中类型子目录：
			 * 1. 电子素材
			 * 2. 媒体素材
			 * 3. 试题
			 * 4. 文献资料
			 */
			Catalog subDirCatalog = new Catalog();
			String[] catalogNameAry = new String[]{
				"电子素材",
				"媒体素材",
				"试题",
				"文献资料"
			};
			
			for(int i=0;i< catalogNameAry.length ;i++){
				String curName = catalogNameAry[i];
				
				subDirCatalog.setCourseID(catalogParam.getCourseID());
				subDirCatalog.setLevel(Catalog.LEVEL_SUB_DIRECTORY);
				subDirCatalog.setName(curName);
				subDirCatalog.setParentID(catalog.getId());
				
				catalogMapper.save(subDirCatalog);
			}
			
		}
		
		CatalogDTO catalogDTO = trans2CatalogDTO(catalog);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(catalogDTO);
		view.setMsg("插入成功");
		return view;
	}

	@Override
	public ViewDTO<List<CatalogDTO>> listSubDir(Long sectionID)
			throws ServiceException {
		ViewDTO<List<CatalogDTO>> view = new ViewDTO<List<CatalogDTO>>();
		
		List<Catalog> catalogList = catalogMapper.listByParent(sectionID);
		
		List<CatalogDTO> dtoList = trans2CatalogDTOList(catalogList);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delChapter(Long chapterID) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Catalog chapter = catalogMapper.getByID(chapterID);
		
		//catalogMapper.delByCourseAndGtLevel(chapter.getCourseID(),chapter.getLevel());
		
		catalogMapper.delByID( chapterID );
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

	
}
