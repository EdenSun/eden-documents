package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;

@Controller
@RequestMapping("/admin")
public class AdminMainController extends BaseController{

	@RequestMapping("/home")
	public ModelAndView home(){
		ModelAndView mav = new ModelAndView("admin/admin-home");
		
		return mav;
	}
	
	@RequestMapping("/user-manage")
	public ModelAndView userManage(){
		ModelAndView mav = new ModelAndView("admin/user-manage");
		
		return mav;
	}
	
	@RequestMapping("/resource-manage")
	public ModelAndView resourceManage(){
		ModelAndView mav = new ModelAndView("admin/resource-manage");
		
		return mav;
	}
	
	@RequestMapping("/channel-manage")
	public ModelAndView channelManage(){
		ModelAndView mav = new ModelAndView("admin/channel-manage");
		
		return mav;
	}
	
	@RequestMapping("/resource-category-manage")
	public ModelAndView resourceCategoryManage(){
		ModelAndView mav = new ModelAndView("admin/resource-category-manage");
		
		return mav;
	}
	
	@RequestMapping("/course-manage")
	public ModelAndView courseManage(){
		ModelAndView mav = new ModelAndView("admin/course-manage");
		
		return mav;
	}
	
	
	@RequestMapping("/elective-course-manage")
	public ModelAndView electiveCourseManage(){
		ModelAndView mav = new ModelAndView("admin/elective-course-manage");
		
		return mav;
	}
	
	@RequestMapping("/ec-assignment-manage")
	public ModelAndView ecAssignmentManage(){
		ModelAndView mav = new ModelAndView("admin/ec-assignment-manage");
		
		return mav;
	}
	
	
	@RequestMapping("/ec-ask-manage")
	public ModelAndView ecAskManage(){
		ModelAndView mav = new ModelAndView("admin/ec-ask-manage");
		
		return mav;
	}
	
	
	
}
