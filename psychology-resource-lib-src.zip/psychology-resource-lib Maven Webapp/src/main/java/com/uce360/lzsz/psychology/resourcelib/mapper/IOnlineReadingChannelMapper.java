package com.uce360.lzsz.psychology.resourcelib.mapper;

public interface IOnlineReadingChannelMapper {

}
