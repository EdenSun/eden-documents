package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class DownloadListDTO {
	private List<DownloadItemDTO> downloads;
	private PagerDTO pager;
	public List<DownloadItemDTO> getDownloads() {
		return downloads;
	}
	public void setDownloads(List<DownloadItemDTO> downloads) {
		this.downloads = downloads;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
