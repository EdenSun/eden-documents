package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class ElectiveCourseDTO {
	private Long id;
	private String name;
	private String description;
	private Long teacherID;
	private Date createTime;
	
	private UserDTO teacher;
	private UserDTO creator;
	private String studentsStrList;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(Long teacherID) {
		this.teacherID = teacherID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public UserDTO getCreator() {
		return creator;
	}
	public void setCreator(UserDTO creator) {
		this.creator = creator;
	}
	public UserDTO getTeacher() {
		return teacher;
	}
	public void setTeacher(UserDTO teacher) {
		this.teacher = teacher;
	}
	public String getStudentsStrList() {
		return studentsStrList;
	}
	public void setStudentsStrList(String studentsStrList) {
		this.studentsStrList = studentsStrList;
	}
}
