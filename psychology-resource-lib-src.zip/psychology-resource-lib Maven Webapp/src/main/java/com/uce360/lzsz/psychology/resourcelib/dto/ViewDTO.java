package com.uce360.lzsz.psychology.resourcelib.dto;


public class ViewDTO<T> {
	public static final int CODE_SUCCESS = 0;
	public static final int CODE_FAIL = -1;
	
	//AuthController 
	
	/**
	 * 返回码
	 */
	private int code;
	
	/**
	 * 数据
	 */
	private T data;
	
	/**
	 * 文本信息
	 */
	private String msg;
	
	public ViewDTO() {
		super();
		code = CODE_FAIL;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
