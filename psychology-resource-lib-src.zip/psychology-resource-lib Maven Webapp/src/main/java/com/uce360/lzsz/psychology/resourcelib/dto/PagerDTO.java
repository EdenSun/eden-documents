package com.uce360.lzsz.psychology.resourcelib.dto;

public class PagerDTO {
	public static int PAGE_DEFAULT = 1 ;
	public static int PAGE_SIZE_DEFAULT = 10 ;
	
	private int page ;
	private int pageSize ;
	private int totalCount;
	private int totalPage;
	
	private int start;
	
	public PagerDTO() {
		super();
		setPage(PAGE_DEFAULT);
		setPageSize(PAGE_SIZE_DEFAULT);
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
		this.start = (page-1)*pageSize;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
		this.start = (page-1)*pageSize;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		this.totalPage = (int)Math.ceil( (double)totalCount/this.pageSize );
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}
	
}
