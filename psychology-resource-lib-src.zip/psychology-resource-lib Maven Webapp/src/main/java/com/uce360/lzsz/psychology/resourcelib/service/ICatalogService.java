package com.uce360.lzsz.psychology.resourcelib.service;

import java.util.List;

import com.uce360.lzsz.psychology.resourcelib.dto.CatalogDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.CatalogParamDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface ICatalogService {

	/**
	 * 查询课程下的章 
	 * @param courseID 课程ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CatalogDTO>> listChapterByCourse(Long courseID)throws ServiceException;

	/**
	 * 查询指定章下的节
	 * @param chapterID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CatalogDTO>> listSection(Long chapterID)throws ServiceException;

	/**
	 * 添加分类
	 * @param catalogParam
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<CatalogDTO> addCatalog(CatalogParamDTO catalogParam)throws ServiceException;

	/**
	 * 获取节下的子目录列表
	 * @param sectionID 节ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<List<CatalogDTO>> listSubDir(Long sectionID)throws ServiceException;

	/**
	 * 删除章节
	 * @param chapterID 章节ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delChapter(Long chapterID)throws ServiceException;

}
