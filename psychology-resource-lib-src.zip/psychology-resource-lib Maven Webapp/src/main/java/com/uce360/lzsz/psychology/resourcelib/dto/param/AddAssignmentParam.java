package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class AddAssignmentParam {
	private String title;
	private String content;
	private Long electiveCourseID;
	private Long creatorID;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Long getElectiveCourseID() {
		return electiveCourseID;
	}
	public void setElectiveCourseID(Long electiveCourseID) {
		this.electiveCourseID = electiveCourseID;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}

}
