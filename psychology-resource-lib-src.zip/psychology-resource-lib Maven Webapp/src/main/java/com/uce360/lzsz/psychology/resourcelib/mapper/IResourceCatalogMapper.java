package com.uce360.lzsz.psychology.resourcelib.mapper;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.model.Catalog;
import com.uce360.lzsz.psychology.resourcelib.model.ResourceCatalog;

public interface IResourceCatalogMapper {

	void save(@Param("rc")ResourceCatalog rc);

	void deleteByCatalogID(@Param("catalogID")Long catalogID);

	ResourceCatalog getByCatalogIDAndResourceID(
			@Param("catalogID")Long catalogID, 
			@Param("resID")Long resID);
}
