package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.DownloadListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IDownloadService {

	/**
	 * 分页查询用户的下载列表
	 * @param uid 用户ID
	 * @param pager 分页数据
	 * @return 分页返回用户下载列表
	 * @throws ServiceException
	 */
	ViewDTO<DownloadListDTO> listByUserID(Long uid, PagerDTO pager)throws ServiceException;

	/**
	 * 根据ID删除指定的下载记录
	 * @param downloadID
	 * @return
	 */
	ViewDTO<Boolean> delByID(Long downloadID)throws ServiceException;

	/**
	 * 添加下载记录
	 * @param uid 用户ID
	 * @param resID 资源ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addMyDownload(Long uid, Long resID)throws ServiceException;

}
