package com.uce360.lzsz.psychology.resourcelib.controller.front;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.dto.CourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceCategoryDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.service.ICourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceCategoryService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;

@RequestMapping("/rc/json")
@Controller
public class ResourceCenterJSONController {

	@Autowired
	private IResourceCategoryService resourceCategoryService;
	
	@Autowired
	private ICourseService courseService;
	
	@Autowired
	private IResourceService resourceService;
	
	@RequestMapping("/catelist")
	@ResponseBody
	public ViewDTO<ResourceCategoryDTO> catelist(){
		ViewDTO<ResourceCategoryDTO> view = resourceCategoryService.listCatelist();
		
		return view;
	}
	
	@RequestMapping("/listResByCategory")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listResByCategory(
			Long cateID,
			@ModelAttribute("pager")PagerDTO pager
			){
		ViewDTO<ResourceListDTO> view = resourceService.listResByCategoryID(cateID,2,pager);
		
		return view;
	}
	
	@RequestMapping("/listAllResByCategory")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listAllResByCategory(
			Long cateID
			){
		ViewDTO<ResourceListDTO> view = resourceService.listAllResByCategoryID(cateID,2);
		
		return view;
	}
	
	
	@RequestMapping("/listCourseCateList")
	@ResponseBody
	public ViewDTO<List<ResourceCategoryDTO>> listCourseCateList(){
		ViewDTO<List<ResourceCategoryDTO>> view = resourceCategoryService.listAllCourseCate();
		
		return view;
	}
	
	@RequestMapping("/listAllCourse")
	@ResponseBody
	public ViewDTO<List<CourseDTO>> listAllCourse(){
		ViewDTO<List<CourseDTO>> view = courseService.listAllCourse();
		
		return view;
	}
	
	@RequestMapping("/listResByCourse")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listResByCourse(
		Long courseID,
		@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<ResourceListDTO> view = resourceService.listResByCourse(courseID,pager);
		
		return view;
	}
	
}
