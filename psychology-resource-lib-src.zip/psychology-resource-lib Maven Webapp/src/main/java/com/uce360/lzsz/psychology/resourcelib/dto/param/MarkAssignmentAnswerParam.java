package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class MarkAssignmentAnswerParam {
	private Long evaluateUserID;
	private Long aaid;
	private Integer score;
	private String teacherComment;
	public Long getEvaluateUserID() {
		return evaluateUserID;
	}
	public void setEvaluateUserID(Long evaluateUserID) {
		this.evaluateUserID = evaluateUserID;
	}
	public Long getAaid() {
		return aaid;
	}
	public void setAaid(Long aaid) {
		this.aaid = aaid;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getTeacherComment() {
		return teacherComment;
	}
	public void setTeacherComment(String teacherComment) {
		this.teacherComment = teacherComment;
	}
}
