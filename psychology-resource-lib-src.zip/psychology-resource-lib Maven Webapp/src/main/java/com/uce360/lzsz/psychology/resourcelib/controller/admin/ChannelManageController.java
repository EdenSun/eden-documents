package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;


@RequestMapping("/admin/channel")
@Controller
public class ChannelManageController {
	
	@Autowired
	private IResourceService resourceService;
	
	@RequestMapping("/addResToChannel")
	@ResponseBody
	public ViewDTO<Boolean> addResToChannel(
		Long channelID,
		Long resID
		){
		ViewDTO<Boolean> view = resourceService.addResToChannel(channelID,resID);
		
		return view;
	}

	@RequestMapping("/delFromChannel")
	@ResponseBody
	public ViewDTO<Boolean> delFromChannel(
			Long channelID,
			Long resID
		){
		ViewDTO<Boolean> view = resourceService.delFromChannel(channelID,resID);
		
		return view;
	}
	
	@RequestMapping("/searchOnlineResByKeywords")
	@ResponseBody
	public ViewDTO<ResourceListDTO> searchByKeywords(
			String keywords,
			@ModelAttribute("pager")PagerDTO pager
			){
		try {
			keywords = URLDecoder.decode(keywords, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		ViewDTO<ResourceListDTO> view = resourceService.searchOnlineResByKeywords(keywords,pager);
		
		return view;
	}
	
	@RequestMapping("/listResByChannel")
	@ResponseBody
	public ViewDTO<ResourceListDTO> listResByChannel(
			Long channelID,
			@ModelAttribute("pager")PagerDTO pager
			){
		ViewDTO<ResourceListDTO> view = resourceService.listResByChannel(channelID,pager);
		
		return view;
	}
	
}
