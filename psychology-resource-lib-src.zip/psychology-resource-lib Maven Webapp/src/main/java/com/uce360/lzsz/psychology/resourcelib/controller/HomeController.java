package com.uce360.lzsz.psychology.resourcelib.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.uce360.lzsz.psychology.resourcelib.dto.CourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ResourceListDTO;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.ICourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IResourceService;

@Controller
@RequestMapping("")
public class HomeController extends BaseController{
	@Autowired
	private ICourseService courseService;
	
	@Autowired
	private IResourceService resourceService;
	
	@RequestMapping("/index")
	public ModelAndView index(HttpSession session){
		User user = getLoginUser(session);
		
		ModelAndView mav = new ModelAndView("index");
		
		List<CourseDTO> homepageCourseList = courseService.listAllHomepageCourse();
		mav.addObject("homepageCourseList",homepageCourseList);
		
		mav.addObject("channel", "index");
		return mav;
	}
	
	@RequestMapping("/psycology-test")
	public ModelAndView psycologyTest(){
		ModelAndView mav = new ModelAndView("psycology-test");
		
		
		mav.addObject("channel", "psycology-test");
		return mav;
	}
	
	@RequestMapping("/specialty-construction")
	public ModelAndView specialtyConstruction(){
		ModelAndView mav = new ModelAndView("specialty-construction");
		
		mav.addObject("channel", "specialty-construction");
		return mav;
	}
	
	
	@RequestMapping("/case-center")
	public ModelAndView caseCenter(){
		ModelAndView mav = new ModelAndView("case-center");
		
		mav.addObject("channel", "case-center");
		return mav;
	}
	
	
	@RequestMapping("/course-center")
	public ModelAndView courseCenter(){
		ModelAndView mav = new ModelAndView("course-center");
		
		mav.addObject("channel", "course-center");
		return mav;
	}
	
	@RequestMapping("/resource-center")
	public ModelAndView resourceCenter(){
		ModelAndView mav = new ModelAndView("resource-center");
		
		mav.addObject("channel", "resource-center");
		return mav;
	}
	
	@RequestMapping("/course-index")
	public ModelAndView courseIndex(
			Long courseID
		){
		ModelAndView mav = new ModelAndView("course-index");
		
		CourseDTO course = courseService.getByID(courseID);
		
		mav.addObject("course", course);
		return mav;
	}
	
	@RequestMapping("/search-result")
	public ModelAndView searchResult(
			Long courseID,
			String keywords,
			@ModelAttribute("pager")PagerDTO pager
		) throws UnsupportedEncodingException{
		ModelAndView mav = new ModelAndView("search-result");
		
		String decodedKeywords = new String(keywords.getBytes("iso-8859-1"), "UTF-8" );
		
		ResourceListDTO resListDTO = resourceService.listResByKeywords(decodedKeywords,pager);
		mav.addObject("resListDTO", resListDTO);
		mav.addObject("decodedKeywords", decodedKeywords);
		
		return mav;
	}
}
