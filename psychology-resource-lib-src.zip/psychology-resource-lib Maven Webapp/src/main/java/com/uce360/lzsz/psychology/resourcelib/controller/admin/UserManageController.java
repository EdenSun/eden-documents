package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.UserParamDTO;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@RequestMapping("/admin/user")
@Controller
public class UserManageController extends BaseController{

	@Autowired
	private IUserService userService;
	
	@RequestMapping("/addUser")
	@ResponseBody
	public ViewDTO<UserDTO> addUser(
			@ModelAttribute("userParam")UserParamDTO userParam
		){
		ViewDTO<UserDTO> view = userService.addUser(userParam);
		
		return view;
	}
	
	@RequestMapping("/updateUser")
	@ResponseBody
	public ViewDTO<Boolean> updateUser(
			@RequestParam("userParam")UserParamDTO userParam
		){
		ViewDTO<Boolean> view = userService.updateUser(userParam);
		
		return view;
	}
	
	@RequestMapping("/delUser")
	@ResponseBody
	public ViewDTO<Boolean> delUser(
			Long userID
		){
		ViewDTO<Boolean> view = userService.delUser(userID);
		
		return view;
	}
	
	
	@RequestMapping("/listUser")
	@ResponseBody
	public ViewDTO<UserListDTO> listUser(
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<UserListDTO> view = userService.listUser(pager);
		
		return view;
	}
	
}
