package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.List;

public class UserListDTO {
	private List<UserDTO> users;
	private PagerDTO pager;
	public List<UserDTO> getUsers() {
		return users;
	}
	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}
	public PagerDTO getPager() {
		return pager;
	}
	public void setPager(PagerDTO pager) {
		this.pager = pager;
	}
}
