package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IQuestionService {

	/**
	 * 分页查询指定课程问题
	 * @param param 条件对象
	 * @param pager 分页数据
	 * @return 分页返回指定课程的问题
	 * @throws ServiceException
	 */
	ViewDTO<QuestionListDTO> listQuestion(ListQuestionParam param,
			PagerDTO pager)throws ServiceException;

	/**
	 * 添加问题
	 * @param param 参数
	 * @return 返回添加成功的问题
	 * @throws ServiceException
	 */
	ViewDTO<QuestionDTO> addQuestion(AddQuestionParam param)throws ServiceException;

	/**
	 * 根据ID获取问题
	 * @param qid 问题ID
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<QuestionDTO> getQuestion(Long qid)throws ServiceException;

	/**
	 * 根据问题ID 获取问题答案
	 * @param qid 问题ID
	 * @param pager 分页数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<QuestionAnswerListDTO> listQuestionAnswer(Long qid, PagerDTO pager)throws ServiceException;

	/**
	 * 提交问题答案
	 * @param uid 用户ID
	 * @param qid 问题ID 
	 * @param content 答案内容
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> submitQuestionAnswer(Long uid, Long qid, String content)throws ServiceException;

	/**
	 * 根据ID 删除问题
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> delByID(Long id)throws ServiceException;

}
