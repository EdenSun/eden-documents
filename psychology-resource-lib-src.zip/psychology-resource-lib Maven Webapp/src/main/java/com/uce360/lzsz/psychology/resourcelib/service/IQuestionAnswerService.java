package com.uce360.lzsz.psychology.resourcelib.service;

import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;

public interface IQuestionAnswerService {

	/**
	 * 添加问题答案
	 * @param param 参数数据
	 * @return
	 * @throws ServiceException
	 */
	ViewDTO<Boolean> addQuestionAnswer(AddQuestionAnswerParam param)throws ServiceException;

}
