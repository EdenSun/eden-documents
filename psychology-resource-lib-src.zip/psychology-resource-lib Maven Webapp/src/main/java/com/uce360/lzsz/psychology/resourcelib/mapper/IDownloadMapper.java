package com.uce360.lzsz.psychology.resourcelib.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.model.Download;

public interface IDownloadMapper {

	List<Download> listByUserID(
			@Param("uid")Long uid, 
			@Param("pager")PagerDTO pager);

	int listCountByUserID(@Param("uid")Long uid);

	void delByID(@Param("id")Long id);

	void save(@Param("download")Download download);

}
