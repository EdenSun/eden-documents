package com.uce360.lzsz.psychology.resourcelib.controller.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uce360.lzsz.psychology.resourcelib.controller.BaseController;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.AssignmentListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionAnswerListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.QuestionListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddAssignmentParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddElectiveCourseParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddQuestionAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.ListQuestionParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.MarkAssignmentAnswerParam;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentAnswerService;
import com.uce360.lzsz.psychology.resourcelib.service.IAssignmentService;
import com.uce360.lzsz.psychology.resourcelib.service.IElectiveCourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IQuestionAnswerService;
import com.uce360.lzsz.psychology.resourcelib.service.IQuestionService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Controller
@RequestMapping("/admin/ec")
public class ElectiveCourseManageController extends BaseController{

	@Autowired
	private IElectiveCourseService electiveCourseService;
	
	@Autowired
	private IAssignmentService assignmentService;
	
	@Autowired
	private IAssignmentAnswerService assignmentAnswerService;
	
	@Autowired
	private IQuestionService questionService;
	
	@Autowired
	private IQuestionAnswerService questionAnswerService;
	
	@Autowired
	private IUserService userService;
	
	@ResponseBody
	@RequestMapping("/list-elective-course")
	public ViewDTO<ElectiveCourseListDTO> listElectiveCourse(
		HttpSession session,
		String filter,
		@ModelAttribute("pager")PagerDTO pager
		){
		User user = getLoginUser(session);
		
		Long uid = null;
		if( filter.equals( "all" ) ){
			uid = null;
		}else{
			uid = user.getId();
		}
		ViewDTO<ElectiveCourseListDTO>  view = electiveCourseService.listElectiveCourseByUID(uid,pager);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/list-all-ec")
	public ViewDTO<List<ElectiveCourseDTO>> listAllEC(
		HttpSession session
		){
		ViewDTO<List<ElectiveCourseDTO>>  view = electiveCourseService.listAll();
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/del-elective-course")
	public ViewDTO<Boolean> delElectiveCourse(
			Long id
		){
		ViewDTO<Boolean> view = electiveCourseService.delElectiveCourse(id);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/add-elective-course")
	public ViewDTO<Boolean> addElectiveCourse(
			HttpSession session,
			@ModelAttribute("param")AddElectiveCourseParam param,
			@RequestParam("studentIDList[]")List<Long> studentIDList
		){
		param.setStudentIDAry(studentIDList);
		User user = getLoginUser(session);
		
		param.setCreatorID(user.getId());
		ViewDTO<Boolean> view = electiveCourseService.addElectiveCourse(param);
		
		return view;
	}
	
	
	@ResponseBody
	@RequestMapping("/list-ec-assignment")
	public ViewDTO<AssignmentListDTO> listEcAssignment(
		HttpSession session,
		Long ecID,
		String filter,
		@ModelAttribute("pager")PagerDTO pager
		){
		User user = getLoginUser(session);
		
		Long uid = null;
		if( filter.equals( "all" ) ){
			uid = null;
		}else{
			uid = user.getId();
		}
		
		ViewDTO<AssignmentListDTO>  view = assignmentService.listAssignmentForAdmin(uid, ecID, pager);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/add-assignment")
	public ViewDTO<Boolean> addAssignment(
			HttpSession session,
			@ModelAttribute("param")AddAssignmentParam param
		){
		User user = getLoginUser(session);
		param.setCreatorID(user.getId());
		
		ViewDTO<Boolean> view = electiveCourseService.addAssignment(param);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/del-ec-assignment")
	public ViewDTO<Boolean> delECAssignment(
			HttpSession session,
			Long id
		){
		ViewDTO<Boolean> view = assignmentService.delByID(id);
		
		return view;
	}
	

	
	@ResponseBody
	@RequestMapping("/list-assignment-answer")
	public ViewDTO<AssignmentAnswerListDTO> listAssignmentAnswer(
			HttpSession session,
			Long assignmentID,
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<AssignmentAnswerListDTO> view = assignmentAnswerService.listAssignmentAnswer( assignmentID, pager);
		
		return view;
	}
	
	
	@ResponseBody
	@RequestMapping("/mark-assignment-answer")
	public ViewDTO<Boolean> markAssignmentAnswer(
			HttpSession session,
			@ModelAttribute("param")MarkAssignmentAnswerParam param
		){
		User user = getLoginUser(session);
		param.setEvaluateUserID(user.getId());
		
		ViewDTO<Boolean> view = assignmentAnswerService.markAssignmentAnswer( param );
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/list-ec-question")
	public ViewDTO<QuestionListDTO> markAssignmentAnswer(
			HttpSession session,
			@ModelAttribute("param")ListQuestionParam param,
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<QuestionListDTO> view = questionService.listQuestion(param, pager);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/del-ec-question")
	public ViewDTO<Boolean> markAssignmentAnswer(
			HttpSession session,
			Long id
		){
		ViewDTO<Boolean> view = questionService.delByID(id);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/list-question-answer")
	public ViewDTO<QuestionAnswerListDTO> listQuestionAnswer(
			HttpSession session,
			Long qid,
			@ModelAttribute("pager")PagerDTO pager
		){
		ViewDTO<QuestionAnswerListDTO> view = questionService.listQuestionAnswer(qid, pager);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/submit-question-answer")
	public ViewDTO<Boolean> addQuestionAnswer(
			HttpSession session,
			@ModelAttribute("param")AddQuestionAnswerParam param
		){
		User user = getLoginUser(session);
		param.setAnswerUserID(user.getId());
		
		ViewDTO<Boolean> view = questionAnswerService.addQuestionAnswer(param);
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/list-all-student")
	public ViewDTO<List<UserDTO>> listAllStudent(){
		ViewDTO<List<UserDTO>> view = userService.listAllStudent();
		
		return view;
	}
	
	@ResponseBody
	@RequestMapping("/list-all-teacher")
	public ViewDTO<List<UserDTO>> listAllTeacher(){
		ViewDTO<List<UserDTO>> view = userService.listAllTeacher();
		
		return view;
	}
}
