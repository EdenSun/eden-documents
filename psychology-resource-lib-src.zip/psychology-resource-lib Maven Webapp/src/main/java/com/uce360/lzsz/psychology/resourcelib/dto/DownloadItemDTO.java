package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

import com.uce360.lzsz.psychology.resourcelib.util.Constants;

public class DownloadItemDTO {
	private Long id;
	private ResourceDTO resource;
	private UserDTO user;
	private Date createTime = new Date();
	private Integer isDelete = Constants.IS_DELETE_FALSE;
	
	public DownloadItemDTO() {
		super();
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public ResourceDTO getResource() {
		return resource;
	}
	public void setResource(ResourceDTO resource) {
		this.resource = resource;
	}
	public UserDTO getUser() {
		return user;
	}
	public void setUser(UserDTO user) {
		this.user = user;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
}
