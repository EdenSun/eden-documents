package com.uce360.lzsz.psychology.resourcelib.dto;

import java.util.Date;

public class CourseDTO {
	private Long id;
	private String name;
	private String description;
	private Long creatorID;
	private Long categoryID;
	private Float courseTime;
	private Float courseCredit;
	private Integer isShowOnHomepage;
	private Date createTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public Long getCategoryID() {
		return categoryID;
	}
	public void setCategoryID(Long categoryID) {
		this.categoryID = categoryID;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Float getCourseTime() {
		return courseTime;
	}
	public void setCourseTime(Float courseTime) {
		this.courseTime = courseTime;
	}
	public Float getCourseCredit() {
		return courseCredit;
	}
	public void setCourseCredit(Float courseCredit) {
		this.courseCredit = courseCredit;
	}
	public Integer getIsShowOnHomepage() {
		return isShowOnHomepage;
	}
	public void setIsShowOnHomepage(Integer isShowOnHomepage) {
		this.isShowOnHomepage = isShowOnHomepage;
	}
}
