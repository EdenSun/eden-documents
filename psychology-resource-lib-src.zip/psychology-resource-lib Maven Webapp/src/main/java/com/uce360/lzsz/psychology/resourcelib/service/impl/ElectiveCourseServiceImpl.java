package com.uce360.lzsz.psychology.resourcelib.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ElectiveCourseListDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.PagerDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.UserDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.ViewDTO;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddAssignmentParam;
import com.uce360.lzsz.psychology.resourcelib.dto.param.AddElectiveCourseParam;
import com.uce360.lzsz.psychology.resourcelib.exception.ServiceException;
import com.uce360.lzsz.psychology.resourcelib.mapper.IAssignmentMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IElectiveCourseMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IElectiveCourseStudentMapper;
import com.uce360.lzsz.psychology.resourcelib.mapper.IUserMapper;
import com.uce360.lzsz.psychology.resourcelib.model.Assignment;
import com.uce360.lzsz.psychology.resourcelib.model.ElectiveCourse;
import com.uce360.lzsz.psychology.resourcelib.model.ElectiveCourseStudent;
import com.uce360.lzsz.psychology.resourcelib.model.User;
import com.uce360.lzsz.psychology.resourcelib.service.IElectiveCourseService;
import com.uce360.lzsz.psychology.resourcelib.service.IUserService;

@Service
public class ElectiveCourseServiceImpl implements IElectiveCourseService {

	@Autowired
	private IElectiveCourseMapper electiveCourseMapper;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IUserMapper userMapper;
	
	@Autowired
	private IElectiveCourseStudentMapper electiveCourseStudentMapper;
	
	@Autowired
	private IAssignmentMapper assignmentMapper;
	
	@Override
	public List<ElectiveCourseDTO> listAllByUserID(Long uid)
			throws ServiceException {
		
		User user = userMapper.getByID(uid);
		
		Integer roleType = user.getRoleType() ;
		List<ElectiveCourse> courseList = null;
		if( roleType != null ){
			if( roleType.equals(User.ROLE_TYPE_STUDENT) ){
				//学生
				courseList = electiveCourseMapper.listAllByStudentID(uid);
			}else if( roleType.equals(User.ROLE_TYPE_TEACHER) ){
				//老师
				courseList = electiveCourseMapper.listAllByTeacherID(uid);
			}
		}
		
		
		List<ElectiveCourseDTO> courseDTOList = trans2ElectiveCourseDTOList(courseList);
		
		return courseDTOList;
	}

	private List<ElectiveCourseDTO> trans2ElectiveCourseDTOList(
			List<ElectiveCourse> courseList) {
		if( courseList == null ){
			return null;
		}
		
		List<ElectiveCourseDTO> dtoList = new ArrayList<ElectiveCourseDTO>();
		ElectiveCourseDTO dto = null;
		
		for( ElectiveCourse course : courseList ){
			dto = trans2ElectiveCourseDTO(course);
			if( dto != null ){
				dtoList.add(dto);
			}
		}
		return dtoList;
	}

	private ElectiveCourseDTO trans2ElectiveCourseDTO(ElectiveCourse course) {
		if( course == null ){
			return null;
		}
		
		ElectiveCourseDTO dto = new ElectiveCourseDTO();
		
		BeanUtils.copyProperties(course, dto);
		
		Long creatorID = course.getCreatorID();
		if( creatorID != null ){
			dto.setCreator(userService.getUserDTOByID(creatorID));
		}
		
		Long teacherID = course.getTeacherID();
		if( teacherID != null ){
			dto.setTeacher(userService.getUserDTOByID(teacherID));
		}
		
		List<UserDTO> stus = listAllStudentByECID(course.getId());
		
		String studentsStrList = "";
		if( stus != null ){
			for( UserDTO stu : stus ){
				studentsStrList += stu.getRealName() + ",";
			}
			if( studentsStrList.length() > 0 ){
				studentsStrList = studentsStrList.substring(0, studentsStrList.length()-1);
			}
		}
		dto.setStudentsStrList(studentsStrList);
		
		return dto;
	}

	private List<UserDTO> listAllStudentByECID(Long ecid) {
		List<UserDTO> dtoList = userService.listAllStudentByECID(ecid);

		return dtoList;
	}

	@Override
	public ViewDTO<ElectiveCourseDTO> getViewByID(Long cid)
			throws ServiceException {
		ViewDTO<ElectiveCourseDTO> view = new ViewDTO<ElectiveCourseDTO>();
		
		ElectiveCourse course = electiveCourseMapper.getByID(cid);
		ElectiveCourseDTO dto = trans2ElectiveCourseDTO(course);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dto);
		view.setMsg("获取成功");
		return view;
	}

	@Override
	public ViewDTO<ElectiveCourseListDTO> listElectiveCourseByUID(Long uid,
			PagerDTO pager) throws ServiceException {
		ViewDTO<ElectiveCourseListDTO> view = new ViewDTO<ElectiveCourseListDTO>();
		ElectiveCourseListDTO listDTO = new ElectiveCourseListDTO();
		
		List<ElectiveCourse> courseList = electiveCourseMapper.listByUID(uid,pager);
		List<ElectiveCourseDTO> ecDTOList = trans2ElectiveCourseDTOList(courseList);
		listDTO.setCourses(ecDTOList);
		
		int totalCount = electiveCourseMapper.listCountByUID(uid);
		pager.setTotalCount(totalCount);
		listDTO.setPager(pager);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(listDTO);
		view.setMsg("查询成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> delElectiveCourse(Long id) throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		electiveCourseMapper.delByID(id);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("删除成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> addElectiveCourse(AddElectiveCourseParam param)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		//保存选课
		ElectiveCourse ec = new ElectiveCourse();
		ec.setCreatorID(param.getCreatorID());
		ec.setDescription(param.getDescription());
		ec.setName(param.getName());
		ec.setTeacherID(param.getTeacherID());
		
		electiveCourseMapper.save(ec);
		
		//保存选课的学生列表
		if( param.getStudentIDAry() != null ){
			ElectiveCourseStudent ecStudent  = null;
			for( Long stuID : param.getStudentIDAry() ){
				ecStudent = new ElectiveCourseStudent();
				
				ecStudent.setElectiveCourseID(ec.getId());
				ecStudent.setStudentID(stuID);
				
				electiveCourseStudentMapper.save(ecStudent);
			}
		}
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("添加成功");
		return view;
	}
	

	@Override
	public ViewDTO<Boolean> addAssignment(AddAssignmentParam param)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		
		Assignment assignment = new Assignment();
		assignment.setContent( param.getContent() );
		assignment.setCreatorID( param.getCreatorID() );
		assignment.setElectiveCourseID( param.getElectiveCourseID() );
		assignment.setTitle( param.getTitle() );
		
		assignmentMapper.save(assignment);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("添加成功");
		return view;
	}

	@Override
	public ViewDTO<List<ElectiveCourseDTO>> listAll() throws ServiceException {
		ViewDTO<List<ElectiveCourseDTO>> view = new ViewDTO<List<ElectiveCourseDTO>>();
		
		List<ElectiveCourse> courses = electiveCourseMapper.listAll();
		List<ElectiveCourseDTO> dtoList = trans2ElectiveCourseDTOList(courses);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(dtoList);
		view.setMsg("查询所有成功");
		return view;
	}

	@Override
	public ViewDTO<Boolean> updateECDesc(Long ecid, String description)
			throws ServiceException {
		ViewDTO<Boolean> view = new ViewDTO<Boolean>();
		ElectiveCourse ec = electiveCourseMapper.getByID(ecid);
		if( ec == null ){
			view.setData(false);
			view.setMsg("选课不存在");
			return view;
		}
		
		ec.setDescription(description);
		electiveCourseMapper.update(ec);
		
		view.setCode(ViewDTO.CODE_SUCCESS);
		view.setData(true);
		view.setMsg("选课公告更新成功");
		return view;
	}
	
}
