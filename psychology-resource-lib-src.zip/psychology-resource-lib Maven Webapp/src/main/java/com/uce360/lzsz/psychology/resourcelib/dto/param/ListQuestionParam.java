package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class ListQuestionParam {
	public final static String FILTER_ALL = "all";
	public final static String FILTER_MINE = "mine";
	
	private Long uid;
	private Long cid;
	private String filter;
	
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
}
