package com.uce360.lzsz.psychology.resourcelib.dto.param;

public class CourseParamDTO {
	private Long id;
	private String name;
	private String description;
	private Long creatorID;
	private Float courseTime;
	private Float courseCredit;
	private Boolean isShowOnHomepageBoolean;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getCreatorID() {
		return creatorID;
	}
	public void setCreatorID(Long creatorID) {
		this.creatorID = creatorID;
	}
	public Float getCourseTime() {
		return courseTime;
	}
	public void setCourseTime(Float courseTime) {
		this.courseTime = courseTime;
	}
	public Float getCourseCredit() {
		return courseCredit;
	}
	public void setCourseCredit(Float courseCredit) {
		this.courseCredit = courseCredit;
	}
	public Boolean getIsShowOnHomepageBoolean() {
		return isShowOnHomepageBoolean;
	}
	public void setIsShowOnHomepageBoolean(Boolean isShowOnHomepageBoolean) {
		this.isShowOnHomepageBoolean = isShowOnHomepageBoolean;
	}
}
