function ECAskCtrl($scope,$http) {
	$scope.selectECEnable = false;
 	$scope.allEcList = [];
 	
 	$scope.questionListCond = {
 		cid:null,
 		page:1,
 		pageSize:10
 	};
 	$scope.questionListTotalPage = 0 ;
 	
 	$scope.init = function(){
 		$scope.listAllEC();
 		$scope.loadQuestionList();
 	}
 	
 	$scope.detailQuestionModel ;
 	
 	$scope.questionAnswerListCond = {
 		qid:null,
 		page:1,
 		pageSize:5
 	};
 	$scope.questionAnswerListTotalPage = 0 ;
 	
 	$scope.qaRequestModel = {
 		questionID : null,
 		content: null
 	}
 	
 	$scope.loadQuestionList = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-ec-question',
	        params    : $scope.questionListCond ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionListData = data.data.questions;
            	$scope.questionListTotalPage = data.data.pager.totalPage;
            }
        });
 	}
 	
 	$scope.loadQuestionPrevPage = function(){
 		if( $scope.questionListCond.page == 1 ){
			return; 			
 		}else{
 			$scope.questionListCond.page = $scope.questionListCond.page - 1;
	 		$scope.loadQuestionList();
 		}
 	}
 	
 	$scope.loadQuestionNextPage = function(){
 		if( $scope.questionListTotalPage == $scope.questionListCond.page ){
 			return;
 		}else{
 			$scope.questionListCond.page = $scope.questionListCond.page + 1;
	 		$scope.loadQuestionList();
 		}
 	}
 	
 	$scope.listAllEC = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-all-ec',
	        params    : {},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.allEcList = data.data;
            }
        });
 	}
 	
 	$scope.delQuestion = function(qid){
 		$http({
	        method  : 'POST',
	        url     : 'ec/del-ec-question',
	        data    : $.param( { 'id' : qid} ),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadQuestionList();
            }
        });
 	}
 	
 	$scope.onSelectECCheckboxClick = function(event){
 		var $curItem = $( event.currentTarget );
		if( !$curItem.is(':checked') ){
			$scope.questionListCond.cid = null;
			$scope.loadQuestionList();
		}
 	}
 	
 	$scope.onECListChange = function(){
 		$scope.loadQuestionList();
 	}
 	
 	
 	$scope.onAnswerClick = function(question){
 		$scope.detailQuestionModel = question;
 		
 		var qid = question.id;
 		
 		$scope.questionAnswerListCond.qid = qid;
 		$scope.loadQuestionAnswer();
		 		
 		$('#questionDetailModal').modal('show');
 	}
 	
 	
 	
 	$scope.loadQuestionAnswer = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-question-answer',
	        params  : $scope.questionAnswerListCond,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionAnswerListData = data.data.answers;
            	$scope.questionAnswerListTotalPage = data.data.pager.totalPage;
            }
        });
 	}
 	
 	$scope.loadQAPrevPage = function(){
 		if( $scope.questionAnswerListCond.page == 1 ){
			return; 			
		}else{
			$scope.questionAnswerListCond.page = $scope.questionAnswerListCond.page - 1;
			$scope.loadQuestionAnswer();
		}
 		
 	}
 	
 	$scope.loadQANextPage = function(){
 		if( $scope.questionAnswerListTotalPage == $scope.questionAnswerListCond.page ){
 			return;
 		}else{
 			$scope.questionAnswerListCond.page = $scope.questionAnswerListCond.page + 1;
	 		$scope.loadQuestionAnswer();
 		}
 	}
 	
 	$scope.submitAnswerContent = function(){
		 $scope.qaRequestModel.questionID = $scope.questionAnswerListCond.qid;
		 
		 $http({
	        method  : 'POST',
	        url     : 'ec/submit-question-answer',
	        data    : $.param($scope.qaRequestModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.qaRequestModel = {};
            	$scope.loadQuestionAnswer();
            }
        });
 	}
 	
}