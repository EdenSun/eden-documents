function OnlineReadingChannelCtrl($scope,$http) {
	$scope.courses = [];
 	
	$http.get('res/json/reslistByChannel?channelID=' + channelID)
		 .success(function(data, status, headers, config){
		 	$scope.courses = data.data;
		 	
		 	if( $scope.courses.length > 0 ){
			 	$scope.onDocumentItemClick(0);
		 	}
		 });
 
 	$scope.onDocumentItemClick = function(index){
 		var curCourse = $scope.courses[index];
 		
 		if( curCourse.onlineReadUrl ){
	 		loadSwf(curCourse.urlBase + curCourse.onlineReadUrl);
 		}
 	}
 	
 	function loadSwf(swfUrl){
 		$('#documentViewer').FlexPaperViewer(
				{ config : {
					SWFFile : swfUrl,
					Scale : 0.6,
					ZoomTransition : 'easeOut',
					ZoomTime : 0.5,
					ZoomInterval : 0.2,
					FitPageOnLoad : true,
					FitWidthOnLoad : true,
					FullScreenAsMaxWindow : false,
					ProgressiveLoading : false,
					MinZoomSize : 0.2,
					MaxZoomSize : 5,
					SearchMatchAll : false,
					InitViewMode : 'Portrait',
					RenderingOrder : 'flash',
					StartAtPage : '',

					ViewModeToolsVisible : true,
					ZoomToolsVisible : true,
					NavToolsVisible : true,
					CursorToolsVisible : true,
					SearchToolsVisible : true,
					WMode : 'window',
					localeChain: 'en_US'
				}}
		);
 	}
}