function MyDownloadCtrl($scope,$http) {
	$scope.myDownloadList = [];
	$scope.myDownloadListPager = {
		page:1,
		pageSize:10
	};
	$scope.myDownloadListTotalPage = 0;
	
	
 	$scope.init = function(){
 		$scope.loadMyDownload();
 	}
 	
 	
 	$scope.loadMyDownload = function(){
 		$http({
	        method  : 'GET',
	        url     : 'download/list-my-download',
	        params    : $scope.myDownloadListPager ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.myDownloadList = data.data.downloads;
            	$scope.myDownloadListTotalPage = data.data.pager.totalPage;
            	
            }
        });
 	}
 	
 	$scope.onDownloadPrevClick = function(){
 		if( $scope.myDownloadListPager.page == 1 ){
			return; 			
 		}else{
 			$scope.myDownloadListPager.page = $scope.myDownloadListPager.page - 1;
	 		$scope.loadMyDownload();
 		}
 	}
 	$scope.onDownloadNextClick = function(){
 		if( $scope.myDownloadListTotalPage == $scope.myDownloadListPager.page ){
 			return;
 		}else{
 			$scope.myDownloadListPager.page = $scope.myDownloadListPager.page + 1;
	 		$scope.loadMyDownload();
 		}
 	}
 	
 	$scope.onDelDownloadBtnClick = function(did){
 		var param = {
 			'downloadID':did
 		};
 		$http({
	        method  : 'POST',
	        url     : 'download/del',
	        data    :  $.param(param),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
				$scope.loadMyDownload();       	
            }
        });
 	}
}