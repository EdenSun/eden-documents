function MyElectiveCourseCtrl($scope,$http) {
	$scope.assignmentModel = {};
	$scope.assignmentPager = {
		cid:null,
		page:1,
		pageSize:10
	};
	$scope.assignmentListTotalPage = 0;
	
	$scope.questionPager = {
		cid:null,
		filter:'all',
		page:1,
		pageSize:10
	};
	$scope.questionListTotalPage = 0;
	$scope.questionModel = {};
	
	$scope.submitAssignmentAnswerCond = {
		assignmentID:null,
		assignmentAnswerContent: null
	};
	
 	$scope.init = function(){
 	}
 	
 	$scope.assignmentDetail = {};
 	$scope.myAssignmentAnswer = {};
 	
 	$scope.questionDetail = {};
 	
 	$scope.questionAnswerCond = {
 		qid: null,
		page:1,
		pageSize:3
	};
	$scope.questionAnswerTotalPage = 0;
 	$scope.addQuestionAnswerModel = {
 		qid:null,
 		content: null
 	};
 	
 	$scope.updateNoticeModel = {
 		id : null,
 		description : null
 	}
 	$scope.assignmentAnswerListCond = {
 		assignmentID: null,
 		page:1,
 		pageSize:10
 	};
 	$scope.assignmentAnswerListTotalPage = 0 ;
 	
 	$scope.onECourceItemClick = function(event){
 		var $curItem = $(event.currentTarget);
 		
 		var $subList = $curItem.find('.nav');
 		
 		if( $subList.hasClass("expend") ){
 			$subList.removeClass("expend");
 		}else{
 			$subList.addClass("expend");
 		}
 	}
 	
 	$scope.onCourseSubMenuClick = function(event,index,cid){
 		if( index == 1 ){
 			//公告
 			$scope.initCourseNotice(cid);
 		}else if( index == 2 ){
 			//作业
 			$scope.assignmentModel.electiveCourseID=cid;		
 			$scope.loadCourseAssignment(cid);
 		}else if( index == 3 ){
 			//问答
 			$scope.questionModel.electiveCourseID = cid;
 			$scope.loadCourseAsk(cid);
 		}else{
 		
 		}
 		
 		event.preventDefault();
 		event.stopPropagation();
 	}
 	
 	$scope.initCourseNotice = function(cid){
 		var param = {
 			'cid': cid
 		};
 		$http({
	        method  : 'GET',
	        url     : 'ec/get-course',
	        params    : param ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.curCourse = data.data;
            	$('.course-right-col').hide();
            	$('.notice-box').show();
            }
        });
 	}
 	
 	$scope.loadCourseAssignment = function(cid){
 		if(cid){
	 		$scope.assignmentPager.cid = cid;
 		}
 		
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-assignment',
	        params    : $scope.assignmentPager ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.assignmentListTotalPage = data.data.pager.totalPage;
            	$scope.assignments = data.data.assignments;
            	
            	$('.course-right-col').hide();
    			$('.assignment-box').show();
    			
            }
        });
    	
 	}
 	
 	$scope.loadCourseAsk = function(cid){
 		if(cid){
	 		$scope.questionPager.cid = cid;
 		}
 		
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-question',
	        params    : $scope.questionPager ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionListTotalPage = data.data.pager.totalPage;
            	$scope.questions = data.data.questions;
            	
            	$('.course-right-col').hide();
    			$('.ask-box').show();
    			
            }
        });
 	
    	
 	}
 	
 	$scope.onAssignmentPrevClick = function(){
 		if( $scope.assignmentPager.page == 1 ){
			return; 			
 		}else{
 			$scope.assignmentPager.page = $scope.assignmentPager.page - 1;
	 		$scope.loadCourseAssignment();
 		}
 	}
 	$scope.onAssignmentNextClick = function(){
 		if( $scope.assignmentListTotalPage == $scope.assignmentPager.page ){
 			return;
 		}else{
 			$scope.assignmentPager.page = $scope.assignmentPager.page + 1;
	 		$scope.loadCourseAssignment();
 		}
 	}
 	
 	
 	$scope.onQuestionPrevClick = function(){
 		if( $scope.questionPager.page == 1 ){
			return; 			
 		}else{
 			$scope.questionPager.page = $scope.questionPager.page - 1;
	 		$scope.loadCourseAsk();
 		}
 	}
 	$scope.onQuestionNextClick = function(){
 		if( $scope.questionListTotalPage == $scope.questionPager.page ){
 			return;
 		}else{
 			$scope.questionPager.page = $scope.questionPager.page + 1;
	 		$scope.loadCourseAsk();
 		}
 	}
 	
 	$scope.onAskFilterRadioClick = function(event){
 		var $curItem = $(event.currentTarget);
 		
 		var filter = $curItem.data('filter');
 		$scope.questionPager.filter = filter;
 		
 		$scope.loadCourseAsk();
 	}
 	
 	$scope.onSaveQuestionBtnClick = function(){
 		$http({
	        method  : 'POST',
	        url     : 'ec/add-question',
	        data    : $.param($scope.questionModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionModel = {};
            	$scope.loadCourseAsk();
            	
    			$('#askModal').modal('hide');
            }
        });
		
 	}
 
 	$scope.onSubmitAssignmentClick = function($event,assignmentID){
 		var param = {
 			'id': assignmentID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'ec/get-assignment',
	        params    : param,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.assignmentDetail = data.data;
		 		$('#submitAssignmentModal').modal('show');
		 		
		 		$scope.getMyAssignmentAnswer(assignmentID);
            }
        });
 		
 	}
 	
 	$scope.onMarkAssignmentClick = function(event,aid){
 		$scope.assignmentAnswerListCond.assignmentID = aid;
 		
 		$scope.loadAssignmentAnswer(function(data){
 			if( data.data.pager.totalCount == 0 ){
 				alert('没有学生提交作业');
 				return ;
 			}
 			
	 		$('#markModal').modal('show');
 		});
 		
 	}
 	
 	$scope.loadAssignmentAnswer = function(successFn){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-assignment-answer',
	        params    : $scope.assignmentAnswerListCond,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.aaListData = data.data.answers;
            	$scope.assignmentAnswerListTotalPage = data.data.pager.totalPage;
            	
            	if( successFn ){
	            	successFn(data);
            	}
            }
        });
 	}
 	
 	
 	$scope.getMyAssignmentAnswer = function(assignmentID){
 		$scope.myAssignmentAnswer = null;
 		$http({
	        method  : 'GET',
	        url     : 'ec/get-my-assignment-answer',
	        params  : {'assignmentID':assignmentID},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.myAssignmentAnswer = data.data;
            }
        });
 		
 	}
 	
 	$scope.onSubmitAssignmentAnswer = function(assignmentID){
 		$scope.submitAssignmentAnswerCond.assignmentID = assignmentID;
		
 		$http({
	        method  : 'POST',
	        url     : 'ec/submit-assignment-answer',
	        data    : $.param( $scope.submitAssignmentAnswerCond ),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.submitAssignmentAnswerCond = {};
            	$scope.loadCourseAssignment();
            	
            	$scope.getMyAssignmentAnswer(assignmentID);
            }
        });
 	}
 	
 	$scope.onAskDetailClick = function(questionID){
 		$http({
	        method  : 'GET',
	        url     : 'ec/get-question-detail',
	        params  : {'id':questionID},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionDetail = data.data;
            	
            	$scope.loadQuestionAnswer(questionID);
            	
		 		$('#questionDetailModal').modal('show');
            }
        });
        
 	
 	}
 	
 	
 	
	
 	$scope.loadQuestionAnswer = function(questionID){
 		if( questionID ){
	 		$scope.questionAnswerCond.qid = questionID;
 		}
 		
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-question-answer',
	        params  : $scope.questionAnswerCond,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.questionAnswersData = data.data.answers;
            	$scope.questionAnswerTotalPage = data.data.pager.totalPage;
            }
        });
        
 	
 	}
 	
 	$scope.onQuestionAnswerPrevClick = function(){
 		if( $scope.questionAnswerCond.page == 1 ){
			return; 			
 		}else{
 			$scope.questionAnswerCond.page = $scope.questionAnswerCond.page - 1;
	 		$scope.loadQuestionAnswer();
 		}
 	}
 	$scope.onQuestionAnswerNextClick = function(){
 		if( $scope.questionAnswerTotalPage == $scope.questionAnswerCond.page ){
 			return;
 		}else{
 			$scope.questionAnswerCond.page = $scope.questionAnswerCond.page + 1;
	 		$scope.loadQuestionAnswer();
 		}
 	}
 	
 	$scope.submitQuestionAnswer = function(){
 		$scope.addQuestionAnswerModel.qid = $scope.questionDetail.id;
 		
 		$http({
	        method  : 'POST',
	        url     : 'ec/submit-question-answer',
	        data    : $.param( $scope.addQuestionAnswerModel ),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.addQuestionAnswerModel = {};
            	$scope.loadQuestionAnswer($scope.questionDetail.id);
            }
        });
        
 	}
 	
 	$scope.onModifyNotice = function(){
 		var curCourse = $scope.curCourse;
 		$scope.updateNoticeModel.id = curCourse.id;
 		$scope.updateNoticeModel.description = curCourse.description;
 		
 		$('#updateNoticeModal').modal('show');
 	}
 	
 	$scope.doUpdateNotice = function(){
 		$http({
	        method  : 'POST',
	        url     : 'ec/update-ec-desc',
	        data    : $.param( $scope.updateNoticeModel ),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	alert('更新成功');
            	$('#updateNoticeModal').modal('hide');
            	
            	$scope.updateNoticeModel.id = null;
 				$scope.updateNoticeModel.description = null;
 				$scope.initCourseNotice($scope.curCourse.id);
            }
        });
 	}
 	
 	$scope.submitAssignment = function(){
 		$http({
	        method  : 'POST',
	        url     : '../admin/ec/add-assignment',
	        data    : $.param($scope.assignmentModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadCourseAssignment($scope.assignmentModel.electiveCourseID);
            	$scope.assignmentModel = {};
            	
            	$('#addAssignmentModal').modal('hide');
            }
        });
 	}
 	
 	$scope.onAddAssignmentBtnClick = function(){
 		$('#addAssignmentModal').modal('show');
 	}
 	
 	$scope.onMarkAssignment = function(aMarkModel){
 		$http({
	        method  : 'POST',
	        url     : '../admin/ec/mark-assignment-answer',
	        data    : $.param(aMarkModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadAssignmentAnswer();
            }
        });
 		
 	}
 	
 	$scope.loadPrevAAPage = function(){
 		if( $scope.assignmentAnswerListCond.page == 1 ){
			return; 			
 		}else{
 			$scope.assignmentAnswerListCond.page = $scope.assignmentAnswerListCond.page - 1;
	 		$scope.loadAssignmentAnswer();
 		}
 	}
 	
 	$scope.loadNextAAPage = function(){
 		if( $scope.assignmentAnswerListTotalPage == $scope.assignmentAnswerListCond.page ){
 			return;
 		}else{
 			$scope.assignmentAnswerListCond.page = $scope.assignmentAnswerListCond.page + 1;
	 		$scope.loadAssignmentAnswer();
 		}
 	}
}