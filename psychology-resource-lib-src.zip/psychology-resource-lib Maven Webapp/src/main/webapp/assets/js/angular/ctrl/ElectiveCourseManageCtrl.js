function ElectiveCourseManageCtrl($scope,$http) {
 	var FILTER_ALL = 'all';
 	var FILTER_MINE = 'mine';

 	$scope.ecListCond = {
 		filter:FILTER_ALL,
 		page:1,
 		pageSize:10
 	};
 	$scope.ecListTotalPage = 0 ;
 	
 	$scope.init = function(){
 		$scope.loadECList();
 		$scope.loadAllStudent();
 		$scope.loadAllTeacher();
 		
 		
 	}
 	$scope.electiveCourse = {};
 	
 	$scope.loadECList = function(){
 		
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-elective-course',
	        params    : $scope.ecListCond ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.ecListData = data.data.courses;
            	$scope.ecListTotalPage = data.data.pager.totalPage;
            }
        });
 	}
 	
 	function initStudentListParam(electiveCourse){
 		$scope.electiveCourse.studentIDList = new Array();
 		
 		var $selectedStuCheckbox = $('.stu-tab-content :checkbox:checked[data-uid]');
 		
 		$.each(
 			$selectedStuCheckbox,
 			function(i,n){
 				var uid = $(this).data('uid');
 				$scope.electiveCourse.studentIDList.push(uid);
 			}
 		);
 	}
 	
 	function clearSelectedStudents(){
 		var $selectedStuCheckbox = $('.stu-tab-content :checkbox:checked');
 		$selectedStuCheckbox.prop('checked',false);
 	}
 	
 	$scope.addEC = function(electiveCourse){
 		initStudentListParam(electiveCourse);
 		var isSuccess = addECParamCheck(electiveCourse);
		if( isSuccess ){
			$http({
		        method  : 'POST',
		        url     : 'ec/add-elective-course',
		        data    : $.param(electiveCourse),  
		        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
	    	}).success(function(data) {
	            if( data.code == 0 ){
	            	$scope.electiveCourse = {};
	            	$scope.loadECList();
	            	clearSelectedStudents();
	            	
	            	$('#addECModal').modal('hide');
	            }
	        });
		}
 	}
 	
 	function addECParamCheck(electiveCourse){
 		if( $.trim(electiveCourse.name) == '' ){
 			alert('请输入选课名称');
 			return false;
 		}
 		if( $.trim(electiveCourse.description) == '' ){
 			alert('请输入选课公告');
 			return false;
 		}
 		if( electiveCourse.teacherID == null ){
 			alert('请选择老师');
 			return false;
 		}
 		if( electiveCourse.studentIDList == null || electiveCourse.studentIDList.length == 0 ){
 			alert('请选择学生');
 			return false;
 		}
 		return true;
 	}
 	
 	$scope.loadPrevECPage = function(){
 		if( $scope.ecListCond.page == 1 ){
			return; 			
 		}else{
 			$scope.ecListCond.page = $scope.ecListCond.page - 1;
	 		$scope.loadECList();
 		}
 	}
 	
 	$scope.loadNextECPage = function(){
 		if( $scope.ecListTotalPage == $scope.ecListCond.page ){
 			return;
 		}else{
 			$scope.ecListCond.page = $scope.ecListCond.page + 1;
	 		$scope.loadECList();
 		}
 	}
 	
 	$scope.onFilterClick = function(event){
 		var filter = $(event.currentTarget).data('filter');
 		$scope.ecListCond.filter = filter;
 		
 		$scope.loadECList();
 	}
 	
 	$scope.delEC = function(ecID){
 		
 		$http({
	        method  : 'POST',
	        url     : 'ec/del-elective-course',
	        params    : { 'id' : ecID},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadECList();
            }
        });
 	}
 	
 	$scope.loadAllStudent = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-all-student',
	        params  : {},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.allStudentData = data.data;
            	
            	$scope.allStudentDataByStartYearData = sortStudentDataByStartYear(data.data);
            	
            	//$scope.electiveCourse.studentIDList[0] = 3;
            }
        });
 	}
 	
 	function sortStudentDataByStartYear(data){
 		if( data ){
 			var resultData = {};
 			$.each(
 				data,
 				function(i,n){
 					var startYear = n.startYear;
 					if( resultData[startYear] ){
 						resultData[startYear].push(n);
 					}else{
 						resultData[startYear] = new Array();
 						resultData[startYear].push(n);
 					}
 				}
 			);
 			return resultData;
 		}
 		return null;
 	}
 	
 	$scope.loadAllTeacher = function(){
		$http({
	        method  : 'GET',
	        url     : 'ec/list-all-teacher',
	        params  : {},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.allTeacherData = data.data;
            }
        });
 	}
 	
 	$scope.viewStudents = function(event, ecID){
 	}
 	
 	$scope.onEditEC = function(index){
 		var curEC = $scope.ecListData[index];
 	}
 	
 	$scope.selectAllStu = function(event){
 		var $this = $(event.currentTarget);
 		var isChecked = $this.is(':checked');
 		if( isChecked ){
 			$this.closest('.tab-pane').find(':checkbox').prop('checked',true);
 		}else{
 			$this.closest('.tab-pane').find(':checkbox').prop('checked',false);
 		}
 	}
}