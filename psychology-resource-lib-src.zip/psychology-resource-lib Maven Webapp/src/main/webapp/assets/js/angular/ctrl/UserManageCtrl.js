function UserManageCtrl($scope,$http) {
	$scope.users = [];
	$scope.page = 1;
	$scope.pageSize = 10;
 	$scope.totalPage = 0;
 	
 	$scope.init = function(){
 		initUploadComponent();
 		loadUserList();
 	}
 	
 	loadUserList = function(){
 		$http.get('user/listUser?page=' + $scope.page  +'&pageSize=' + $scope.pageSize )
		 .success(function(data, status, headers, config){
		 	$scope.users = data.data.users;
		 	$scope.totalPage = data.data.pager.totalPage;
		 });
 	}
 	
 	$scope.loadPrevPage = function(){
 		if( $scope.page > 1 ){
 			$scope.page = $scope.page -1 ;
 			
 			loadUserList();
 		}
 	}
 	
 	$scope.loadNextPage = function(){
 		if( $scope.page < $scope.totalPage ){
 			$scope.page = $scope.page + 1 ;
 			
 			loadUserList();
 		}
 	}
 	
 	
 	$scope.addUser = function(user){
 		$http({
	        method  : 'POST',
	        url     : 'user/addUser',
	        data    : $.param(user),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//清空表单数据
            	$scope.user = angular.copy({});
            	
            	//隐藏弹出层
            	$('#addUserModal').modal('hide');
            	
            	//刷新数据
            	$scope.page = 1;
            	loadUserList();
            }
        });
 	}
 	
 	$scope.delUser = function(uid){
		$http({
	        method  : 'POST',
	        url     : 'user/delUser',
	        data    : 'userID='+ uid,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	loadUserList();
            }
        });
 	}
 	
 	$scope.onEditUserLinkClick = function(user){
 		$scope.user = user;
 		
 		//显示编辑层
 		$('#editUserModal').modal('show');
 	}
 	
 	$scope.onAddUserBtnClick = function(){
 		//清空表单数据
        $scope.user = angular.copy({});
 	}
 	
 	initUploadComponent = function(){
	    $('#fileupload').fileupload({
	        dataType: 'json',
	        start: function(e,data){
		 		$("html").mask("正在进行文件上传,请稍候...");
	        },
	        done: function (e, data) {
	        	loadUserList();
	        	$("html").unmask();
	        	alert("导入成功");
	        }
	    });
 	}
 	
}