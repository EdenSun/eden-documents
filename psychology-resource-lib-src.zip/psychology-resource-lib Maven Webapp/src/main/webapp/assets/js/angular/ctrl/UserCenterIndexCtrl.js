function UserCenterIndexCtrl($scope,$http) {
	
 	$scope.init = function(){
 		
 		
 	}
 	
}