function CourseCenterCtrl($scope,$http) {
 	$scope.courseListData = [];
 	$scope.courseListPage = 1;
 	$scope.courseListPageSize = 5;
 	$scope.courseListTotalPage = 0;
 	
 	$scope.init = function(){
 		$scope.loadCourseList();
 		
 		$scope.loadLoginValidCode();
 	}
 	
 	$scope.loadLoginValidCode = function(){
	    $('#validCode').attr('src','login/validCode');
 	}
 	
 	$scope.loadCourseList = function(){
 		var param = {
 			'page': $scope.courseListPage,
 			'pageSize': $scope.courseListPageSize
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listCourse',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		$scope.courseListData = data.data.courses;
    		
    		$scope.courseListTotalPage = data.data.pager.totalPage;
        });
 	}
 	
 	$scope.loadPrevPageCourse = function(){
 		if( $scope.courseListPage > 1 ){
 			$scope.courseListPage = $scope.courseListPage -1 ;
 			
 			$scope.loadCourseList();
 		}
 	}
 	
 	$scope.loadNextPageCourse = function(){
 		if( $scope.courseListPage < $scope.courseListTotalPage ){
 			$scope.courseListPage = $scope.courseListPage + 1 ;
 			
 			$scope.loadCourseList();
 		}
 	}
 	
 	$scope.doLogin = function(loginFormModel){
 		var isSuccess = checkLoginForm(loginFormModel);
 		
 		if( isSuccess ){
 			
			$http({
		        method  : 'POST',
		        url     : 'auth/json/doLogin',
		        data    : $.param(loginFormModel),  
		        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
			}).success(function(data) {
				if( data.code == 0 ){
					location.reload();
				}else{
					alert(data.msg);
				}
		    });	 		
 		}
 	}
 	
 	
 	$scope.doLogout = function(){
 		$http({
	        method  : 'POST',
	        url     : 'auth/json/doLogout',
	        data    : null,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
		}).success(function(data) {
			if( data.code == 0 ){
				location.reload();
			}
	    });	
 	}
 	
 	function checkLoginForm( loginFormModel ){
 		if( !loginFormModel ){
 			alert('请输入帐号和密码')
 			return false;
 		}
 		
 		if( !loginFormModel.account || loginFormModel.account.length == 0 ){
 			alert('帐号不能为空')
 			return false;
 		}
 		
 		if( !loginFormModel.password || loginFormModel.password.length == 0 ){
 			alert('密码不能为空')
 			return false;
 		}
 		
 		if( !loginFormModel.validCode || loginFormModel.validCode.length == 0 ){
 			alert('验证码不能为空')
 			return false;
 		}
 		
 		return true;
 	}
 	
}