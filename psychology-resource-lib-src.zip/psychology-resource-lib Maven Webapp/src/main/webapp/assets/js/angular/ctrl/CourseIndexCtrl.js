function CourseIndexCtrl($scope,$http) {
 	$scope.cataloglist = [];
 	$scope.cateTreeData = [];
 	$scope.isResListHide = true;
 	$scope.isReadingViewerHide = true;
 	
 	$scope.init = function(){
 	
 		$scope.initCateTree();
 	}
 	
 	$scope.initCateTree = function(){
 		var param = {
 			'courseID':courseID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/getCourseCatalog',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		/*
    		$scope.cataloglist = data.data;
    		
    		initCateTreeData(data.data);
    		*/
    		initCateTreeData(data.data);
        });
 	}
 	
 	$scope.listAllByType = function(type){
 		var catalogName = '';
 		if( type == 1 ){
 			//媒体素材库 
	 		catalogName = '媒体素材';
 		}else if( type == 2 ){
 			//试题库
 			catalogName = '试题';
 		}else if( type ==3 ){
 			//文献资料库
 			catalogName = '文献资料';
 		}else{
 			catalogName = null;
 		}
 		
 		if( catalogName ){
	 		loadResByCatalogNameInCourse( 
	 			courseID,
				catalogName , 
				function(data){
					if(data.code == 0 ){
						$scope.contentListData = data.data;
						
						$scope.isReadingViewerHide = true;
						$scope.isResListHide = false;
					}
				}
			);
 		}
 		
 	}
 	
 	var loadResByCatalogNameInCourse = function(courseID,catalogName,successFn){
 		var param = {
 			'courseID': courseID,
 			'catalogName':catalogName
 		};
 		$http({
	        method  : 'POST',
	        url     : 'coursecenter/listAllResByCatalogNameInCourse',
	        data  :  $.param(param),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
    		successFn(data);
        });
 		
 	};
 	
 	var initCateTreeData = function( cataloglist ){
 		if( cataloglist ){
 			iteratorCateTreeData( cataloglist ,0 ,0);
 		
 			var setting = {
				view: {
					//addHoverDom: addHoverDom,
					//removeHoverDom: removeHoverDom,
					selectedMulti: false
				},
				edit: {
					//enable: true,
					//editNameSelectAll: true,
					//showRemoveBtn: showRemoveBtn,
					//showRenameBtn: showRenameBtn
				},
				data: {
					simpleData: {
						enable: true
					}
				},
				callback: {
					onClick: function(event, treeId, treeNode){
						if( treeNode.dataLevel == 3 ){
							var parent = treeNode.getParentNode();
							
							//设置内容标题
							$('#contentTitle').text(parent.name + ' - ' + treeNode.name) ;
							
							//读取分类内容
							if( treeNode.name == '电子素材' ){
								loadResInSubDir( 
									treeNode.id , 
									function(data){
										if(data.code == 0 ){
											var curRes = data.data[0];
											
											$scope.isReadingViewerHide = false;
											$scope.isResListHide = true;
											loadSwf('#documentViewer',curRes.urlBase + curRes.onlineReadUrl);
										}
									}
								);
							}else{
								loadResInSubDir( 
									treeNode.id , 
									function(data){
										if(data.code == 0 ){
											$scope.contentListData = data.data;
											
											$scope.isReadingViewerHide = true;
											$scope.isResListHide = false;
												
										}
									}
								);
							}
						}
					}
				}
			};
		
			// init zTree
			$.fn.zTree.init($("#treeDemo"), setting, $scope.cateTreeData);
			
 		}
 	};
 	
 	var loadResInSubDir = function(catalogID,successFn){
 		var param = {
 			'catalogID':catalogID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listAllResByCatalog',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		successFn(data);
        });
 		
 	};
 	
 	var iteratorCateTreeData = function( cataloglist, index ,parentID){
 		if( !cataloglist ){
 			return ;
 		}
 		
 		var curCate = cataloglist[index];
		if( curCate ){
			var cateTreeListItem = {
				'id': curCate.id,
				'name': curCate.name,
				'dataLevel': curCate.level,
				'pId': parentID,
				'open': true
			};
			
			$scope.cateTreeData.push(cateTreeListItem);
			
			if( curCate.subs ){
				iteratorCateTreeData( curCate.subs, 0 , curCate.id );
			}
			
			if( cataloglist[index+1] ){
				iteratorCateTreeData( cataloglist, index+1 , parentID );
			}
			
		}else{
			return;
		}
 	};
 	
 	$scope.onResClick = function(res){
 		if( res.format == 1 ){
 			//PDF ,在线预览
	 		var onlineReadUrl = res.urlBase + res.onlineReadUrl;
	 		
	 		
	 		$('#onlineReadDialog').modal('show');
	 		
	 		loadSwf('#dialogDocumentViewer',onlineReadUrl);
	 		
 		}else{
 			//不是pdf，下载
 			var fileUrl = res.urlBase + res.url;
 			
 			open(fileUrl);
 		}
 	}
 	
 	function loadSwf(viewerSelector,swfUrl){
 		$(viewerSelector).FlexPaperViewer(
				{ config : {
					SWFFile : swfUrl,
					Scale : 0.6,
					ZoomTransition : 'easeOut',
					ZoomTime : 0.5,
					ZoomInterval : 0.2,
					FitPageOnLoad : true,
					FitWidthOnLoad : true,
					FullScreenAsMaxWindow : false,
					ProgressiveLoading : false,
					MinZoomSize : 0.2,
					MaxZoomSize : 5,
					SearchMatchAll : false,
					InitViewMode : 'Portrait',
					RenderingOrder : 'flash',
					StartAtPage : '',

					ViewModeToolsVisible : true,
					ZoomToolsVisible : true,
					NavToolsVisible : true,
					CursorToolsVisible : true,
					SearchToolsVisible : true,
					WMode : 'window',
					localeChain: 'en_US'
				}}
		);
 	}
}