function CourseManageCtrl($scope,$http) {
 	$scope.courseListData = [];
 	$scope.catalogListData = [];
 	$scope.sectionListData = [];
 	$scope.subDirListData = [];
 	
 	$scope.searchResListData = [];
 	$scope.searchModel ={};
 	$scope.searchPage = 1 ;
	$scope.searchPageSize = 10 ;
	$scope.searchTotalCount = 0 ;
	$scope.resourceModel = {};
	$scope.mediaCateList = {};
	
 	$scope.init = function(){
 		initUploadComponent();
 		loadCourseList();
 		//获取媒体属性和课程属性分类
		loadCateList(); 
 	}
 	
 	loadCateList = function(){
 		//媒体分类
 		var param1 = {};
 		$http({
	        method  : 'GET',
	        url     : 'rescenter/listAllMediaCate',
	        data    : $.param(param1),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	$scope.mediaCateList = data.data;
            }
        });
        
 	}
 	
 	initUploadComponent = function(){
	    $('#fileupload').fileupload({
	        dataType: 'json',
	        start: function(e,data){
		 		$("html").mask("正在进行文件上传,请稍候...");
	        },
	        done: function (e, data) {
	        	$("html").unmask();
	        	
	        	//上传成功
	        	//{basePath: "http://127.0.0.1:8080/upload", path: "20131225/fd6fcf23-b14a-40d7-80ce-dbf981f44ee1.png", contentType: "image/png", originalFilename: "未标题-1_04", size: 1712}
	        	if( data.result ){
	        		var curDocID = data.result.id;
	        		var name = data.result.name;
	        		var format = data.result.formatStr;
	        		var size = data.result.size ;
	        		
	        		//设置数据
	        		$('#uploadDocID').val(curDocID);
	        		$('#nameInput').val(name);
	        		$('#sizeInput').val(size);
	        		$('#formatInput').val(format);
	        		
	        		$('#uploadModal').modal('show');
	        	}
	        }
	    });
 	}
 	
 	$scope.updateRes = function(resourceModel){
 		resourceModel.id = $('#uploadDocID').val();
 		$http({
	        method  : 'POST',
	        url     : 'rescenter/updateRes',
	        data    :  $.param(resourceModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//更新成功
            	//刷新数据
            	searchRes();
            	
            	$scope.resourceModel = {};
            	$('#uploadModal').modal('hide');
            }
        });
 	}
 	
 	loadCourseList = function(){
 		var param = {};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listCourse',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		$scope.courseListData  = data.data;
        });
 	}
 	$scope.onCourseClick = function(courseID,curIndex){
	 	//清理
 		$scope.catalogListData = [];
	 	$scope.sectionListData = [];
	 	$scope.subDirListData = [];
 		
 		$scope.selectedCourseIndex = curIndex;
 		$scope.selectedCourseID = courseID;
 		loadCatalog();
 	}
 	
 	$scope.onCatalogClick = function(catalogID, curIndex ){
 		//清理
	 	$scope.sectionListData = [];
	 	$scope.subDirListData = [];
	 	
 		$scope.selectedCatalogIndex = curIndex;
 		$scope.selectedCatalogID = catalogID;
 		loadSection();
 	}
 	
 	$scope.onSectionClick = function(sectionID,curIndex ){
 		//清理
	 	$scope.subDirListData = [];
 		
 		$scope.selectedSectionIndex = curIndex;
 		$scope.selectedSectionID = sectionID;
 		
 		loadSubDir();
 	}
 	
 	
 	loadSubDir = function(){
 		var param = {
 			'sectionID':$scope.selectedSectionID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listSubDirBySection',
	        params  : param,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data){
    		$scope.subDirListData = data.data;
        });
 	}
 	
 	loadCatalog = function(){
 		var param = {
 			'courseID':$scope.selectedCourseID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listChapterByCourse',
	        params  : param,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data){
    		$scope.catalogListData = data.data;
        });
 	}
 	
 	loadSection = function(){
 		var param = {
 			'chapterID':$scope.selectedCatalogID
 		};
 		$http({
	        method  : 'GET',
	        url     : 'coursecenter/listSectionByChapter',
	        params  : param,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data){
    		$scope.sectionListData = data.data;
        });
 	}

	$scope.addOrUpdateCourse = function(courseModel){
		if( !checkAddCourseParam(courseModel) ){
			return;
		}

 		$http({
	        method  : 'POST',
	        url     : 'coursecenter/addOrUpdateCourse',
	        data:  $.param(courseModel),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
			loadCourseList();
			    		
    		$scope.courseModel = {};
        	$('#addCourseModal').modal('hide');
        });
	}
	
	function checkAddCourseParam(courseModel){
		if( courseModel ) {
			if( !courseModel.name || $.trim(courseModel.name).length == 0 ){
				alert('课程名称不能为空');
				return false;
			}
			
			return true;
		}
		else{
			alert('请正确填写课程信息再提交。');
			return false;
		}
	}
	/**
	 * 创建章
	 */
	$scope.addCatalog = function(catalogModel){
		catalogModel.courseID = $scope.selectedCourseID;
		catalogModel.level = 1;
 		$http({
	        method  : 'POST',
	        url     : 'coursecenter/addCatalog',
	        data    : $.param(catalogModel),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
			loadCatalog();
			
    		$scope.catalogModel = {};
        	$('#addCatalogModal').modal('hide');
        });
	}
	
	/**
	 * 创建节
	 */
	$scope.addSection = function(sectionModel){
		sectionModel.courseID = $scope.selectedCourseID;
		sectionModel.parentID = $scope.selectedCatalogID;
		sectionModel.level = 2;
 		$http({
	        method  : 'POST',
	        url     : 'coursecenter/addCatalog',
	        data    : $.param(sectionModel),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
			loadSection();
			
    		$scope.sectionModel = {};
        	$('#addSectionModal').modal('hide');
        });
	}
	
	$scope.onAddResToSubDirBtnClick = function(){
		searchRes();
	}
	
	searchRes = function(){
		$scope.searchModel.page = $scope.searchPage;
		$scope.searchModel.pageSize = $scope.searchPageSize;

		$http({
	        method  : 'POST',
	        url     : 'coursecenter/listRes',
	        data    : $.param($scope.searchModel),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
    		$scope.searchTotalPage = data.data.pager.totalPage;
    		$scope.searchResListData = data.data.resources;
        });
	}
	
	
	$scope.loadSearchResPrevPage = function(){
 		if( $scope.searchPage > 1 ){
 			$scope.searchPage = $scope.searchPage -1 ;
 			
 			searchRes();
 		}
 	}
 	
 	$scope.loadSearchResNextPage = function(){
 		if( $scope.searchPage < $scope.searchTotalPage ){
 			$scope.searchPage = $scope.searchPage + 1 ;
 			
 			searchRes();
 		}
 	}
 	
 	$scope.onSearchBtnClick = function(){
 		searchRes();
 	}
	
	$scope.setResToSubDir = function(type,res){
		
		var resID = res.id;
		if( type == 1 ){
			//电子素材, 只能PDF
			if( res.format != 1 ){
				alert('文档格式不正确，请选择PDF文档');
				return ;
			}
			//添加电子素材
			var catalogID = $scope.subDirListData[0].id;
			doAddResToSubDir(catalogID, resID);
		}else if( type == 2 ){
			//媒体素材, 只能 图片或视频
			if( (res.format >= 401 && res.format <= 600) 
				|| res.format >= 201 && res.format <= 400 ){
				var catalogID = $scope.subDirListData[1].id;
				
				doAddResToSubDir(catalogID, resID);
			}else{
				alert('文档格式不正确，请选择图片或视频');
				return ;
			}
			
		}else if( type == 3 ){
			//试题
			if( res.format != 1 ){
				alert('文档格式不正确，请选择PDF文档');
				return ;
			}
			
			var catalogID = $scope.subDirListData[2].id;
			
			doAddResToSubDir(catalogID, resID);
		}else if( type == 4 ){
			//文献
			if( res.format != 1 ){
				alert('文档格式不正确，请选择PDF文档');
				return ;
			}
			
			var catalogID = $scope.subDirListData[3].id;
			
			doAddResToSubDir(catalogID, resID);
		}
	}
	
	doAddResToSubDir = function(catalogID, resID){
		var param = {
			'catalogID': catalogID,
			'resID':resID
		};
		$http({
	        method  : 'POST',
	        url     : 'coursecenter/addResToSubDir',
	        data 	: $.param(param),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
    		if( data.code == 0 ){
    			alert('添加成功');
    		}else{
    			alert(data.msg);
    		}
        });
	}
	
	$scope.onCourseDeleteBtnClick = function(selectedCourseID){
		var param = {
			'courseID': selectedCourseID
		};
		$http({
	        method  : 'POST',
	        url     : 'coursecenter/delCourse',
	        data 	: $.param(param),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
    		if( data.code == 0 ){
    			loadCourseList();
    		}else{
    			alert(data.msg);
    		}
        });
	}
	
	$scope.onChapterDeleteBtnClick = function(selectedChapterID){
		var param = {
			'chapterID': selectedChapterID
		};
		$http({
	        method  : 'POST',
	        url     : 'coursecenter/delChapter',
	        data 	: $.param(param),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
    		if( data.code == 0 ){
    			loadCatalog();
    		}else{
    			alert(data.msg);
    		}
        });
	}
	
	$scope.onSectionDeleteBtnClick = function(selectedSectionID){
		var param = {
			'chapterID': selectedSectionID
		};
		$http({
	        method  : 'POST',
	        url     : 'coursecenter/delChapter',
	        data 	: $.param(param),
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded'}
    	}).success(function(data){
    		if( data.code == 0 ){
    			loadSection();
    		}else{
    			alert(data.msg);
    		}
        });
	}
	
	$scope.onCourseEditBtnClick = function(event,index){
		var curCourse = $scope.courseListData[index];
		if( curCourse ){
			//编辑
			$scope.courseModel = {};
			$scope.courseModel = curCourse;
			var isShowOnHomepage = curCourse.isShowOnHomepage;
			if( isShowOnHomepage ){
				if( isShowOnHomepage == 1 ){
					curCourse.isShowOnHomepageBoolean = true;
				}else{
					curCourse.isShowOnHomepageBoolean = false;
				}
			}
			
			$('#addCourseModalLabel').text('编辑课程');
			
			$('#addCourseModal').modal('show');
		}
	}
	
	$scope.onAddCourseBtnClick = function(){
		$('#addCourseModalLabel').text('创建课程');
		$('#addCourseModal').modal('show');
	}
	
}