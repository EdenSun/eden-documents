function ResourceManageCtrl($scope,$http) {
	$scope.resources = [];
	$scope.page = 1;
	$scope.pageSize = 10;
 	$scope.totalPage = 0;
 	$scope.resourceModel = {};
 	$scope.mediaCateList = {};
 	$scope.courseCateList = {};
 	
 	
 	$scope.init = function(){
 		initUploadComponent();
 		
 		loadResourceList();

		//获取媒体属性和课程属性分类
		loadCateList(); 		
 	}

	function getCategoryList(cateTreeList){
		var cateListAry = [];
		if( cateTreeList ){
			for(var i=0;i<cateTreeList.length;i++){
				var cur = cateTreeList[i];
				cateListAry.push(cur);
			
				var subs = cur.subs;
				if( subs ){
					for(var j=0;j<subs.length;j++){
						var curSub = subs[j];
						curSub.name = '-' + curSub.name;
						cateListAry.push(curSub);
					}
				}	
			}
		}
		
		return cateListAry;
	} 	
	
 	loadCateList = function(){
 		//媒体分类
 		var param1 = {};
 		$http({
	        method  : 'GET',
	        url     : 'rescenter/listAllMediaCate',
	        data    : $.param(param1),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	//$scope.mediaCateList = data.data;
            	
            	$scope.mediaCateList = getCategoryList(data.data);
            }
        });
        
        //课程分类
        /*
        var param2 = {};
 		$http({
	        method  : 'GET',
	        url     : 'rescenter/listAllCourseCate',
	        data    : $.param(param2),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	$scope.courseCateList = data.data;
            }
        });
        */
 	}
 	
 	initUploadComponent = function(){
	    $('#fileupload').fileupload({
	        dataType: 'json',
	        start: function(e,data){
		 		$("html").mask("正在进行文件上传,请稍候...");
	        },
	        done: function (e, data) {
	        	$("html").unmask();
	        	
	        	//上传成功
	        	//{basePath: "http://127.0.0.1:8080/upload", path: "20131225/fd6fcf23-b14a-40d7-80ce-dbf981f44ee1.png", contentType: "image/png", originalFilename: "未标题-1_04", size: 1712}
	        	if( data.result ){
	        		var curDocID = data.result.id;
	        		var name = data.result.name;
	        		var format = data.result.formatStr;
	        		var size = data.result.size ;
	        		
	        		//设置数据
	        		$('#uploadDocID').val(curDocID);
	        		$('#nameInput').val(name);
	        		$('#sizeInput').val(size);
	        		$('#formatInput').val(format);
	        		
	        		$('#uploadModal').modal('show');
	        	}
	        }
	    });
 	}
 	
 	
 	loadResourceList = function(){
 		$http.get('rescenter/listRes?page=' + $scope.page  +'&pageSize=' + $scope.pageSize )
		 .success(function(data, status, headers, config){
		 	$scope.resources = data.data.resources;
		 	$scope.totalPage = data.data.pager.totalPage;
		 });
 	}
 	
 	$scope.loadPrevPage = function(){
 		if( $scope.page > 1 ){
 			$scope.page = $scope.page -1 ;
 			
 			loadResourceList();
 		}
 	}
 	
 	$scope.loadNextPage = function(){
 		if( $scope.page < $scope.totalPage ){
 			$scope.page = $scope.page + 1 ;
 			
 			loadResourceList();
 		}
 	}
 	
 	$scope.doAudit = function(resID,auditStatus){
 		var param = {
 			'resourceID': resID,
 			'auditStatus' : auditStatus
 		};
 		$http({
	        method  : 'POST',
	        url     : 'rescenter/auditRes',
	        data    : $.param(param),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	loadResourceList();
            }
        });
 	}
 	
 	$scope.updateRes = function(resourceModel){
 		resourceModel.id = $('#uploadDocID').val();
 		$http({
	        method  : 'POST',
	        url     : 'rescenter/updateRes',
	        data    :  $.param(resourceModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//更新成功
            	//刷新数据
            	loadResourceList();
            	
            	$scope.resourceModel = {};
            	$('#uploadModal').modal('hide');
            }
        });
 	}
 	
 	$scope.delRes = function(resid){
		$http({
	        method  : 'POST',
	        url     : 'rescenter/delRes',
	        data    : 'resourceID='+ resid,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	loadResourceList();
            }
        });
 	}
 	
 	$scope.onEditUserLinkClick = function(user){
 		$scope.user = user;
 		
 		//显示编辑层
 		$('#editUserModal').modal('show');
 	}
 	
 	$scope.onAddUserBtnClick = function(){
 		//清空表单数据
        $scope.user = angular.copy({});
 	}
 	
 	$scope.onEdit = function(index){
 		var curRes = $scope.resources[index];
 		$('#uploadDocID').val(curRes.id);
 		$('#sizeInput').val(curRes.size);
 		$('#formatInput').val(curRes.formatStr);
 		$scope.resourceModel = {
			'name':curRes.name ,
			'description': curRes.description,
			'mediaCateID': curRes.mediaCateID,
			'courseCateID': curRes.courseCateID,
			'faceTo': curRes.faceTo,  
			'keywords': curRes.keywords
 		};
 		$('#uploadModal').modal('show');
 	}
 	
 	
 	$scope.viewRes = function(index){
 		var curResData = $scope.resources[index] ;
 		var onlineReadUrl = curResData.onlineReadUrl;
 		if( onlineReadUrl ){
 			//可以在线阅读
 			$('#onlineReadDialog').modal('show');
 			loadSwf('#dialogDocumentViewer',curResData.urlBase + onlineReadUrl);
 		}else{
 			//不能在线阅读，下载
 			var fileRealUrl = curResData.urlBase + curResData.url;
 			open(fileRealUrl);
 		}
 		
 	}
 	
 	function loadSwf(viewerSelector,swfUrl){
 		$(viewerSelector).FlexPaperViewer(
				{ config : {
					SWFFile : swfUrl,
					Scale : 0.6,
					ZoomTransition : 'easeOut',
					ZoomTime : 0.5,
					ZoomInterval : 0.2,
					FitPageOnLoad : true,
					FitWidthOnLoad : true,
					FullScreenAsMaxWindow : false,
					ProgressiveLoading : false,
					MinZoomSize : 0.2,
					MaxZoomSize : 5,
					SearchMatchAll : false,
					InitViewMode : 'Portrait',
					RenderingOrder : 'flash',
					StartAtPage : '',

					ViewModeToolsVisible : true,
					ZoomToolsVisible : true,
					NavToolsVisible : true,
					CursorToolsVisible : true,
					SearchToolsVisible : true,
					WMode : 'window',
					localeChain: 'en_US',
					jsDirectory: 'assets/../'
				}}
		);
 	}
}