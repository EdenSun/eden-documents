function ResourceCatalogManageCtrl($scope,$http) {
	/*
	$scope.isCreateRootCateDisabled = false;
	$scope.isCreateSubCateDisabled = false;
	$scope.isModifyCateNameDisabled = false;
	$scope.isDeleteCateDisabled = false;
	*/
	
	$scope.cateTreeData = [];
	$scope.init = function(){
		
		$scope.initCataTree();
	}
	
	$scope.initCataTree = function(){
		var param = {
 		};
 		$http({
	        method  : 'GET',
	        url     : 'rescenter/listCateTree',
	        params    : $.param(param),  
	        headers : { /*'Content-Type': 'application/x-www-form-urlencoded'*/ }
    	}).success(function(data) {
            if( data.code == 0 ){
            	initCateTreeData(data.data.subs);
            	
            }
        });
        
	}
	
	var initCateTreeData = function( cataloglist ){
 		if( cataloglist ){
 			iteratorCateTreeData( cataloglist ,0 ,0);
 			
 			var setting = {
				view: {
					/*addHoverDom: addHoverDom,
					removeHoverDom: removeHoverDom,
					*/
					selectedMulti: false
				},
				edit: {
					enable: false,
					editNameSelectAll: true,
					showRemoveBtn: showRemoveBtn,
					showRenameBtn: showRenameBtn
				},
				data: {
					simpleData: {
						enable: true
					}
				},
				callback: {
					beforeDrag: beforeDrag,
					beforeEditName: beforeEditName,
					beforeRemove: beforeRemove,
					beforeRename: beforeRename,
					onRemove: onRemove,
					onRename: onRename,
					onClick: function(event, treeId, treeNode){
						$scope.$apply(function () {
					        if( treeNode.dataLevel == 1 ){
								//根分类
								$('#createRootBtn').prop('disabled',false);
								$('#createSubBtn').prop('disabled',false);
								$('#modifyCateNameBtn').prop('disabled',false);
								$('#delCateBtn').prop('disabled',false);
								
							}else{
								$('#createRootBtn').prop('disabled',false);
								$('#createSubBtn').prop('disabled',false);
								$('#modifyCateNameBtn').prop('disabled',false);
								$('#delCateBtn').prop('disabled',false);
							}
					    });
					}
				}
			};
		
			// init zTree
			$.fn.zTree.init($("#cataTree"), setting, $scope.cateTreeData);
			
 		}
 	};

 	var iteratorCateTreeData = function( cataloglist, index ,parentID){
 		if( !cataloglist ){
 			return ;
 		}
 		
 		var curCate = cataloglist[index];
 		
		if( curCate ){
			var cateTreeListItem = {
				'id': curCate.id,
				'name': curCate.name,
				'dataLevel': curCate.level,
				'pId': parentID,
				'open': true
			};

			$scope.cateTreeData.push(cateTreeListItem);
			
			if( curCate.subs && curCate.subs.length > 0 ){
				iteratorCateTreeData( curCate.subs, 0 , curCate.id );
			}
			
			if( index+1 < cataloglist.length ){
				iteratorCateTreeData( cataloglist, index+1 , parentID );
			}
			
		}else{
			return;
		}
 	};
 	
 	$scope.addRootCate = function(addRootCateModel){
 		$http({
	        method  : 'POST',
	        url     : 'rescenter/addCate',
	        data    : $.param(addRootCateModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.addRootCateModel = {};
            	initCateTreeData(data.data.subs);
            	
            	$('#addRootCateModal').modal('hide');
            	$scope.cateTreeData = [];
            	$scope.initCataTree();
            }
        });
 	}
 	
 	$scope.addSubCate = function(addSubCateModel){
 		var treeObj = $.fn.zTree.getZTreeObj("cataTree");
		var nodes = treeObj.getSelectedNodes();
		if( nodes && nodes.length == 0 ){
			alert('请先选中节点');
			return ;
		}
		var selectedNode = nodes[0];
		
		addSubCateModel.parentID = selectedNode.id ;
		addSubCateModel.level = selectedNode.dataLevel + 1;
		
 		$http({
	        method  : 'POST',
	        url     : 'rescenter/addCate',
	        data    : $.param(addSubCateModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.addSubCateModel = {};
            	initCateTreeData(data.data.subs);
            	
            	$('#addSubCateModel').modal('hide');
            	$scope.cateTreeData = [];
            	$scope.initCataTree();
            }
        });
 	}
 	
 	$scope.delSelectedCate = function(){
 		var treeObj = $.fn.zTree.getZTreeObj("cataTree");
		var nodes = treeObj.getSelectedNodes();
		if( nodes && nodes.length == 0 ){
			alert('请先选中节点');
			return ;
		}
		var selectedNode = nodes[0];
		
		var param = {
			'id': selectedNode.id
		};
		$http({
	        method  : 'POST',
	        url     : 'rescenter/delCate',
	        data    : $.param(param),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.cateTreeData = [];
            	$scope.initCataTree();
            }
        });
 	}
 	
 	
 	$scope.onModifyCateBtnClick = function(){
 		var treeObj = $.fn.zTree.getZTreeObj("cataTree");
		var nodes = treeObj.getSelectedNodes();
		if( nodes && nodes.length == 0 ){
			alert('请先选中节点');
			return ;
		}
		var selectedNode = nodes[0];
		
 		$scope.modifyCateModel = {};
 		$scope.modifyCateModel.name = selectedNode.name;
 		
 		$('#modifyCateModel').modal('show');
 	}
 	
 	$scope.modifyCateName = function(modifyCateModel){
		var selectedNode = getSelectedNode();
		
		modifyCateModel.id = selectedNode.id;
		$http({
	        method  : 'POST',
	        url     : 'rescenter/updateCateName',
	        data    : $.param(modifyCateModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.modifyCateModel = [];
            	
            	$scope.cateTreeData = [];
            	$scope.initCataTree();
            	
            	$('#modifyCateModel').modal('hide');
            }
        });
 		
 	}
 	
 	var getSelectedNode = function(){
 		var treeObj = $.fn.zTree.getZTreeObj("cataTree");
		var nodes = treeObj.getSelectedNodes();
		if( nodes && nodes.length == 0 ){
			alert('请先选中节点');
			return ;
		}
		var selectedNode = nodes[0];
		return selectedNode;
 	}
}