function ChannelManageCtrl($scope,$http) {
	$scope.channelResources = [];
	$scope.channelResListPage = 1;
	$scope.channelResListPageSize = 10;
 	$scope.channelResListTotalPage = 0;
 	$scope.resourceModel = {};
 	$scope.channelID = 1;
 	
 	$scope.searchByKeywordsPage = 1;
 	$scope.searchByKeywordsPageSize = 10;
 	$scope.searchByKeywordsTotalPage = 0;
 	$scope.init = function(){
 		loadResourceListByChannel();
 		
 	}
 	
 	loadResourceListByChannel = function(){
 		var param = {
 			'channelID': $scope.channelID,
 			'page': $scope.channelResListPage,
 			'pageSize' : $scope.channelResListPageSize
 		};
 		$http({
	        method  : 'GET',
	        url     : 'channel/listResByChannel',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		$scope.channelResources = data.data.resources;
    		$scope.channelResListTotalPage = data.data.pager.totalPage;
        });
 	}
 	
 	$scope.loadPrevPageChannelRes = function(){
 		if( $scope.channelResListPage > 1 ){
 			$scope.channelResListPage = $scope.channelResListPage -1 ;
 			
 			loadResourceListByChannel();
 		}
 	}
 	
 	$scope.loadNextPageChannelRes = function(){
 		if( $scope.channelResListPage < $scope.channelResListTotalPage ){
 			$scope.channelResListPage = $scope.channelResListPage + 1 ;
 			
 			loadResourceListByChannel();
 		}
 	}
 	
 	$scope.loadSearchByKeywordsPrevPage = function(){
 	if( $scope.searchByKeywordsPage > 1 ){
 			$scope.searchByKeywordsPage = $scope.searchByKeywordsPage -1 ;
 			
 			$scope.searchByKeywords();
 		}
 	}
 	$scope.loadSearchByKeywordsNextPage = function(){
 		if( $scope.searchByKeywordsPage < $scope.searchByKeywordsTotalPage ){
 			$scope.searchByKeywordsPage = $scope.searchByKeywordsPage + 1 ;
 			
 			$scope.searchByKeywords();
 		}
 	}
 	
 	
 	$scope.onChannelChannge = function(channelID){
 		$scope.channelResListPage = 1;
		$scope.channelID = channelID;
		loadResourceListByChannel();
 	}
 	
 	$scope.removeResFromChannel = function(resID){
 		var param = {
 			'channelID': $scope.channelID,
 			'resID': resID
 		};
 		
 		$http({
	        method  : 'POST',
	        url     : 'channel/delFromChannel',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		if( data.code == 0 ){
    			loadResourceListByChannel();
    		}
        });
 	}
 	
 	$scope.addResToChannel = function(resID,channelID){
 		var param = {
 			'channelID': channelID,
 			'resID': resID
 		};
 		
 		$http({
	        method  : 'POST',
	        url     : 'channel/addResToChannel',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		if( data.code == 0 ){
    			alert('添加成功');
    			loadResourceListByChannel();
    		}
        });
 	}
 	
 	$scope.searchByKeywords = function(){
 		if( $scope.searchKeywords ){
	 		var param = {
	 			'keywords': encodeURIComponent($scope.searchKeywords),
	 			'page': $scope.searchByKeywordsPage,
	 			'pageSize' : $scope.searchByKeywordsPageSize
	 		};
	 		$http({
		        method  : 'POST',
		        url     : 'channel/searchOnlineResByKeywords',
		        params  : param,  
		        headers : {  }
	    	}).success(function(data) {
	    		$scope.searchByKeywordsResources = data.data.resources;
	    		$scope.searchByKeywordsTotalPage = data.data.pager.totalPage;
	        });
        }else{
        	alert('请输入关键字');
        }
 	}
 	
}