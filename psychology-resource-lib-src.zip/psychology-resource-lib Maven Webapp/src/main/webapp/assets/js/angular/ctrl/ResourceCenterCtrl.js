function ResourceCenterCtrl($scope,$http) {
	$scope.catelist = [];
	$scope.courselist = [];
	$scope.resourceList = [];
 	$scope.page = 1 ;
 	$scope.pageSize = 10 ;
 	$scope.totalPage ;
 	$scope.totalCount = 0;
 	
 	$scope.type ;
 	
	$scope.init = function(){
		$scope.initCateList();
		
		$scope.initCourseList();
		
		$scope.cateID = null;
		loadResByCategory();
	}
	
	$scope.initCateList = function(){
		var param = {};
 		$http({
	        method  : 'GET',
	        url     : 'rc/json/catelist',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		$scope.catelist = data.data.subs;
        });
	}
	
	$scope.initCourseList = function(){
		var param = {};
 		$http({
	        method  : 'GET',
	        url     : 'rc/json/listAllCourse',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		$scope.courselist = data.data;
        });
	}
	
	
	$scope.onCourseClick = function( courseID ){
		$scope.courseID = courseID;
		$scope.type = 2;
		$scope.page = 1;
		
		loadResByCourse();
	}
	
	loadResByCourse = function(){
		var param = {
			'courseID': $scope.courseID,
			'page': $scope.page,
			'pageSize': $scope.pageSize
		};
		
 		$http({
	        method  : 'GET',
	        url     : 'rc/json/listResByCourse',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		if( data.code == 0 ){
    			$scope.totalCount = data.data.pager.totalCount;
    			$scope.totalPage = data.data.pager.totalPage;
    			$scope.resourceList = data.data.resources;
    		}
        });
	}
	
	$scope.onCateClick = function( cateID ){
		$scope.cateID = cateID;
		$scope.type = 1;
		$scope.page = 1;
		
		loadResByCategory();
	}
	
	loadResByCategory = function(){
		var param = {
			'cateID': $scope.cateID,
			'page': $scope.page,
			'pageSize': $scope.pageSize
		};
		
 		$http({
	        method  : 'GET',
	        url     : 'rc/json/listResByCategory',
	        params    : param,  
	        headers : {  }
    	}).success(function(data) {
    		if( data.code == 0 ){
    			$scope.totalCount = data.data.pager.totalCount;
    			$scope.totalPage = data.data.pager.totalPage;
    			$scope.resourceList = data.data.resources;
    		}
        });
	}
	
	$scope.loadPrevPage = function(){
 		if( $scope.page > 1 ){
 			$scope.page = $scope.page -1 ;
 			
 			if( $scope.type == 1 ){
	 			loadResByCategory();
 			}else{
 				loadResByCourse();
 			}
 		}
 	}
 	
 	$scope.loadNextPage = function(){
 		if( $scope.page < $scope.totalPage ){
 			$scope.page = $scope.page + 1 ;
 			
 			if( $scope.type == 1 ){
	 			loadResByCategory();
 			}else{
 				loadResByCourse();
 			}
 		}
 	}
 	
 	$scope.onDownload = function(resID,url){
		$http({
	        method  : 'GET',
	        url     : 'auth/json/isLogin',
	        params    : {t:new Date().getTime()},  
	        headers : {  }
    	}).success(function(data) {
    		if( data.data == true ){
    			addMyDownload(resID);
    			open(url);
    			//$('#downloadHelper').attr('href',url).trigger("click");
    		}else{
    			alert('登录后才能下载,请先登录');
    		}
        });	
 	}
 	
 	function addMyDownload(resID){
 		$http({
	        method  : 'POST',
	        url     : 'ucenter/download/addMyDownload',
	        data    : $.param({'resID':resID}),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
		}).success(function(data) {
			if( data.code == 0 ){
			}
	    });	 
 	}
 	
}