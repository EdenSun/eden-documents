function MyUploadCtrl($scope,$http) {
	$scope.myUploadList = [];
	$scope.myUploadListPager = {
		page:1,
		pageSize:10
	};
	$scope.myUploadListTotalPage = 0;
	
 	$scope.init = function(){
 		initUploadComponent();
 		
 		$scope.loadMyUpload();
 		
 		//获取媒体属性和课程属性分类
		loadCateList(); 
 	}
 	
 	initUploadComponent = function(){
 		
	    $('#fileupload').fileupload({
	        dataType: 'json',
	        start: function(e,data){
		 		$("html").mask("正在进行文件上传,请稍候...");
	        },
	        done: function (e, data) {
	        	$("html").unmask();
	        
	        	//上传成功
	        	//{basePath: "http://127.0.0.1:8080/upload", path: "20131225/fd6fcf23-b14a-40d7-80ce-dbf981f44ee1.png", contentType: "image/png", originalFilename: "未标题-1_04", size: 1712}
	        	if( data.result ){
	        		var curDocID = data.result.id;
	        		var name = data.result.name;
	        		var format = data.result.formatStr;
	        		var size = data.result.size ;
	        		
	        		//设置数据
	        		$('#uploadDocID').val(curDocID);
	        		$('#nameInput').val(name);
	        		$('#sizeInput').val(size);
	        		$('#formatInput').val(format);
	        		
	        		$('#uploadModal').modal('show');
	        	}
	        }
	    });
 	}
 	
 	loadCateList = function(){
 		//媒体分类
 		var param1 = {};
 		$http({
	        method  : 'GET',
	        url     : '../admin/rescenter/listAllMediaCate',
	        data    : $.param(param1),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//刷新数据
            	$scope.mediaCateList = data.data;
            }
        });
 	}
 	
 	$scope.loadMyUpload = function(){
 		$http({
	        method  : 'GET',
	        url     : 'upload/list-my-upload',
	        params    : $scope.myUploadListPager ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.myUploadList = data.data.resources;
            	$scope.myUploadListTotalPage = data.data.pager.totalPage;
            	
            }
        });
 	}
 	
 	$scope.onUploadPrevClick = function(){
 		if( $scope.myUploadListPager.page == 1 ){
			return; 			
 		}else{
 			$scope.myUploadListPager.page = $scope.myUploadListPager.page - 1;
	 		$scope.loadMyUpload();
 		}
 	}
 	$scope.onUploadNextClick = function(){
 		if( $scope.myUploadListTotalPage == $scope.myUploadListPager.page ){
 			return;
 		}else{
 			$scope.myUploadListPager.page = $scope.myUploadListPager.page + 1;
	 		$scope.loadMyUpload();
 		}
 	}
 	
 	$scope.updateRes = function(resourceModel){
 		resourceModel.id = $('#uploadDocID').val();
 		$http({
	        method  : 'POST',
	        url     : '../admin/rescenter/updateRes',
	        data    :  $.param(resourceModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	//更新成功
            	//刷新数据
            	$scope.loadMyUpload();
            	
            	$scope.resourceModel = {};
            	$('#uploadModal').modal('hide');
            }
        });
 	}
 	
}