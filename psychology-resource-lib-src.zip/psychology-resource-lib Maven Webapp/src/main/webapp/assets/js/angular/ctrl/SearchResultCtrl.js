function SearchResultCtrl($scope,$http) {
 
 	$scope.init = function(){
 	}
 	
 	$scope.doLogin = function(loginFormModel){
 		var isSuccess = checkLoginForm(loginFormModel);
 		
 		if( isSuccess ){
 			
			$http({
		        method  : 'POST',
		        url     : 'auth/json/doLogin',
		        data    : $.param(loginFormModel),  
		        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
			}).success(function(data) {
				if( data.code == 0 ){
					location.reload();
				}
		    });	 		
 		}
 	}
 	
 	
 	$scope.doLogout = function(){
 		$http({
	        method  : 'POST',
	        url     : 'auth/json/doLogout',
	        data    : null,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
		}).success(function(data) {
			if( data.code == 0 ){
				location.reload();
			}
	    });	
 	}
 	
 	function checkLoginForm( loginFormModel ){
 		if( !loginFormModel ){
 			alert('请输入帐号和密码')
 			return false;
 		}
 		
 		if( !loginFormModel.account || loginFormModel.account.length == 0 ){
 			alert('帐号不能为空')
 			return false;
 		}
 		
 		if( !loginFormModel.password || loginFormModel.password.length == 0 ){
 			alert('密码不能为空')
 			return false;
 		}
 		
 		if( !loginFormModel.validCode || loginFormModel.validCode.length == 0 ){
 			alert('验证码不能为空')
 			return false;
 		}
 		
 		if( loginFormModel.validCode != '2564' ){
 			alert('验证码不正确')
 			return false;
 		}
 		return true;
 	}
 	
 	$scope.onDownload = function(url){
		$http({
	        method  : 'GET',
	        url     : 'auth/json/isLogin',
	        data    : null,  
	        headers : { }
    	}).success(function(data) {
    		if( data.data == true ){
    			open(url);
    		}else{
    			alert('登录后才能下载,请先登录');
    		}
        });	
 	}
}