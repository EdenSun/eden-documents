function ECAssignmentCtrl($scope,$http) {
 	var FILTER_ALL = 'all';
 	var FILTER_MINE = 'mine';
 	$scope.selectECEnable = false;
 	$scope.allEcList = [];
 	
 	$scope.aListCond = {
 		ecID:null,
 		filter:FILTER_ALL,
 		page:1,
 		pageSize:10
 	};
 	$scope.aListTotalPage = 0 ;
 	
 	$scope.aListData = [];
 	
 	
 	$scope.assignmentAnswerListCond = {
 		assignmentID: null,
 		page:1,
 		pageSize:10
 	};
 	$scope.assignmentAnswerListTotalPage = 0 ;
 	
 	
 	$scope.init = function(){
 		$scope.listAllEC();
 		$scope.loadAssignmentList();
 	}
 	
 	$scope.loadAssignmentList = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-ec-assignment',
	        params    : $scope.aListCond ,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.aListData = data.data.assignments;
            	$scope.aListTotalPage = data.data.pager.totalPage;
            }
        });
 	}
 	
 	$scope.loadPrevECAPage = function(){
 		if( $scope.aListCond.page == 1 ){
			return; 			
 		}else{
 			$scope.aListCond.page = $scope.aListCond.page - 1;
	 		$scope.loadAssignmentList();
 		}
 	}
 	
 	$scope.loadNextECAPage = function(){
 		if( $scope.aListTotalPage == $scope.aListCond.page ){
 			return;
 		}else{
 			$scope.aListCond.page = $scope.aListCond.page + 1;
	 		$scope.loadAssignmentList();
 		}
 	}
 	
 	$scope.loadPrevAAPage = function(){
 		if( $scope.assignmentAnswerListCond.page == 1 ){
			return; 			
 		}else{
 			$scope.assignmentAnswerListCond.page = $scope.assignmentAnswerListCond.page - 1;
	 		$scope.loadAssignmentAnswer();
 		}
 	}
 	
 	$scope.loadNextAAPage = function(){
 		if( $scope.assignmentAnswerListTotalPage == $scope.assignmentAnswerListCond.page ){
 			return;
 		}else{
 			$scope.assignmentAnswerListCond.page = $scope.assignmentAnswerListCond.page + 1;
	 		$scope.loadAssignmentAnswer();
 		}
 	}

 	$scope.onFilterClick = function(event){
 		var filter = $(event.currentTarget).data('filter');
 		$scope.aListCond.filter = filter;
 		
 		$scope.loadAssignmentList();
 	}
 	
 	$scope.delECA = function(ecaID){
 		$http({
	        method  : 'POST',
	        url     : 'ec/del-ec-assignment',
	        data    : $.param( { 'id' : ecaID} ),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadAssignmentList();
            }
        });
 	}
 	
 	$scope.listAllEC = function(){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-all-ec',
	        params    : {},  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.allEcList = data.data;
            }
        });
 	}
 	
 	
 	$scope.submitAssignment = function(){
 		$http({
	        method  : 'POST',
	        url     : 'ec/add-assignment',
	        data    : $.param($scope.assignmentModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.assignmentModel = {};
            	$scope.loadAssignmentList();
            	
            	$('#addAssignmentModal').modal('hide');
            }
        });
 	}
 	
 	$scope.onECListChange = function(){
 		$scope.loadAssignmentList();
 	}
 	
 	$scope.onSelectECCheckboxClick = function(event){
 		var $curItem = $( event.currentTarget );
		if( !$curItem.is(':checked') ){
			$scope.aListCond.ecID = null;
			$scope.loadAssignmentList();
		}
 	}
 	
 	$scope.onAssignmentAnswerMark = function(aid){
 		$scope.assignmentAnswerListCond.assignmentID = aid;
 		
 		$scope.loadAssignmentAnswer(function(data){
 			if( data.data.pager.totalCount == 0 ){
 				alert('没有学生提交作业');
 				return ;
 			}
 			
	 		$('#markModal').modal('show');
 		});
 		
 	}
 	
 	$scope.loadAssignmentAnswer = function(successFn){
 		$http({
	        method  : 'GET',
	        url     : 'ec/list-assignment-answer',
	        params    : $scope.assignmentAnswerListCond,  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.aaListData = data.data.answers;
            	$scope.assignmentAnswerListTotalPage = data.data.pager.totalPage;
            	
            	if( successFn ){
	            	successFn(data);
            	}
            }
        });
 	}
 	
 	$scope.onMarkAssignment = function(aMarkModel){
 		$http({
	        method  : 'POST',
	        url     : 'ec/mark-assignment-answer',
	        data    : $.param(aMarkModel),  
	        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
    	}).success(function(data) {
            if( data.code == 0 ){
            	$scope.loadAssignmentAnswer();
            }
        });
 		
 	}
 	/*
 	$scope.addEC = function(electiveCourse){
 		
 		var isSuccess = addECParamCheck(electiveCourse);
		if( isSuccess ){
			$http({
		        method  : 'POST',
		        url     : 'ec/add-elective-course',
		        data    : $.param(electiveCourse),  
		        headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
	    	}).success(function(data) {
	            if( data.code == 0 ){
	            	$scope.electiveCourse = {};
	            	$scope.loadECList();
	            }
	        });
		}
 	}
 	
 	function addECParamCheck(electiveCourse){
 		if( $.trim(electiveCourse.name) == '' ){
 			alert('请输入选课名称');
 			return false;
 		}
 		if( $.trim(electiveCourse.description) == '' ){
 			alert('请输入选课公告');
 			return false;
 		}
 		if( electiveCourse.teacherID == null ){
 			alert('请选择老师');
 			return false;
 		}
 		if( electiveCourse.studentIDList == null || electiveCourse.studentIDList.length == 0 ){
 			alert('请选择学生');
 			return false;
 		}
 		return true;
 	}
 	*/
 	
 	
 	
}