$(function(){
	$('.logo-text').text('心理咨询专业资源库');
});